/* =====================================================================
   engine.js — محرّك خطة حفظ القرآن الكريم (مشترك بين كل الصفحات)
   لا تعدّل فيه إلا الإعدادات في الأعلى (QT_CONFIG).
   مكتوب بصيغة قديمة (ES5) ليعمل على الأجهزة القديمة أيضًا.
   ===================================================================== */

/* ---------------------------------------------------------------------
   الإعدادات
   --------------------------------------------------------------------- */
var QT_CONFIG = {
  // رابط Google Apps Script (الذي نشرته). لو غيّرته ضعه هنا.
  SCRIPT_URL: "https://script.google.com/macros/s/AKfycbyladtIbtLJUU9M-f25RuOaW9dVaTs2FXQj2D1LnhNYXvkKaOWEpHbaxRQ7rVcf6foCPg/exec",
  // عدد أرباع التثبيت في اليوم (ربعان).
  FIX_PER_DAY: 2,
  // تاريخ بداية «خطة الجديد للترم الأول» (YYYY-MM-DD). فارغ = لا تزال خطة الأرباع القديمة (لا شيء يتغير).
  // لو كتبت تاريخًا: الأيام قبله تبقى بالنظام القديم وتقاريرها كما هي، ومنه يحسب النظام لكل مشترك آخر آية حفظها فعلًا ويكمل من بعدها.
  // مهم: اكتب نفس التاريخ في ملف engine.js على GitHub وفي ملف Engine.gs في Apps Script.
  NEW_PLAN_START: "",                                  // يُضبط تلقائيًا من الخادم (Code.gs ← NEW_PLAN_START)؛ لا تعدّله هنا
  VERSION: "final-5",
  // رقم الدعم (يظهر أسفل كل صفحة)
  SUPPORT_PHONE: "201095374757",
  // الرقم الذي ترسل منه الرسائل (رقم واتساب Meta). اكتبه بصيغة دولية بدون +؛ يظهر في شاشة الترحيب ليحفظه المشترك.
  SENDER_PHONE: "",
  SENDER_NAME: "خطة القرآن 📖"
};

var QT = (function () {

  /* -------------------------------------------------------------------
     البيانات: أسماء السور
     ------------------------------------------------------------------- */
  var SURAHS = ["الفاتحة","البقرة","آل عمران","النساء","المائدة","الأنعام","الأعراف","الأنفال","التوبة","يونس","هود","يوسف","الرعد","إبراهيم","الحجر","النحل","الإسراء","الكهف","مريم","طه","الأنبياء","الحج","المؤمنون","النور","الفرقان","الشعراء","النمل","القصص","العنكبوت","الروم","لقمان","السجدة","الأحزاب","سبأ","فاطر","يس","الصافات","ص","الزمر","غافر","فصلت","الشورى","الزخرف","الدخان","الجاثية","الأحقاف","محمد","الفتح","الحجرات","ق","الذاريات","الطور","النجم","القمر","الرحمن","الواقعة","الحديد","المجادلة","الحشر","الممتحنة","الصف","الجمعة","المنافقون","التغابن","الطلاق","التحريم","الملك","القلم","الحاقة","المعارج","نوح","الجن","المزمل","المدثر","القيامة","الإنسان","المرسلات","النبأ","النازعات","عبس","التكوير","الانفطار","المطففين","الانشقاق","البروج","الطارق","الأعلى","الغاشية","الفجر","البلد","الشمس","الليل","الضحى","الشرح","التين","العلق","القدر","البينة","الزلزلة","العاديات","القارعة","التكاثر","العصر","الهمزة","الفيل","قريش","الماعون","الكوثر","الكافرون","النصر","المسد","الإخلاص","الفلق","الناس"];

  /* -------------------------------------------------------------------
     الكنز: 180 وحدة (ربع) = يومان × 90 يومًا
     كل وحدة: مصفوفة أجزاء [السورة، رقم الربع داخل السورة، بداية الربع، من آية، إلى آية، ملاحظة]
     ------------------------------------------------------------------- */
var SLOTS=[
[["الأنعام",0,"بداية السورة",1,12,""],["الأنعام",1,"وله ما سكن",13,35,""]],
[["الأنعام",2,"إنما يستجيب",36,58,""]],
[["الأنعام",3,"وعنده مفاتح الغيب",59,73,""]],
[["الأنعام",4,"وإذ قال إبراهيم",74,94,""]],
[["الأنعام",5,"إن الله فالق الحب",95,110,""]],
[["الأنعام",6,"ولو أننا نزلنا",111,126,""]],
[["الأنعام",7,"لهم دار السلام",127,140,""]],
[["الأنعام",8,"وهو الذي أنشأ",141,150,""]],
[["الأنعام",9,"قل تعالوا أتل",151,165,""]],
[["الأعراف",1,"بداية السورة",1,30,""]],
[["الأعراف",2,"يا بني آدم خذوا",31,46,""]],
[["الأعراف",3,"وإذا صرفت",47,64,""]],
[["الأعراف",4,"وإلى عاد أخاهم",65,87,""]],
[["الأعراف",5,"قال الملأ",88,116,""]],
[["الأعراف",6,"وأوحينا إلى موسى",117,141,""]],
[["الأعراف",7,"وواعدنا",142,155,""]],
[["الأعراف",8,"واكتب لنا",156,170,""]],
[["الأعراف",9,"وإذ نتقنا",171,188,""]],
[["الأعراف",10,"هو الذي خلقكم",189,206,""]],
[["الأنفال",1,"بداية السورة",1,21,""]],
[["الأنفال",2,"إن شر الدواب",22,40,""]],
[["الأنفال",3,"واعلموا أنما",41,60,""]],
[["الأنفال",4,"وإن جنحوا",61,75,""]],
[["التوبة",1,"بداية السورة",1,18,""]],
[["التوبة",2,"أجعلتم سقاية",19,33,""]],
[["التوبة",3,"يا أيها الذين",34,45,""]],
[["التوبة",4,"ولو أرادوا الخروج",46,59,""]],
[["التوبة",5,"إنما الصدقات",60,74,""]],
[["التوبة",6,"ومنهم من عاهد",75,92,""]],
[["التوبة",7,"إنما السبيل",93,110,""]],
[["التوبة",8,"إن الله اشترى",111,121,""]],
[["التوبة",9,"وما كان",122,129,""]],
[["يونس",1,"بداية السورة",1,10,""]],
[["يونس",2,"ولو يعجل الله",11,25,""]],
[["يونس",3,"للذين أحسنوا",26,52,""]],
[["يونس",4,"ويستنبئونك",53,70,""]],
[["يونس",5,"فمن أظلم",71,89,""]],
[["يونس",6,"وجاوزنا ببني إسرائيل",90,109,"ختام السورة"]],
[["هود",1,"بداية السورة",1,23,""]],
[["هود",2,"ويا قوم لا أسألكم",24,40,""]],
[["هود",3,"قيل يا نوح اهبط",41,60,""]],
[["هود",4,"وإلى ثمود أخاهم",61,83,""]],
[["هود",5,"وإلى مدين أخاهم",84,107,""]],
[["هود",6,"وأقم الصلاة",108,123,""]],
[["يوسف",1,"بداية السورة",1,29,""]],
[["يوسف",2,"وقال نسوة",30,52,""]],
[["يوسف",3,"وما أبرئ نفسي",53,76,""]],
[["يوسف",4,"فلما استيأسوا",77,100,""]],
[["يوسف",5,"وكأين من آية",101,111,"ختام السورة"]],
[["الرعد",1,"بداية السورة",1,18,""]],
[["الرعد",2,"أفمن يعلم",19,34,""]],
[["الرعد",3,"ومثل الجنة",35,43,"ختام السورة"]],
[["إبراهيم",1,"بداية السورة",1,27,""]],
[["إبراهيم",2,"ألم تر إلى الذين بدلوا",28,52,"ختام السورة"]],
[["الحجر",1,"بداية السورة",1,48,""]],
[["الحجر",2,"ونبئهم عن ضيف",49,99,"ختام السورة"]],
[["النحل",1,"بداية السورة",1,29,""]],
[["النحل",2,"وقيل للذين اتقوا",30,50,""]],
[["النحل",3,"وقال الله لا تتخذوا",51,74,""]],
[["النحل",4,"وضرب الله مثلاً",75,89,""]],
[["النحل",5,"إن الله يأمر بالعدل",90,110,""]],
[["النحل",6,"ثم إن ربك للذين هاجروا",111,128,"ختام السورة"]],
[["الإسراء",1,"بداية السورة",1,22,""]],
[["الإسراء",2,"وقضى ربك",23,49,""]],
[["الإسراء",3,"وقل لعبادي",50,69,""]],
[["الإسراء",4,"وإذ قلنا لك",70,98,""]],
[["الإسراء",5,"أولم يروا أن الله",99,111,"ختام السورة"]],
[["الكهف",1,"بداية السورة",1,16,""]],
[["الكهف",2,"وترى الشمس",17,31,""]],
[["الكهف",3,"واضرب لهم مثلاً",32,50,""]],
[["الكهف",4,"وما منع الناس",51,74,""]],
[["الكهف",5,"قال ألم أقل لك",75,110,"ختام السورة"]],
[["مريم",1,"بداية السورة",1,58,""]],
[["مريم",2,"أفرأيت الذي كفر",59,98,"ختام السورة"]],
[["طه",1,"بداية السورة",1,54,""]],
[["طه",2,"قال فما بالك",55,82,""]],
[["طه",3,"وما أعجلك",83,110,""]],
[["طه",4,"ومن أعرض عن ذكري",111,135,"ختام السورة"]],
[["الأنبياء",1,"بداية السورة",1,50,""]],
[["الأنبياء",2,"ولقد آتينا إبراهيم",51,82,""]],
[["الأنبياء",3,"وأيوب إذ نادى",83,112,"ختام السورة"]],
[["الحج",1,"بداية السورة",1,18,""]],
[["الحج",2,"ألم تر أن الله يسجد له",19,37,""]],
[["الحج",3,"أذن للذين يقاتلون",38,59,""]],
[["الحج",4,"ذلك ومن عاقب",60,78,"ختام السورة"]],
[["المؤمنون",1,"بداية السورة",1,35,""]],
[["المؤمنون",2,"ثم أنشأنا",36,74,""]],
[["المؤمنون",3,"حتى إذا أخذنا",75,118,"ختام السورة"]],
[["النور",1,"بداية السورة",1,20,""]],
[["النور",2,"لولا إذ سمعتموه",21,34,""]],
[["النور",3,"الله نور السماوات والأرض",35,52,""]],
[["النور",4,"ولقد أنزلنا",53,64,"ختام السورة"]],
[["الفرقان",1,"بداية السورة",1,20,""]],
[["الفرقان",2,"وقال الذين لا يرجون",21,52,""]],
[["الفرقان",3,"وهو الذي مرج البحرين",53,77,"ختام السورة"]],
[["الشعراء",1,"بداية السورة",1,51,""]],
[["الشعراء",2,"قال للملأ حوله",52,110,""]],
[["الشعراء",3,"قالوا أنؤمن لك",111,180,""]],
[["الشعراء",4,"قالوا إنما أنت من السحرين",181,227,"ختام السورة"]],
[["النمل",1,"بداية السورة",1,26,""]],
[["النمل",2,"قال سننظر",27,55,""]],
[["النمل",3,"أمن خلق السماوات",56,75,""]],
[["النمل",4,"إن هذا القرآن يقص",76,93,"ختام السورة"]],
[["القصص",1,"بداية السورة",1,11,""]],
[["القصص",2,"وحرمنا عليه المراضع",12,28,""]],
[["القصص",3,"فلما قضى موسى الأجل",29,50,""]],
[["القصص",4,"ولقد وصلنا لهم القول",51,75,""]],
[["القصص",5,"إن قارون كان",76,88,"ختام السورة"]],
[["العنكبوت",1,"بداية السورة",1,25,""]],
[["العنكبوت",2,"فما كان جواب قومه",26,45,""]],
[["العنكبوت",3,"ولا تجادلوا أهل الكتاب",46,69,"ختام السورة"]],
[["الروم",1,"بداية السورة",1,30,""]],
[["الروم",2,"ومن آياته أن خلق لكم",31,60,"ختام السورة"]],
[["لقمان",1,"بداية السورة",1,21,""]],
[["لقمان",2,"وإذا قيل لهم اتبعوا",22,34,"ختام السورة"]],
[["السجدة",1,"بداية السورة",1,30,"ختام السورة"]],
[["الأحزاب",1,"بداية السورة",1,17,""]],
[["الأحزاب",2,"وإذ قالت طائفة",18,30,""]],
[["الأحزاب",3,"ومن يقنت منكن",31,50,""]],
[["الأحزاب",4,"لا يحل لك النساء",51,59,""]],
[["الأحزاب",5,"يا أيها الذين آمنوا اذكروا",60,73,"ختام السورة"]],
[["سبأ",1,"بداية السورة",1,23,""]],
[["سبأ",2,"قل إن ربي يبسط الرزق",24,54,"ختام السورة"]],
[["فاطر",1,"بداية السورة",1,14,""]],
[["فاطر",2,"يا أيها الناس أنتم الفقراء",15,45,"ختام السورة"]],
[["يس",1,"بداية السورة",1,27,""]],
[["يس",2,"وما أنزلنا على قومه",28,59,""]],
[["يس",3,"ألم أعهد إليكم",60,83,"ختام السورة"]],
[["الصافات",1,"بداية السورة",1,82,""]],
[["الصافات",2,"وإن من شيعته لإبراهيم",83,144,""]],
[["الصافات",3,"فنبذناه بالعراء",145,182,"ختام السورة"]],
[["ص",1,"بداية السورة",1,51,""]],
[["ص",2,"هذا وإن للطاغين",52,88,"ختام السورة"]],
[["الزمر",1,"بداية السورة",1,31,""]],
[["الزمر",2,"فمن أظلم ممن كذب",32,52,""]],
[["الزمر",3,"قل يا عبادي الذين أسرفوا",53,75,"ختام السورة"]],
[["غافر",1,"بداية السورة",1,20,""]],
[["غافر",2,"وقال رجل مؤمن",21,40,""]],
[["غافر",3,"ويا قوم ما لي أدعوكم",41,65,""]],
[["غافر",4,"فسبحان الله",66,85,"ختام السورة"]],
[["فصلت",1,"بداية السورة",1,24,""]],
[["فصلت",2,"وقال الذين كفروا",25,46,""]],
[["فصلت",3,"إليه يرد علم الساعة",47,54,"ختام السورة"]],
[["الشورى",1,"بداية السورة",1,26,""]],
[["الشورى",2,"ومن آياته الجوار",27,53,"ختام السورة"]],
[["الزخرف",1,"بداية السورة",1,23,""]],
[["الزخرف",2,"واستمسك بالذي أوحي",24,56,""]],
[["الزخرف",3,"ولما ضرب ابن مريم",57,89,"ختام السورة"]],
[["الدخان",0,"كاملة",1,59,""]],
[["الجاثية",0,"كاملة",1,37,""]],
[["الأحقاف",1,"بداية السورة",1,20,""]],
[["الأحقاف",2,"واذكر أخا عاد",21,35,"ختام السورة"]],
[["محمد",0,"كاملة",1,38,""]],
[["الفتح",1,"بداية السورة",1,17,""]],
[["الفتح",2,"هو الذي أنزل السكينة",18,29,"ختام السورة"]],
[["الحجرات",0,"كاملة",1,18,""]],
[["ق",0,"كاملة",1,45,""]],
[["الذاريات",1,"بداية السورة",1,30,""]],
[["الذاريات",2,"قال فما خطبكم",31,60,"ختام السورة"]],
[["الطور",0,"كاملة",1,49,""]],
[["النجم",0,"كاملة",1,62,""]],
[["القمر",0,"كاملة",1,55,""]],
[["الرحمن",0,"كاملة",1,78,""]],
[["الواقعة",0,"كاملة",1,96,""]],
[["الحديد",0,"كاملة",1,29,""]],
[["المجادلة",0,"كاملة",1,22,""]],
[["الحشر",0,"كاملة",1,24,""]],
[["الممتحنة",0,"كاملة",1,13,""]],
[["الصف",0,"كاملة",1,14,""],["الجمعة",0,"كاملة",1,11,""]],
[["المنافقون",0,"كاملة",1,11,""],["التغابن",0,"كاملة",1,18,""]],
[["الطلاق",0,"كاملة",1,12,""],["التحريم",0,"كاملة",1,12,""]],
[["الملك",0,"كاملة",1,30,""]],
[["القلم",0,"كاملة",1,52,""]],
[["الحاقة",0,"كاملة",1,52,""],["المعارج",0,"كاملة",1,44,""]],
[["نوح",0,"كاملة",1,28,""],["الجن",0,"كاملة",1,28,""]],
[["المزمل",0,"كاملة",1,20,""],["المدثر",0,"كاملة",1,56,""]],
[["القيامة",0,"كاملة",1,40,""],["الإنسان",0,"كاملة",1,31,""],["المرسلات",0,"كاملة",1,50,""]],
[["النبأ",0,"كاملة",1,40,""],["النازعات",0,"كاملة",1,46,""],["عبس",0,"كاملة",1,42,""],["التكوير",0,"كاملة",1,29,""],["الانفطار",0,"كاملة",1,19,""],["المطففين",0,"كاملة",1,36,""],["الانشقاق",0,"كاملة",1,25,""],["البروج",0,"كاملة",1,22,""],["الطارق",0,"كاملة",1,17,""],["الأعلى",0,"كاملة",1,19,""],["الغاشية",0,"كاملة",1,26,""],["الفجر",0,"كاملة",1,30,""],["البلد",0,"كاملة",1,20,""],["الشمس",0,"كاملة",1,15,""],["الليل",0,"كاملة",1,21,""],["الضحى",0,"كاملة",1,11,""],["الشرح",0,"كاملة",1,8,""],["التين",0,"كاملة",1,8,""],["العلق",0,"كاملة",1,19,""]],
[["القدر",0,"كاملة",1,5,""],["البينة",0,"كاملة",1,8,""],["الزلزلة",0,"كاملة",1,8,""],["العاديات",0,"كاملة",1,11,""],["القارعة",0,"كاملة",1,11,""],["التكاثر",0,"كاملة",1,8,""]],
[["العصر",0,"كاملة",1,3,""],["الهمزة",0,"كاملة",1,9,""],["الفيل",0,"كاملة",1,5,""],["قريش",0,"كاملة",1,4,""],["الماعون",0,"كاملة",1,7,""],["الكوثر",0,"كاملة",1,3,""],["الكافرون",0,"كاملة",1,6,""],["النصر",0,"كاملة",1,3,""],["المسد",0,"كاملة",1,5,""],["الإخلاص",0,"كاملة",1,4,""],["الفلق",0,"كاملة",1,5,""],["الناس",0,"كاملة",1,6,""]]
];

  var UNITS = 180;       // عدد الأرباع
  var UNIT12 = 12;       // كل ربع = 12 جزءًا (لتمثيل ¼ ⅓ ½ ⅔ ¾ بدون كسور عشرية)
  var TOTAL12 = UNITS * UNIT12;   // 2160
  var DAY12 = 24;        // المطلوب اليومي الافتراضي = ربعان (يقدر كل مشترك يغيّره: st.tpd)
  var TPD_OPTIONS = [1, 1.5, 2, 2.5, 3, 4];        // عدد أرباع الكنز المسموح اختيارها في اليوم
  function tpdLabel(q) { return q === 1 ? "ربع واحد" : (q === 1.5 ? "ربع ونصف" : (q === 2 ? "ربعان" : (q === 2.5 ? "ربعان ونصف" : (q === 3 ? "3 أرباع" : (q === 4 ? "4 أرباع" : q + " ربع"))))); }
  function normTpd(a) {                              // st.tpd = [{from:"YYYY-MM-DD", q:عدد الأرباع}] مرتبة بالتاريخ؛ لا تُطبَّق إلا من تاريخها فصاعدًا فلا يتغير الماضي
    var out = [], i, x;
    if (!a || a.length === undefined) return out;
    for (i = 0; i < a.length; i++) { x = a[i]; if (x && /^\d{4}-\d{2}-\d{2}$/.test(String(x.from)) && TPD_OPTIONS.indexOf(Number(x.q)) > -1) out.push({ from: String(x.from), q12: Math.round(Number(x.q) * 12) }); }
    out.sort(function (p, q) { return p.from < q.from ? -1 : (p.from > q.from ? 1 : 0); });
    return out;
  }

  /* -------------------------------------------------------------------
     الجديد: سورة المائدة — 9 أرباع، كل ربع على يومين
     ------------------------------------------------------------------- */
  var MAIDA = [
    { q: 1, s: 1,   e: 11,  ph: "بداية السورة" },
    { q: 2, s: 12,  e: 26,  ph: "ولقد أخذ الله ميثاق بني إسرائيل" },
    { q: 3, s: 27,  e: 40,  ph: "واتل عليهم نبأ ابني آدم" },
    { q: 4, s: 41,  e: 50,  ph: "يا أيها الرسول لا يحزنك" },
    { q: 5, s: 51,  e: 66,  ph: "يا أيها الذين آمنوا لا تتخذوا اليهود والنصارى أولياء" },
    { q: 6, s: 67,  e: 81,  ph: "يا أيها الرسول بلغ" },
    { q: 7, s: 82,  e: 96,  ph: "لتجدن أشد الناس عداوة" },
    { q: 8, s: 97,  e: 108, ph: "جعل الله الكعبة" },
    { q: 9, s: 109, e: 120, ph: "يوم يجمع الله الرسل" }
  ];
  (function () {
    for (var i = 0; i < MAIDA.length; i++) {
      var n = MAIDA[i].e - MAIDA[i].s + 1;
      MAIDA[i].mid = MAIDA[i].s + Math.ceil(n / 2) - 1;   // نهاية اليوم الأول من الربع
    }
  })();

  var REST = { 0: 1, 3: 1 };      // أيام الراحة (0=الأحد ... 6=السبت)؛ يحددها كل مشترك عند التسجيل، والافتراضي الأحد والأربعاء
  function setRest(arr) {
    REST = {};
    if (!arr || arr.length === undefined) arr = [0, 3];
    for (var i = 0; i < arr.length; i++) { var n = Number(arr[i]); if (n >= 0 && n <= 6 && n !== 5) REST[n] = 1; }
  }
  function getRestArr() { var o = []; for (var k in REST) if (REST.hasOwnProperty(k)) o.push(Number(k)); o.sort(function (a, b) { return a - b; }); return o; }
  function isRest(s) { return !!REST[parseYmd(s).getDay()]; }

  // وحدات الجديد: كل ربع من يومين (الأول والثاني) وتراكم أحجامها، لمعرفة هل المشترك متأخر أم متقدم عن الخطة
  var PM = [0];
  (function () {
    for (var i = 0; i < MAIDA.length; i++) {
      var q = MAIDA[i];
      PM.push(PM[PM.length - 1] + (q.mid - q.s + 1));
      if (q.e > q.mid) PM.push(PM[PM.length - 1] + (q.e - q.mid));
    }
  })();
  function cumM(n) { return PM[Math.min(n, PM.length - 1)]; }

  // «خطة الجديد للترم الأول»: 25 يومًا من سورة المائدة (الآيات 1–66)
  var NEWPLAN = [[1,2],[3,4],[5,6],[7,9],[10,11],[12,13],[14,15],[16,17],[18,20],[21,23],[24,27],[28,31],[32,33],[34,36],[37,40],[41,41],[42,43],[44,45],[46,47],[48,50],[51,53],[54,57],[58,61],[62,64],[65,66]];
  var NU = [], CNU = [0];
  (function () {
    for (var i = 0; i < NEWPLAN.length; i++) {
      NU.push({ k: i + 1, s: NEWPLAN[i][0], e: NEWPLAN[i][1], size: NEWPLAN[i][1] - NEWPLAN[i][0] + 1 });
      CNU.push(CNU[CNU.length - 1] + NU[i].size);
    }
  })();
  var NEW_LAST = NU[NU.length - 1].e;                           // 66
  function cumNU(n) { return CNU[Math.min(n, NU.length)]; }
  function unitsCovered(v) { var c = 0; for (var i = 0; i < NU.length; i++) { if (NU[i].e <= v) c++; else break; } return c; }
  function unitAt(v) { for (var i = 0; i < NU.length; i++) if (NU[i].e >= v) return NU[i]; return null; }
  function pageSpan(p) { return { s: NU[2 * p - 2].s, e: NU[Math.min(2 * p, NU.length) - 1].e }; }   // «صفحة» = يومان متتاليان من الخطة (نصف صفحة في اليوم)

  var DAYNAMES = ["الأحد","الاثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"];
  var MONTHS = ["يناير","فبراير","مارس","أبريل","مايو","يونيو","يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر"];

  /* -------------------------------------------------------------------
     أدوات عامة
     ------------------------------------------------------------------- */
  function esc(s) {
    return String(s === null || s === undefined ? "" : s).replace(/[&<>"']/g, function (m) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[m];
    });
  }
  function pad2(n) { return (n < 10 ? "0" : "") + n; }
  function ymd(d) { return d.getFullYear() + "-" + pad2(d.getMonth() + 1) + "-" + pad2(d.getDate()); }
  function parseYmd(s) {
    var p = String(s).split("-");
    return new Date(Number(p[0]), Number(p[1]) - 1, Number(p[2]), 12, 0, 0);
  }
  function addDays(s, k) { var d = parseYmd(s); d.setDate(d.getDate() + k); return ymd(d); }
  function dowOf(s) { return parseYmd(s).getDay(); }          // 0 أحد ... 5 جمعة ... 6 سبت
  function todayStr() { return ymd(new Date()); }
  function isYmd(s) { return /^\d{4}-\d{2}-\d{2}$/.test(String(s || "")); }
  function prettyDate(s) {
    var d = parseYmd(s);
    return DAYNAMES[d.getDay()] + " " + d.getDate() + " " + MONTHS[d.getMonth()] + " " + d.getFullYear();
  }
  function shortDate(s) {
    var d = parseYmd(s);
    return d.getDate() + " " + MONTHS[d.getMonth()];
  }
  function weekStart(s) {              // بداية الأسبوع = السبت
    var dw = dowOf(s);
    var back = (dw + 1) % 7;           // السبت 0، الأحد 1 ... الجمعة 6
    return addDays(s, -back);
  }
  function getParam(name) {
    var q = String(window.location.search || "").replace(/^\?/, "").split("&");
    for (var i = 0; i < q.length; i++) {
      var kv = q[i].split("=");
      if (decodeURIComponent(kv[0]) === name) return decodeURIComponent((kv[1] || "").replace(/\+/g, " "));
    }
    return "";
  }

  /* -------------------------------------------------------------------
     الكسور: كل كمية في الكنز تُخزَّن بالأجزاء (ربع = 12 جزءًا)
     ¼ = 3 ، ⅓ = 4 ، ½ = 6 ، ⅔ = 8 ، ¾ = 9 ، 1 = 12
     ------------------------------------------------------------------- */
  var FR = { 3: "¼", 4: "⅓", 6: "½", 8: "⅔", 9: "¾" };
  function gcd(a, b) { return b ? gcd(b, a % b) : a; }
  function fmtRaw(t) {
    t = Math.round(t);
    if (t <= 0) return "0";
    var w = Math.floor(t / 12), r = t % 12, f = "";
    if (r) {
      if (FR[r]) f = FR[r];
      else { var g = gcd(r, 12); f = (r / g) + "/" + (12 / g); }
    }
    if (w && f) return w + (FR[r] ? "" : " ") + f;
    if (w) return String(w);
    return f;
  }
  // نفس القيمة لكن بعلامة اتجاه تجعل الكسر يظهر صحيحًا (2¼ وليس ¼2) داخل النص العربي
  function fmtU(t) { return "\u200E" + fmtRaw(t) + "\u200E"; }
  function normDigits(s) {
    return String(s).replace(/[\u200E\u200F]/g, "").replace(/[٠-٩]/g, function (d) { return String(d.charCodeAt(0) - 1632); })
                    .replace(/٫/g, ".").replace(/[،,]/g, ".").replace(/⁄/g, "/");
  }
  function parseU(str) {
    var s = normDigits(str || "");
    s = s.replace(/¼/g, " 1/4 ").replace(/⅓/g, " 1/3 ").replace(/½/g, " 1/2 ")
         .replace(/⅔/g, " 2/3 ").replace(/¾/g, " 3/4 ");
    s = s.replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "");
    if (!s) return null;
    var toks = s.split(" "), total = 0;
    for (var i = 0; i < toks.length; i++) {
      var t = toks[i], v;
      if (/^\d+\/\d+$/.test(t)) {
        var ab = t.split("/");
        if (Number(ab[1]) === 0) return null;
        v = 12 * Number(ab[0]) / Number(ab[1]);
      } else if (/^\d+(\.\d+)?$/.test(t)) {
        v = 12 * parseFloat(t);
      } else {
        return null;
      }
      if (Math.abs(v - Math.round(v)) > 0.0001) return null;
      total += Math.round(v);
    }
    return total;
  }

  /* -------------------------------------------------------------------
     وصف أجزاء الكنز
     ------------------------------------------------------------------- */
  function partText(p) {
    if (p[1] === 0 && p[2] === "كاملة") return p[0] + " كاملة (" + p[3] + "–" + p[4] + ")";
    return p[0] + " — " + p[2] + " (" + p[3] + "–" + p[4] + ")";
  }
  function unitInfo(u) {              // u من 1 إلى 180
    var parts = SLOTS[u - 1] || [];
    var names = [], i;
    for (i = 0; i < parts.length; i++) if (names.indexOf(parts[i][0]) < 0) names.push(parts[i][0]);
    var title, sub, ayat;
    if (parts.length === 0) { title = ""; sub = ""; ayat = ""; }
    else if (parts.length <= 2) {
      var tt = [], ss = [], aa = [];
      for (i = 0; i < parts.length; i++) {
        tt.push(parts[i][0]);
        ss.push(parts[i][2] === "كاملة" ? "كاملة" : parts[i][2]);
        aa.push(parts[i][3] + "–" + parts[i][4]);
      }
      if (parts.length === 1) { title = tt[0]; sub = ss[0]; ayat = aa[0]; }
      else if (parts[0][0] === parts[1][0]) {   // نفس السورة (بداية السورة + الربع الأول)
        title = tt[0]; sub = ss.join(" ثم "); ayat = parts[0][3] + "–" + parts[1][4];
      } else { title = tt.join(" + "); sub = ss.join(" + "); ayat = aa.join(" + "); }
    } else {
      title = "من " + parts[0][0] + " إلى " + parts[parts.length - 1][0];
      sub = parts.length + " سورة";
      ayat = "";
    }
    return { u: u, title: title, sub: sub, ayat: ayat, names: names, parts: parts };
  }
  // مقطع من الكنز: الربع u والجزء من a إلى b (بالأجزاء 0..12)
  function segsOf(from12, to12) {
    var segs = [];
    var u = Math.floor(from12 / 12);
    while (u * 12 < to12 && u < UNITS) {
      var a = Math.max(from12, u * 12) - u * 12;
      var b = Math.min(to12, (u + 1) * 12) - u * 12;
      segs.push({ u: u + 1, a: a, b: b, whole: (a === 0 && b === 12), info: unitInfo(u + 1) });
      u++;
    }
    return segs;
  }
  function segLabel(sg) {
    var s = "ربع " + sg.u;
    if (!sg.whole) {
      if (sg.a === 0) s += " (أول " + fmtU(sg.b - sg.a) + ")";
      else if (sg.b === 12) s += " (آخر " + fmtU(sg.b - sg.a) + ")";
      else s += " (جزء " + fmtU(sg.b - sg.a) + ")";
    }
    return s;
  }
  function segFull(sg) {
    var i = sg.info;
    var s = segLabel(sg) + " — " + i.title;
    if (i.sub && i.sub !== "كاملة") s += ": " + i.sub;
    if (i.ayat) s += " (" + i.ayat + ")";
    return s;
  }

  /* -------------------------------------------------------------------
     الحالة (state) وتخزينها
     state = {
       v:2, start:"YYYY-MM-DD", settingsAt:0,
       reports: { "YYYY-MM-DD": { at, t:{st,amt}, nw:{st,to}, fx:{st}, day:"full|none|" } },
       comps:   [ { id, kind:"t|n|day", ref, amt, date, at } ],
       kahf:    { "YYYY-MM-DD": { ok:true/false, at } }
     }
     ------------------------------------------------------------------- */
  var SESS_KEY = "qt_session_v1";
  function getSession() {
    try {
      var x = JSON.parse(window.localStorage.getItem(SESS_KEY) || "null");
      if (x && x.uid && x.token) return x;
    } catch (e) {}
    return null;
  }
  function setSession(x) {
    try { if (x) window.localStorage.setItem(SESS_KEY, JSON.stringify(x)); else window.localStorage.removeItem(SESS_KEY); } catch (e) {}
  }
  function lsKey() { var x = getSession(); return "qt_state_v2_" + (x ? x.uid : "anon"); }
  function dirtyKey() { var x = getSession(); return "qt_dirty_" + (x ? x.uid : "anon"); }
  var state = null;

  function emptyState() { return { v: 2, start: "", settingsAt: 0, reports: {}, comps: [], kahf: {} }; }
  function loadLocal() {
    try {
      var raw = window.localStorage.getItem(lsKey());
      if (raw) {
        var s = JSON.parse(raw);
        if (s && typeof s === "object") {
          s.reports = s.reports || {}; s.comps = s.comps || []; s.kahf = s.kahf || {};
          s.start = s.start || ""; s.settingsAt = s.settingsAt || 0; s.v = 2;
          return s;
        }
      }
    } catch (e) {}
    return emptyState();
  }
  function saveLocal() {
    try { window.localStorage.setItem(lsKey(), JSON.stringify(state)); } catch (e) {}
  }
  function setDirty(v) { try { window.localStorage.setItem(dirtyKey(), v ? "1" : "0"); } catch (e) {} }
  function isDirty() { try { return window.localStorage.getItem(dirtyKey()) === "1"; } catch (e) { return false; } }

  function merge(a, b) {            // دمج حالتين: الأحدث يفوز لكل عنصر
    var out = emptyState(), k;
    if ((b.settingsAt || 0) > (a.settingsAt || 0)) { out.start = b.start || ""; out.settingsAt = b.settingsAt || 0; if (b.base) out.base = b.base; if (b.prevStart) out.prevStart = b.prevStart; if (b.tpd) out.tpd = b.tpd; }
    else { out.start = a.start || ""; out.settingsAt = a.settingsAt || 0; if (a.base) out.base = a.base; if (a.prevStart) out.prevStart = a.prevStart; if (a.tpd) out.tpd = a.tpd; }
    var sets = [["reports", "at"], ["kahf", "at"]];
    for (var i = 0; i < sets.length; i++) {
      var nm = sets[i][0];
      var A = a[nm] || {}, B = b[nm] || {};
      for (k in A) if (A.hasOwnProperty(k)) out[nm][k] = A[k];
      for (k in B) if (B.hasOwnProperty(k)) {
        if (!out[nm][k] || (B[k].at || 0) > (out[nm][k].at || 0)) out[nm][k] = B[k];
      }
    }
    var seen = {}, list = (a.comps || []).concat(b.comps || []);
    for (i = 0; i < list.length; i++) {
      if (!seen[list[i].id]) { seen[list[i].id] = 1; out.comps.push(list[i]); }
    }
    return out;
  }
  function sameState(a, b) { return JSON.stringify(a) === JSON.stringify(b); }

  /* ---- اتصال بسيط مع Google Apps Script ---- */
  function http(method, url, body, cb, timeoutMs) {
    var done = false, x;
    function fin(ok, data) { if (done) return; done = true; if (cb) cb(ok, data); }
    try {
      x = new XMLHttpRequest();
      x.open(method, url, true);
      if (method === "POST") x.setRequestHeader("Content-Type", "text/plain;charset=utf-8");
      x.timeout = timeoutMs || 9000;
      x.onreadystatechange = function () {
        if (x.readyState !== 4) return;
        if (x.status >= 200 && x.status < 300) {
          var d = null;
          try { d = JSON.parse(x.responseText); } catch (e) {}
          fin(true, d);
        } else fin(false, null);
      };
      x.ontimeout = function () { fin(false, null); };
      x.onerror = function () { fin(false, null); };
      x.send(method === "POST" ? body : null);
    } catch (e) { fin(false, null); }
  }
  function hasServer() { return QT_CONFIG.SCRIPT_URL && QT_CONFIG.SCRIPT_URL.indexOf("script.google.com") > -1; }

  function goAccount() {
    var here = String(window.location.pathname || "").split("/").pop() + String(window.location.search || "");
    var next = /^[A-Za-z]+\.html(\?.*)?$/.test(here) && here.indexOf("account.html") < 0 ? "?next=" + encodeURIComponent(here) : "";
    window.location.replace("account.html" + next);
  }
  function rememberPhone() { try { var x = getSession(); if (x && x.phone) window.localStorage.setItem("qt_lastphone", x.phone); } catch (e) {} }
  function authFail() { rememberPhone(); setSession(null); goAccount(); }

  function pull(cb) {
    var ss = getSession();
    if (!hasServer() || !ss) { if (cb) cb(false, false); return; }
    http("POST", QT_CONFIG.SCRIPT_URL, JSON.stringify({ action: "get", uid: ss.uid, token: ss.token }), function (ok, data) {
      if (ok && data && data.ok === false && data.error === "auth") { authFail(); return; }
      if (!ok || !data || !data.state) { if (cb) cb(false, false); return; }
      var restChanged = applyConfig(data.config);
      if (data.profile) {
        var oldRest = JSON.stringify(ss.rest || [0, 3]);
        ss.name = data.profile.name; ss.phone = data.profile.phone; ss.guardian = data.profile.guardian; ss.rest = data.profile.rest || [0, 3]; ss.reminders = data.profile.reminders || ["18:00", "22:00"]; ss.tasksStudent = data.profile.tasksStudent || ["06:00"]; ss.tasksGuardian = data.profile.tasksGuardian || ["06:00"];
        setSession(ss); setRest(ss.rest);
        restChanged = restChanged || (oldRest !== JSON.stringify(ss.rest));
      }
      var remote = data.state;
      remote.reports = remote.reports || {}; remote.comps = remote.comps || []; remote.kahf = remote.kahf || {};
      var merged = merge(state, remote);
      var changed = restChanged || !sameState(merged, state);
      state = merged;
      saveLocal();
      var needPush = !sameState(merged, remote);
      if (needPush) setDirty(true);
      if (cb) cb(true, changed);
    }, 12000);
  }
  function push(extra, cb) {
    var ss = getSession();
    if (!hasServer() || !ss) { if (cb) cb(false, null); return; }
    var payload = { action: "save", uid: ss.uid, token: ss.token, state: state };
    if (extra) for (var k in extra) if (extra.hasOwnProperty(k)) payload[k] = extra[k];
    http("POST", QT_CONFIG.SCRIPT_URL, JSON.stringify(payload), function (ok, data) {
      if (ok && data && data.ok === false && data.error === "auth") { authFail(); return; }
      if (ok && data && data.ok !== false) setDirty(false);
      if (cb) cb(ok, data);
    }, 15000);
  }
  // يعرض الصفحة فورًا من بيانات الجهاز، ثم يحدّث من الخادم في الخلفية.
  // cb: عند الجاهزية (فورًا) ، onSync(ok, changed): بعد المزامنة مع الخادم. بدون حساب يحوّل لصفحة الحساب.
  function applyConfig(c) {
    if (!c) return false;
    var v = c.newPlanStart || "", changed = (QT_CONFIG.NEW_PLAN_START || "") !== v;
    QT_CONFIG.NEW_PLAN_START = v;
    try { window.localStorage.setItem("qt_cfg", JSON.stringify(c)); } catch (e) {}
    return changed;
  }
  function init(cb, waitMs, onSync) {
    var ss = getSession();
    if (!ss) { goAccount(); return; }
    try { applyConfig(JSON.parse(window.localStorage.getItem("qt_cfg") || "null")); } catch (e0) {}
    setRest(ss.rest);
    state = loadLocal();
    if (cb) cb(state, false);
    if (!hasServer()) { if (onSync) onSync(false, false); return; }
    pull(function (ok, changed) {
      flushPending(); flushProfile();
      if (onSync) onSync(ok, changed);
    });
  }
  /* ---------- الحسابات ---------- */
  // رقم موبايل مصري: 11 رقمًا يبدأ بـ 010 أو 011 أو 012 أو 015 (يعود بصيغة 201xxxxxxxxx أو "" لو غير صحيح)
  function normPhone(p) {
    var d = normDigits(p || "").replace(/\D/g, "");
    if (d.indexOf("0020") === 0) d = d.substring(2);
    if (d.length === 12 && d.indexOf("20") === 0) d = "0" + d.substring(2);
    if (!/^01[0125]\d{8}$/.test(d)) return "";
    return "2" + d;
  }
  function authCall(payload, cb) {
    if (!hasServer()) { cb(false, { error: "رابط الخادم غير مضبوط." }); return; }
    http("POST", QT_CONFIG.SCRIPT_URL, JSON.stringify(payload), function (ok, data) {
      if (!ok || !data) { cb(false, { error: "تعذر الاتصال بالخادم. تأكد من الإنترنت وحاول مرة أخرى." }); return; }
      if (data.ok === false) { cb(false, data); return; }
      setSession({ uid: data.uid, token: data.token, name: data.profile.name, phone: data.profile.phone, guardian: data.profile.guardian, rest: data.profile.rest || [0, 3], reminders: data.profile.reminders || ["18:00", "22:00"], tasksStudent: data.profile.tasksStudent || ["06:00"], tasksGuardian: data.profile.tasksGuardian || ["06:00"] });
      setRest(data.profile.rest); applyConfig(data.config);
      state = loadLocal();
      if (data.state) { data.state.reports = data.state.reports || {}; data.state.comps = data.state.comps || []; data.state.kahf = data.state.kahf || {}; state = merge(state, data.state); }
      saveLocal();
      cb(true, data);
    }, 20000);
  }
  function register(o, cb) { o.action = "register"; authCall(o, cb); }
  function login(o, cb) { o.action = "login"; authCall(o, cb); }
  var SOFT = ["name", "guardian", "rest", "reminders", "tasksStudent", "tasksGuardian"];   // حقول تُطبَّق فورًا على الجهاز (بدون كلمة سر)
  function profKey() { var x = getSession(); return "qt_pp_" + (x ? x.uid : "anon"); }
  function canonList(a) { var o = [], seen = {}, i; for (i = 0; i < a.length; i++) { var k = String(a[i]); if (!seen[k]) { seen[k] = 1; o.push(k); } } return o.sort(); }
  function sameVal(a, b, field) {                         // مقارنة «ما طلبناه» بـ«ما ثبّته الخادم»: الخادم يوحّد شكل رقم الهاتف (2010...) ويرتّب المواعيد والأيام ويحذف المكرر، فلا نعتبر ذلك اختلافًا
    if (field === "guardian") { var x = a ? (normPhone(a) || String(a)) : "", y = b ? (normPhone(b) || String(b)) : ""; return x === y; }
    if (a && b && typeof a === "object" && typeof b === "object" && a.length !== undefined && b.length !== undefined) return JSON.stringify(canonList(a)) === JSON.stringify(canonList(b));
    return JSON.stringify(a) === JSON.stringify(b);
  }
  function getPP() { try { return JSON.parse(window.localStorage.getItem(profKey()) || "null"); } catch (e) { return null; } }
  function setPP(p) { try { if (p) window.localStorage.setItem(profKey(), JSON.stringify(p)); else window.localStorage.removeItem(profKey()); } catch (e) {} }
  // cb(ok, نتيجة|رسالة خطأ, meta)  — meta.verified = ثبّته الخادم وتأكدنا منه ، meta.pending = حُفظ على الجهاز وسيُرسل لاحقًا
  function api(o, cb, timeoutMs) {                       // طلب عام للخادم بحساب المشترك الحالي (يستعمله الاختبار)
    var ss = getSession();
    if (!ss) { goAccount(); return; }
    var payload = { uid: ss.uid, token: ss.token }, k;
    for (k in o) if (o.hasOwnProperty(k)) payload[k] = o[k];
    http("POST", QT_CONFIG.SCRIPT_URL, JSON.stringify(payload), function (ok, data) {
      if (ok && data && data.ok === false && data.error === "auth") { authFail(); return; }
      if (cb) cb(ok, data);
    }, timeoutMs || 20000);
  }
  function updateProfile(o, cb) {
    var ss = getSession();
    if (!ss) { goAccount(); return; }
    var prev = JSON.parse(JSON.stringify(ss)), i, soft = {}, hasSoft = false;
    for (i = 0; i < SOFT.length; i++) if (o.hasOwnProperty(SOFT[i])) { soft[SOFT[i]] = o[SOFT[i]]; hasSoft = true; }
    var sensitive = o.hasOwnProperty("phone") || o.hasOwnProperty("newPin");
    if (hasSoft && !sensitive) {                           // نُظهر التغيير فورًا
      for (var k in soft) if (soft.hasOwnProperty(k)) ss[k] = soft[k];
      setSession(ss); if (soft.rest) setRest(soft.rest);
    }
    var payload = { action: "profile", uid: ss.uid, token: ss.token };
    for (var key in o) if (o.hasOwnProperty(key)) payload[key] = o[key];
    http("POST", QT_CONFIG.SCRIPT_URL, JSON.stringify(payload), function (ok, data) {
      if (ok && data && data.ok === false && data.error === "auth") { authFail(); return; }
      if (ok && data && data.ok !== false && data.profile) {
        var bad = [];
        for (var f in soft) if (soft.hasOwnProperty(f) && !sameVal(soft[f], data.profile[f], f)) bad.push(f);
        var cur = getSession() || ss;
        cur.name = data.profile.name; cur.phone = data.profile.phone; cur.guardian = data.profile.guardian; cur.rest = data.profile.rest || [0, 3];
        cur.reminders = data.profile.reminders || ["18:00", "22:00"]; cur.tasksStudent = data.profile.tasksStudent || ["06:00"]; cur.tasksGuardian = data.profile.tasksGuardian || ["06:00"];
        setSession(cur); setRest(cur.rest);
        if (bad.length) { cb(false, "الخادم رجّع قيمة مختلفة عن المطلوبة (" + bad.join("، ") + "). حاول مرة أخرى."); return; }
        cb(true, data.profile, { verified: true });
        return;
      }
      if (ok && data && data.ok === false) {              // رفض الخادم (تحقق): نرجّع القيم القديمة
        setSession(prev); setRest(prev.rest);
        cb(false, data.error || "تعذر الحفظ.");
        return;
      }
      // لا اتصال: نبقي التغيير على الجهاز ونعيد الإرسال تلقائيًا لاحقًا (للحقول البسيطة فقط)
      if (hasSoft && !sensitive) { var pp = getPP() || {}; for (var q in soft) if (soft.hasOwnProperty(q)) pp[q] = soft[q]; setPP(pp); cb(true, getSession(), { pending: true }); }
      else { setSession(prev); cb(false, "تعذر الاتصال بالخادم. تأكد من الإنترنت ثم حاول مرة أخرى."); }
    }, 25000);
  }
  function flushProfile() {
    var pp = getPP(), ss = getSession();
    if (!pp || !ss) return;
    var payload = { action: "profile", uid: ss.uid, token: ss.token };
    for (var k in pp) if (pp.hasOwnProperty(k)) payload[k] = pp[k];
    http("POST", QT_CONFIG.SCRIPT_URL, JSON.stringify(payload), function (ok, data) { if (ok && data && data.ok !== false) setPP(null); else if (ok && data && data.ok === false && data.error !== "auth") setPP(null); }, 25000);
  }
  function resetRequest(phone, cb) {
    http("POST", QT_CONFIG.SCRIPT_URL, JSON.stringify({ action: "resetRequest", phone: phone }), function (ok, data) {
      if (!ok || !data) { cb(false, "تعذر الاتصال بالخادم."); return; }
      cb(data.ok !== false, data.ok === false ? data.error : (data.message || ""));
    }, 20000);
  }
  function resetConfirm(phone, code, pin, cb) {
    http("POST", QT_CONFIG.SCRIPT_URL, JSON.stringify({ action: "resetConfirm", phone: phone, code: code, pin: pin }), function (ok, data) {
      if (!ok || !data) { cb(false, "تعذر الاتصال بالخادم."); return; }
      cb(data.ok !== false, data.ok === false ? data.error : (data.message || ""));
    }, 20000);
  }
  /* منبهات التذكير: أول موعد إجباري والباقي اختياري (حتى 5) */
  function mountReminders(box, initial) {
    var list = (initial && initial.length) ? initial.slice() : ["18:00"];
    function draw() {
      var h = "", i;
      for (i = 0; i < list.length; i++) {
        h += '<div class="remrow"><input type="time" class="input remt" data-i="' + i + '" value="' + list[i] + '">' +
             (i > 0 ? '<button type="button" class="btn small red" data-del="' + i + '">حذف</button>' : '<span class="badge">إجباري</span>') + '</div>';
      }
      if (list.length < 5) h += '<button type="button" class="btn small" data-add="1" style="margin-top:6px">➕ إضافة منبه</button>';
      box.innerHTML = h;
    }
    box.oninput = function (ev) {
      ev = ev || window.event; var t = ev.target || ev.srcElement;
      if (t.className && t.className.indexOf("remt") > -1) list[Number(t.getAttribute("data-i"))] = t.value;
    };
    box.onclick = function (ev) {
      ev = ev || window.event; var t = ev.target || ev.srcElement;
      if (t.getAttribute && t.getAttribute("data-add")) { list.push("21:00"); draw(); }
      else if (t.getAttribute && t.getAttribute("data-del")) { list.splice(Number(t.getAttribute("data-del")), 1); draw(); }
    };
    draw();
    return { get: function () { return list.slice(); } };
  }
  /* زر إظهار/إخفاء كلمة السر (يلفّ كل حقل داخل .pwwrap) */
  function bindEyes() {
    var w = document.getElementsByClassName("pwwrap");
    for (var i = 0; i < w.length; i++) (function (box) {
      if (box.getAttribute("data-bound")) return; box.setAttribute("data-bound", "1");
      var inp = box.getElementsByTagName("input")[0], btn = box.getElementsByTagName("button")[0];
      if (!inp || !btn) return;
      btn.onclick = function () { var show = inp.type === "password"; inp.type = show ? "text" : "password"; btn.innerHTML = show ? "🙈" : "👁"; };
    })(w[i]);
  }
  function status(cb) {
    if (!hasServer()) { cb(false, null); return; }
    http("POST", QT_CONFIG.SCRIPT_URL, JSON.stringify({ action: "status" }), function (ok, data) { cb(ok && data && data.ok, data); }, 12000);
  }
  function onbKey() { var x = getSession(); return "qt_onb_" + (x ? x.uid : "anon"); }
  function onboardingDone() { try { return window.localStorage.getItem(onbKey()) === "1"; } catch (e) { return true; } }
  function setOnboardingDone() { try { window.localStorage.setItem(onbKey(), "1"); } catch (e) {} }
  function logout() { rememberPhone(); setSession(null); window.location.replace("account.html"); }
  function getState() { return state; }
  /* رسائل واتساب المعلّقة: تُحفظ محليًا حتى تصل للخادم (حتى لو أُغلقت الصفحة بسرعة) */
  function pendKey() { var x = getSession(); return "qt_pending_" + (x ? x.uid : "anon"); }
  function getPending() { try { return JSON.parse(window.localStorage.getItem(pendKey()) || "null"); } catch (e) { return null; } }
  function setPending(p) { try { if (p) window.localStorage.setItem(pendKey(), JSON.stringify(p)); else window.localStorage.removeItem(pendKey()); } catch (e) {} }
  function commit(extra, cb) {
    saveLocal(); setDirty(true);
    if (extra && extra.notify) { extra.reqId = extra.reqId || ((getSession() || {}).uid + "-" + new Date().getTime()); setPending(extra); }
    push(extra, function (ok, data) {
      if (ok && data && data.ok !== false && extra && extra.reqId) { var p = getPending(); if (p && p.reqId === extra.reqId) setPending(null); }
      if (cb) cb(ok, data);
    });
  }
  function flushPending() {
    var p = getPending();
    if (p) push(p, function (ok, data) { if (ok && data && data.ok !== false) { var q = getPending(); if (q && q.reqId === p.reqId) setPending(null); } });
    else if (isDirty()) push(null, null);
  }

  function setStart(d) {
    state.start = d; state.settingsAt = new Date().getTime();
    commit(null, null);
  }
  // نقطة الانطلاق: c = عدد أرباع الكنز التي أنهاها، v = آخر آية حفظها من المائدة، d = أيام الخطة القديمة التي عملها، from = أول يوم في الخطة الجديدة
  function setBase(c, v, d, from) {
    state.base = { c: c, v: v, d: d, at: new Date().getTime() };
    if (!state.prevStart && state.start && state.start !== from) state.prevStart = state.start;
    state.start = from; state.settingsAt = new Date().getTime();
    commit(null, null);
  }
  // عدد الأرباع في اليوم: يسري من اليوم لو لم يُرسَل تقرير اليوم، وإلا من بكرة (وقبل بداية الخطة يسري من بدايتها)
  function currentTpd() {
    var l = normTpd(state.tpd), t = todayStr(), q = 2, i;
    for (i = 0; i < l.length; i++) if (l[i].from <= t) q = l[i].q12 / 12;
    return q;
  }
  function setTpd(q) {
    q = Number(q); if (TPD_OPTIONS.indexOf(q) < 0) return false;
    var t = todayStr(), from = t, rep = state.reports && state.reports[t];
    if (rep && !rep.cancelled) from = addDays(t, 1);
    if (state.start && from < state.start) from = state.start;
    var keep = normTpd(state.tpd).filter(function (x) { return x.from < from; }).map(function (x) { return { from: x.from, q: x.q12 / 12 }; });
    keep.push({ from: from, q: q });
    state.tpd = keep; state.settingsAt = new Date().getTime();
    commit(null, null);
    return from;
  }
  function reportOf(st, date) { var r = st && st.reports ? st.reports[date] : null; return (r && !r.cancelled) ? r : null; }
  // يضيف سجل التقرير السابق (لو كان اليوم مُرسلًا من قبل) إلى التقرير الجديد حتى لا يضيع الإنجاز السابق
  function withHistory(date, rep) {
    var old = state && state.reports ? state.reports[date] : null, base = null;
    if (old && !old.cancelled) base = old; else if (old && old.cancelled && old.prev) base = old.prev;
    if (base) {
      var h = (base.hist || []).slice();
      h.push({ at: base.at, t: base.t, nw: base.nw, fx: base.fx });
      rep.hist = h.slice(-20);
    }
    return rep;
  }
  // إلغاء تقرير يوم: يصبح اليوم «تقريرًا لم يُملأ» ويُحفظ التقرير القديم داخل prev (لا يُمسح شيء)
  function cancelReport(date) {
    var old = state.reports[date];
    if (!old || old.cancelled) return false;
    state.reports[date] = { cancelled: true, at: new Date().getTime(), prev: old };
    commit(null, null);
    return true;
  }
  function putReport(date, rep, extra, cb) {
    rep.at = new Date().getTime();
    state.reports[date] = rep;
    commit(extra, null);
    if (cb) setTimeout(cb, 300);          // لا ننتظر الخادم: الإرسال يكمل في الخلفية ويُعاد تلقائيًا لو أُغلقت الصفحة
  }
  function putKahf(date, ok) {
    state.kahf[date] = { ok: !!ok, at: new Date().getTime() };
    commit(null, null);
  }
  function addComp(kind, ref, amt) {
    var id = "c" + new Date().getTime() + "x" + Math.floor(Math.random() * 1000);
    state.comps.push({ id: id, kind: kind, ref: ref, amt: amt || 0, date: todayStr(), at: new Date().getTime() });
    commit(null, null);
  }

  /* -------------------------------------------------------------------
     الحساب: يعيد بناء الخطة كلها من التقارير المسجلة (لا شيء يُخزَّن جاهزًا)
     ------------------------------------------------------------------- */
  function compute(st, today) {
    if (!st || !isYmd(st.start)) return null;
    today = today || todayStr();
    var M = { start: st.start, today: today, days: [], byDate: {}, tDef: [], nDef: [], fridays: [], finished: false };
    var comps = st.comps || [];

    function compsFor(kind, ref) {
      var r = [];
      for (var i = 0; i < comps.length; i++) if (comps[i].kind === kind && comps[i].ref === ref) r.push(comps[i]);
      r.sort(function (a, b) { return (a.date < b.date ? -1 : a.date > b.date ? 1 : (a.at || 0) - (b.at || 0)); });
      return r;
    }
    function dayComp(date) { var c = compsFor("day", date); return c.length ? c[0] : null; }

    function makeDef(kind, id, n, date, from, to, extra) {
      var closed = (kind === "n");
      var len = closed ? (to - from + 1) : (to - from);
      var cl = compsFor(kind, id), dc = dayComp(date), acc = 0, cleared = null, i;
      if (dc) { acc = len; cleared = dc.date; }
      else {
        for (i = 0; i < cl.length; i++) {
          acc += cl[i].amt;
          if (acc >= len && !cleared) cleared = cl[i].date;
        }
      }
      var done = Math.min(acc, len);
      var d = { id: id, kind: kind, n: n, date: date, from: from, to: to, len: len, done: done, rem: len - done,
                curFrom: from + done, clearedDate: cleared, comps: cl };
      if (extra) for (var k in extra) if (extra.hasOwnProperty(k)) d[k] = extra[k];
      return d;
    }

    var C = 0;                 // مؤشر الكنز (بالأجزاء)
    var tDays = 0, nDays = 0;  // عدد أيام الكنز والجديد التي مرّت (لمعرفة التأخر أو التقدم عن الخطة)
    var V = 0, nq = 0, ph = "A", newDone = false;     // مؤشر الجديد
    var qFinish = {};          // رقم الربع -> { n, def }
    var lastRev = {};          // رقم الربع -> رقم آخر يوم تثبيت
    var newStart = isYmd(QT_CONFIG.NEW_PLAN_START) ? QT_CONFIG.NEW_PLAN_START : "";
    var newMode = false, nDaysNew = 0, unitDone = {}, lastRevP = {};
    var date = st.start, n = 0, guard = 0;
    var TPD = normTpd(st.tpd), tpi = 0, dpd = DAY12, anchor = 0;     // معدل الكنز اليومي لهذا المشترك (الافتراضي ربعان)
    /* نقطة الانطلاق (يحدّدها المشترك): كم ربعًا أنهى في الكنز، وآخر آية حفظها في الجديد، وكم يومًا عمل بالخطة القديمة.
       تبدأ الحسابات منها مباشرة (فلا تكرار لمحفوظ ولا تخمين)، وترقيم الأيام يكمل من عدد أيامه القديمة. التقارير القديمة تبقى محفوظة كما هي. */
    var B = (st.base && typeof st.base === "object") ? st.base : null;
    if (B) {
      C = Math.max(0, Math.min(TOTAL12, Math.round((Number(B.c) || 0) * 12)));
      tDays = Math.floor(C / DAY12);
      V = Math.max(0, Math.min(120, Math.round(Number(B.v) || 0)));
      n = Math.max(0, Math.round(Number(B.d) || 0));
      while (nDays + 1 < PM.length && cumM(nDays + 1) <= V) nDays++;
      for (var bq = 0; bq < 9; bq++) if (V >= MAIDA[bq].e) qFinish[MAIDA[bq].q] = { n: -1000 + bq, def: null };
    }

    function normNew() {
      if (newDone) return;
      if (newMode) { if (V >= NEW_LAST) newDone = true; return; }
      while (nq < 9 && V >= MAIDA[nq].e) { nq++; ph = "A"; }
      if (nq >= 9) newDone = true;
    }

    while (guard++ < 900) {
      normNew();
      if (C >= TOTAL12 && newDone) { M.finished = true; break; }
      var dw = dowOf(date);
      if (REST[dw]) { date = addDays(date, 1); continue; }     // يوم راحة: لا مهام
      if (dw === 5) {                                   // الجمعة
        var fr = { date: date, isFriday: true, kahf: st.kahf[date] || null,
                   status: (st.kahf[date] ? (st.kahf[date].ok ? "done" : "missed") : (date < today ? "none" : (date === today ? "today" : "future"))) };
        M.fridays.push(fr); M.days.push(fr); M.byDate[date] = fr;
        date = addDays(date, 1); continue;
      }
      n++;
      var rep = st.reports[date] || null;
      if (rep && rep.cancelled) rep = null;                 // تقرير أُلغي: يُعامل كأنه لم يُرسل (ويُحفظ القديم داخل prev)
      var mode = rep ? "rep" : (date < today ? "miss" : "proj");
      var day = { n: n, date: date, isFriday: false, report: rep, mode: mode, t: null, nw: null, fx: null };

      /* ---- الكنز: المعدل اليومي (افتراضيًا ربعان، ويختاره كل مشترك). ما لم يُنجَز يُرحَّل لليوم التالي (تزيد مدة الخطة)، وما زاد يقلّل المطلوب ---- */
      while (tpi < TPD.length && date >= TPD[tpi].from) {              // تغيير المعدل يسري من تاريخه فقط؛ الأيام السابقة لا تتغير
        if (TPD[tpi].q12 === DAY12) { dpd = DAY12; anchor = 0; tDays = Math.floor(C / DAY12); }
        else { dpd = TPD[tpi].q12; anchor = C; tDays = 0; }
        tpi++;
      }
      if (C < TOTAL12) {
        var slackT = C - (anchor + dpd * tDays);                          // سالب = متأخر عن الخطة ، غير سالب = في الموعد أو متقدم
        var req = (slackT < 0) ? dpd : (dpd - ((C - anchor) % dpd));
        req = Math.min(req, TOTAL12 - C);
        var T = { from: C, req: req, to: C + req, extra: 0, def: null, st: "full" };
        var tst = mode === "rep" ? ((rep.t && rep.t.st) || "full") : (mode === "miss" ? "none" : "full");
        var tam = (mode === "rep" && rep.t) ? (rep.t.amt || 0) : 0;
        if (tst === "partial" && (tam <= 0)) tst = "none";
        if (tst === "partial" && tam >= req) tst = "full";
        if (tst === "extra" && tam <= 0) tst = "full";
        var adv = req;
        if (tst === "none") adv = 0;
        else if (tst === "partial") adv = tam;
        else if (tst === "extra") { T.extra = Math.min(tam, TOTAL12 - (C + req)); adv = req + T.extra; }
        T.st = tst; T.am = tam;
        T.segs = segsOf(C, C + req);
        C = C + adv;
        tDays++;
        day.t = T;
      }

      /* ---- الجديد (بالآيات): نفس القاعدة — الباقي يُرحَّل ويكمل الربع، ولا يُقطع جزء ويُرمى في الجمعة ---- */
      // الانتقال لخطة الجديد للترم الأول: من هذا اليوم يُحسب لكل مشترك آخر آية حفظها فعلًا ويُكمل من بعدها
      if (!newMode && newStart && date >= newStart) {
        newMode = true;
        nDaysNew = unitsCovered(V);                                      // الأيام التي تجاوزها في الخطة الجديدة تُطرح من الـ25
        for (var uk = 1; uk <= nDaysNew; uk++) unitDone[uk] = -1000 + uk;    // محفوظ قبل الانتقال (للتثبيت)
        newDone = (V >= NEW_LAST);
      }
      normNew();
      if (!newDone) {
        var Q, uend, usize, aheadN, rf, rt, Nw;
        if (newMode) {
          var U = unitAt(V + 1);
          aheadN = (V >= cumNU(nDaysNew));                               // في الموعد أو متقدم عن الخطة؟
          rf = V + 1; rt = aheadN ? U.e : Math.min(V + U.size, NEW_LAST);
          Nw = { q: U.k, ph: "P", plan: true, k: U.k, from: rf, to: rt, cnt: rt - rf + 1, st: "full", def: null, qi: { q: U.k, s: U.s, e: U.e, ph: "" }, newV: V, to2: null };
        } else {
        Q = MAIDA[nq];
        var inA = (V + 1 <= Q.mid);
        uend = inA ? Q.mid : Q.e; usize = inA ? (Q.mid - Q.s + 1) : (Q.e - Q.mid);
        aheadN = (V >= cumM(nDays));                                      // في الموعد أو متقدم؟
        ph = inA ? "A" : "B";
        rf = V + 1; rt = aheadN ? uend : Math.min(V + usize, Q.e);
        Nw = { q: Q.q, ph: ph, from: rf, to: rt, cnt: rt - rf + 1, st: "full", def: null, qi: Q, newV: V, to2: null };
        }
        var nst = mode === "rep" ? ((rep.nw && rep.nw.st) || "full") : (mode === "miss" ? "none" : "full");
        var nto = (mode === "rep" && rep.nw && rep.nw.to !== undefined && rep.nw.to !== null && rep.nw.to !== "") ? Number(rep.nw.to) : null;
        var newV = V;
        if (nst === "full") newV = rt;
        else if (nst === "none") newV = V;
        else {
          if (nto === null || isNaN(nto)) newV = (nst === "extra") ? rt : V;
          else newV = nto;
          if (newV < V) newV = V;
          if (nst === "partial") { if (newV >= rt) nst = "full"; else if (newV <= V) nst = "none"; }
          if (nst === "extra") { if (newV <= rt) { nst = "full"; newV = rt; } }
          if (nst === "full") newV = Math.max(newV, rt);
          if (newV > (newMode ? NEW_LAST : 120)) newV = (newMode ? NEW_LAST : 120);
        }
        Nw.st = nst; Nw.to2 = newV;
        V = newV;
        if (newMode) {
          nDaysNew++;
          for (var uu = 1; uu <= NU.length; uu++) if (NU[uu - 1].e <= V && unitDone[uu] === undefined) unitDone[uu] = n;      // اليوم الذي اكتملت فيه كل وحدة
        } else {
          nDays++;
          // تسجيل الأرباع التي انتهى حفظها
          for (var qi = 0; qi < 9; qi++) {
            if (V >= MAIDA[qi].e && !qFinish[MAIDA[qi].q]) qFinish[MAIDA[qi].q] = { n: n, def: null };
          }
        }
        day.nw = Nw;
      }

      /* ---- التثبيت ---- */
      var cand = [], qk;
      if (newMode) {
        /* صفحات التثبيت (كل صفحة = يومان من الخطة): حسب ما حُفظ فعلًا، بحد أقصى صفحتين يوميًا والأفضل صفحة، مع أولوية للجديد وعدم تراكم المراجعة */
        var cuB = 0, ku;
        for (ku = 1; ku <= NU.length; ku++) { if (unitDone[ku] !== undefined && unitDone[ku] < n) cuB = ku; else break; }
        var nPages = Math.ceil(cuB / 2);
        if (nPages > 0) {
          var perDay = Math.min(nPages <= 7 ? 1 : 2, nPages), pitems = [], pp;
          for (pp = 1; pp <= nPages; pp++) {
            var newest = -100000;
            for (ku = 2 * pp - 1; ku <= Math.min(2 * pp, cuB); ku++) if (unitDone[ku] > newest) newest = unitDone[ku];
            var lr = (lastRevP[pp] !== undefined) ? lastRevP[pp] : -1;
            pitems.push({ p: pp, newest: newest, lr: lr, needNew: newest > lr });
          }
          pitems.sort(function (a, b) {
            if (a.needNew !== b.needNew) return a.needNew ? -1 : 1;                 // الجديد غير المُثبَّت أولًا
            if (a.needNew) return b.newest - a.newest;                              // الأحدث أولًا
            return a.lr !== b.lr ? a.lr - b.lr : a.p - b.p;                         // ثم الأقدم مراجعة (حتى لا تتراكم)
          });
          var chosen = pitems.slice(0, perDay).map(function (x) { return x.p; }).sort(function (a, b) { return a - b; });
          var fstP = mode === "rep" ? ((rep.fx && rep.fx.st) || "done") : (mode === "miss" ? "none" : "done");
          if (fstP !== "done" && fstP !== "none") fstP = "done";
          var fitems = [];
          for (pp = 0; pp < chosen.length; pp++) {
            var sp = pageSpan(chosen[pp]), lastK = Math.min(2 * chosen[pp], cuB);
            fitems.push({ p: chosen[pp], s: sp.s, e: Math.min(sp.e, NU[lastK - 1].e) });
          }
          day.fx = { mode: "pages", pages: chosen, items: fitems, qs: [], st: fstP };
          if (fstP === "done") for (pp = 0; pp < chosen.length; pp++) lastRevP[chosen[pp]] = n;
        }
        cand = [];
      } else
      for (qk = 1; qk <= 9; qk++) {
        var fq = qFinish[qk];
        if (!fq || fq.n >= n) continue;
        if (fq.def && !(fq.def.clearedDate && fq.def.clearedDate < date)) continue;
        cand.push(qk);
      }
      if (!newMode && cand.length) {
        cand.sort(function (a, b) {
          var la = (lastRev[a] !== undefined) ? lastRev[a] : (-1000 + qFinish[a].n);
          var lb = (lastRev[b] !== undefined) ? lastRev[b] : (-1000 + qFinish[b].n);
          return la !== lb ? la - lb : a - b;
        });
        var pick = cand.slice(0, Math.min(QT_CONFIG.FIX_PER_DAY, cand.length)).sort(function (a, b) { return a - b; });
        var fst = mode === "rep" ? ((rep.fx && rep.fx.st) || "done") : (mode === "miss" ? "none" : "done");
        if (fst !== "done" && fst !== "none") fst = "done";
        day.fx = { qs: pick, st: fst };
        if (fst === "done") for (var pi = 0; pi < pick.length; pi++) lastRev[pick[pi]] = n;
      }

      /* ---- حالة اليوم ---- */
      var secs = [];
      if (day.t) secs.push(day.t.st);
      if (day.nw) secs.push(day.nw.st);
      if (day.fx) secs.push(day.fx.st === "done" ? "full" : "none");
      var allNone = secs.length > 0, k2;
      for (k2 = 0; k2 < secs.length; k2++) if (secs[k2] !== "none") allNone = false;
      if (mode === "rep") day.status = allNone ? "missed" : "done";
      else if (mode === "miss") day.status = "missed";
      else day.status = (date === today) ? "today" : "future";
      day.comp = dayComp(date);
      if (day.status === "missed" && day.comp) day.status = "compensated";

      M.days.push(day); M.byDate[date] = day;
      date = addDays(date, 1);
    }

    /* ---- ملخصات ---- */
    var workDays = 0, i, d;
    for (i = 0; i < M.days.length; i++) if (!M.days[i].isFriday) workDays++;
    M.totalDays = workDays;                       // مدة الخطة بأيام الحفظ
    M.treasureDays = 0; M.newDays = 0;
    for (i = 0; i < M.days.length; i++) {
      d = M.days[i];
      if (d.isFriday) continue;
      if (d.t) M.treasureDays++;
      if (d.nw) M.newDays++;
    }
    M.endDate = M.days.length ? M.days[M.days.length - 1].date : st.start;
    M.qFinish = qFinish; M.newMode = newMode; M.newPlanStart = newStart;
    M.V = V; M.C = C;
    M.doneDays = 0; M.missedDays = []; 
    for (i = 0; i < M.days.length; i++) {
      d = M.days[i];
      if (d.isFriday) continue;
      if (d.status === "done" || d.status === "compensated") M.doneDays++;
      if (d.status === "missed") M.missedDays.push(d);
    }
    M.tDefOpen = []; M.nDefOpen = [];
    for (i = 0; i < M.tDef.length; i++) if (M.tDef[i].rem > 0) M.tDefOpen.push(M.tDef[i]);
    for (i = 0; i < M.nDef.length; i++) if (M.nDef[i].rem > 0) M.nDefOpen.push(M.nDef[i]);
    M.tDefTotal = 0; for (i = 0; i < M.tDefOpen.length; i++) M.tDefTotal += M.tDefOpen[i].rem;
    M.nDefTotal = 0; for (i = 0; i < M.nDefOpen.length; i++) M.nDefTotal += M.nDefOpen[i].rem;
    return M;
  }

  /* اليوم الفعلي لتاريخ ما (هل هو يوم حفظ أم جمعة أم قبل البداية) */
  function dayFor(M, date) { return M && M.byDate ? (M.byDate[date] || null) : null; }

  /* ترتيب الأيام المتتالية */
  function streak(M, today) {
    if (!M) return 0;
    var i, list = [];
    for (i = 0; i < M.days.length; i++) if (!M.days[i].isFriday && M.days[i].date <= today) list.push(M.days[i]);
    var s = 0;
    for (i = list.length - 1; i >= 0; i--) {
      var d = list[i];
      if (d.date === today && d.status === "today") continue;     // اليوم لم يُرسل بعد
      if (d.status === "done" || d.status === "compensated") s++; else break;
    }
    return s;
  }

  /* حالة سورة: متى يبدأ حفظها ومتى ينتهي (من الخطة الفعلية) */
  function surahTimeline(M) {
    var info = {};                // اسم السورة -> {first:day, last:day, finishedAll:bool}
    if (!M) return info;
    var i, j, p, d, nm;
    for (i = 0; i < M.days.length; i++) {
      d = M.days[i];
      if (d.isFriday) continue;
      if (d.t) {
        for (j = 0; j < d.t.segs.length; j++) {
          var parts = d.t.segs[j].info.parts;
          for (p = 0; p < parts.length; p++) {
            nm = parts[p][0];
            if (!info[nm]) info[nm] = { first: d, last: d, kind: "كنز" };
            info[nm].last = d;
          }
        }
      }
      if (d.nw) {
        nm = "المائدة";
        if (!info[nm]) info[nm] = { first: d, last: d, kind: "جديد" };
        info[nm].last = d;
      }
    }
    return info;
  }

  /* -------------------------------------------------------------------
     نصوص التقرير
     ------------------------------------------------------------------- */
  var ST_AR = { full: "تم بالكامل", extra: "تم وزيادة", partial: "جزئي", none: "لم يتم", done: "تم" };
  var ST_ICON = { full: "✅", extra: "➕", partial: "🟡", none: "❌", done: "✅" };

  // عناصر التثبيت لليوم بصيغة موحّدة (ربع قديم أو صفحة في الخطة الجديدة)
  function fxItems(d) {
    var out = [], i;
    if (!d || !d.fx) return out;
    if (d.fx.mode === "pages") { for (i = 0; i < d.fx.items.length; i++) out.push({ label: "صفحة " + d.fx.items[i].p, s: d.fx.items[i].s, e: d.fx.items[i].e, ph: "" }); }
    else for (i = 0; i < d.fx.qs.length; i++) { var Q = MAIDA[d.fx.qs[i] - 1]; out.push({ label: "ربع " + Q.q, s: Q.s, e: Q.e, ph: Q.ph }); }
    return out;
  }
  function fxText(d) {
    var it = fxItems(d), a = [];
    for (var i = 0; i < it.length; i++) a.push(it[i].label + " (آيات " + it[i].s + "–" + it[i].e + ")");
    return a.join(" + ");
  }
  function tSummary(d) {
    if (!d.t) return "";
    var s = ST_ICON[d.t.st] + " " + ST_AR[d.t.st];
    if (d.t.st === "extra") s += " (زيادة " + fmtU(d.t.extra) + " ربع)";
    if (d.t.st === "partial") s += " (حفظت " + fmtU(d.t.am) + " من " + fmtU(d.t.req) + ")";
    if (d.t.st === "none") s += " (" + fmtU(d.t.req) + " ربع في الكنز الناقص)";
    return s;
  }
  function nSummary(d) {
    if (!d.nw) return "";
    var n = d.nw;
    var s = ST_ICON[n.st] + " " + ST_AR[n.st];
    if (n.st === "extra") s += " (إلى آية " + n.to2 + " — زيادة " + (n.to2 - n.to) + ")";
    if (n.st === "partial") s += " (حفظت إلى آية " + n.to2 + " من " + n.from + "–" + n.to + ")";
    if (n.def) s += " — الناقص: " + n.def.from + "–" + n.def.to;
    return s;
  }
  function fSummary(d) {
    if (!d.fx) return "";
    return ST_ICON[d.fx.st] + " " + ST_AR[d.fx.st];
  }
  function todayTasksText(d) {
    var lines = [];
    if (d.nw) lines.push("📖 الجديد (المائدة): من آية " + d.nw.from + " إلى آية " + d.nw.to);
    if (d.t) {
      var ss = [];
      for (var i = 0; i < d.t.segs.length; i++) ss.push(segLabel(d.t.segs[i]) + " — " + d.t.segs[i].info.title);
      lines.push("💎 الكنز: " + ss.join(" + "));
    }
    if (d.fx) lines.push("🔄 التثبيت: " + fxText(d) + " من المائدة");
    return lines.join("\n");
  }
  function reportText(M, d) {
    var lines = ["📋 تقرير حفظ اليوم " + d.n + " — " + prettyDate(d.date)];
    if (d.t) lines.push("💎 الكنز: " + tSummary(d));
    if (d.nw) lines.push("📖 الجديد: " + nSummary(d));
    if (d.fx) lines.push("🔄 التثبيت: " + fSummary(d));
    if (M) {
      lines.push("—");
      lines.push("مدة الخطة الحالية: " + M.totalDays + " يوم · تنتهي " + shortDate(M.endDate));
      if (M.tDefTotal > 0) lines.push("الكنز الناقص: " + fmtU(M.tDefTotal) + " ربع");
      if (M.nDefTotal > 0) lines.push("الجديد الناقص: " + M.nDefTotal + " آية");
    }
    return lines.join("\n");
  }

  /* -------------------------------------------------------------------
     التحقق من صحة التقرير قبل الإرسال
     form = { t:{st,amtText}, nw:{st,toText}, fx:{st} }
     يعيد { ok, errors:[...], report }
     ------------------------------------------------------------------- */
  function buildReport(day, form) {
    var errors = [], rep = { v: 2 }, v;
    if (day.t) {
      var ts = form.t && form.t.st;
      if (!ts) errors.push("اختر حالة الكنز.");
      else {
        rep.t = { st: ts, amt: 0 };
        if (ts === "extra" || ts === "partial") {
          v = parseU(form.t.amtText);
          if (v === null || v <= 0) errors.push(ts === "extra" ? "اكتب مقدار الزيادة في الكنز (مثل ½ أو 1 أو 2)." : "اكتب مقدار ما حفظته في الكنز (مثل 1 أو 1½).");
          else if (ts === "partial" && v >= day.t.req) errors.push("في الجزئي لازم يكون المقدار أقل من المطلوب (" + fmtU(day.t.req) + ").");
          else if (ts === "extra" && v > 48) errors.push("أقصى زيادة في الكنز 4 أرباع.");
          else rep.t.amt = v;
        }
      }
    }
    if (day.nw) {
      var ns = form.nw && form.nw.st;
      if (!ns) errors.push("اختر حالة الجديد.");
      else {
        rep.nw = { st: ns, to: null };
        if (ns === "extra" || ns === "partial") {
          var tv = parseInt(normDigits(form.nw.toText || ""), 10);
          if (isNaN(tv)) errors.push(ns === "extra" ? "اكتب آخر آية وصلت لها في الجديد (بعد آية " + day.nw.to + ")." : "اكتب آخر آية حفظتها في الجديد (من آية " + day.nw.from + ").");
          else if (ns === "partial" && (tv < day.nw.from || tv >= day.nw.to)) errors.push("في الجزئي لازم تكون الآية بين " + day.nw.from + " و " + (day.nw.to - 1) + ".");
          else if (ns === "extra" && (tv <= day.nw.to || tv > (day.nw.plan ? NEW_LAST : 120))) errors.push("في الزيادة لازم تكون الآية أكبر من " + day.nw.to + " وحتى " + (day.nw.plan ? NEW_LAST : 120) + ".");
          else rep.nw.to = tv;
        }
      }
    }
    if (day.fx) {
      var fs = form.fx && form.fx.st;
      if (!fs) errors.push("اختر حالة التثبيت (تم / لم يتم).");
      else rep.fx = { st: fs };
    }
    rep.day = form.day || "";
    return { ok: errors.length === 0, errors: errors, report: rep };
  }

  /* -------------------------------------------------------------------
     إحصاءات أسبوعية/شهرية للصفحة التشجيعية
     ------------------------------------------------------------------- */
  function weekStats(M, anyDate) {
    var ws = weekStart(anyDate), we = addDays(ws, 5);   // السبت..الخميس
    var o = { from: ws, to: we, missed: 0, tExtra: 0, tLess: 0, nExtra: 0, nLess: 0, days: 0, done: 0 };
    if (!M) return o;
    for (var i = 0; i < M.days.length; i++) {
      var d = M.days[i];
      if (d.isFriday || d.date < ws || d.date > we) continue;
      if (d.status === "today" || d.status === "future") continue;
      o.days++;
      if (d.status === "missed") o.missed++; else o.done++;
      if (d.mode !== "rep" && d.mode !== "miss") continue;
      if (d.t) { if (d.t.st === "extra") o.tExtra++; if (d.t.st === "partial" || d.t.st === "none") o.tLess++; }
      if (d.nw) { if (d.nw.st === "extra") o.nExtra++; if (d.nw.st === "partial" || d.nw.st === "none") o.nLess++; }
    }
    return o;
  }
  function monthStats(M, anyDate) {
    var ym = String(anyDate).slice(0, 7);
    var o = { ym: ym, missed: 0, days: 0 };
    if (!M) return o;
    for (var i = 0; i < M.days.length; i++) {
      var d = M.days[i];
      if (d.isFriday || String(d.date).slice(0, 7) !== ym) continue;
      if (d.status === "today" || d.status === "future") continue;
      o.days++;
      if (d.status === "missed") o.missed++;
    }
    return o;
  }

  /* -------------------------------------------------------------------
     كلمات التشجيع
     ------------------------------------------------------------------- */
  /* ---------- أوسمة الإنجاز ---------- */
  function bestStreak(M) {
    if (!M) return 0;
    var best = 0, cur = 0, i;
    for (i = 0; i < M.days.length; i++) {
      var d = M.days[i];
      if (d.isFriday || d.status === "future" || d.status === "today") continue;
      if (d.status === "done" || d.status === "compensated") { cur++; if (cur > best) best = cur; } else cur = 0;
    }
    return best;
  }
  function badges(M) {
    var out = [], best = bestStreak(M), done = M ? M.doneDays : 0, total = M ? Math.max(1, M.totalDays) : 1, pct = done / total * 100, extra = 0, i;
    if (M) for (i = 0; i < M.days.length; i++) { var d = M.days[i]; if (!d.isFriday && d.mode === "rep" && ((d.t && d.t.st === "extra") || (d.nw && d.nw.st === "extra"))) extra++; }
    out.push({ icon: "🌱", title: "البداية", desc: "أول تقرير", got: done >= 1 });
    out.push({ icon: "🔥", title: "3 أيام", desc: "3 أيام متتالية", got: best >= 3 });
    out.push({ icon: "⭐", title: "أسبوع", desc: "7 أيام متتالية", got: best >= 7 });
    out.push({ icon: "🏅", title: "14 يومًا", desc: "14 يومًا متتالية", got: best >= 14 });
    out.push({ icon: "👑", title: "30 يومًا", desc: "30 يومًا متتالية", got: best >= 30 });
    out.push({ icon: "🚀", title: "المجتهد", desc: "زيادة في الحفظ", got: extra >= 1 });
    out.push({ icon: "📈", title: "ربع الخطة", desc: "25% من الخطة", got: pct >= 25 });
    out.push({ icon: "🌓", title: "نصف الخطة", desc: "50% من الخطة", got: pct >= 50 });
    out.push({ icon: "🎓", title: "الختام", desc: "إتمام الخطة", got: pct >= 100 });
    return out;
  }

  /* سطر واحد بتفاصيل التقرير (لقالب ولي الأمر؛ القوالب لا تقبل أسطرًا جديدة) */
  function guardianDetail(d) {
    var parts = [], i;
    if (d.t) {
      var ss = [];
      for (i = 0; i < d.t.segs.length; i++) { var sg = d.t.segs[i]; ss.push("ربع " + sg.u + " (" + sg.info.title + (sg.info.ayat ? " " + sg.info.ayat : "") + ")"); }
      var ts = ST_AR[d.t.st];
      if (d.t.st === "extra") ts += " (زيادة " + fmtRaw(d.t.extra) + " ربع)";
      if (d.t.st === "partial") ts += " (حفظ " + fmtRaw(d.t.am) + " ربع)";
      parts.push("الكنز: " + ss.join(" + ") + " — " + ts);
    }
    if (d.nw) {
      var ns = ST_AR[d.nw.st];
      if (d.nw.st === "extra" || d.nw.st === "partial") ns += " (إلى آية " + d.nw.to2 + ")";
      parts.push("الجديد: سورة المائدة، الآيات " + d.nw.from + "–" + d.nw.to + " — " + ns);
    }
    if (d.fx) parts.push("التثبيت: مراجعة " + fxText(d) + " من المائدة — " + (d.fx.st === "done" ? "تمت المراجعة" : "لم تتم المراجعة"));
    return parts.join(" | ");
  }

  function pick(a, seed) { return a[Math.abs(seed) % a.length]; }
  function encourage(d) {
    var seed = d ? d.n : 0, good = [], bad = [];
    var msgs = {
      great: ["ما شاء الله! يوم ممتاز وزيادة، بارك الله فيك 🌟", "إنجاز رائع! كل خطوة تقرّبك من ختم الحفظ بإذن الله 💪", "أحسنت! الزيادة اليوم تختصر عليك من الخطة 🌿"],
      good: ["أحسنت! أتممت يومك كما خططت، استمر 🌱", "ما شاء الله، يوم موفّق. حافظ على هذا الثبات 💚", "بارك الله فيك! خطوة جديدة في طريق الحفظ ✨"],
      some: ["بداية طيبة، وما نقص اليوم تقدر تعوّضه يوم الجمعة بإذن الله 🤍", "لا بأس، المهم الاستمرار. غدًا يوم جديد، وكن قدوة لنفسك 🌅", "أنجزت جزءًا اليوم، والنقص محفوظ لك لتعوّضه، لا تتوقف 💫"],
      none: ["ابدأ من جديد اليوم، أول خطوة هي الأصعب والله معك 🌙", "يوم فاتك؟ لا تحزن، نيّتك طيبة والخطة تنتظرك. يلا ابدأ! 💪", "كن قدوة لنفسك: خطوة صغيرة الآن أفضل من لا شيء 🌿"]
    };
    if (!d || !d.report && d.status !== "done") return pick(msgs.none, seed);
    var st = d.status;
    if (st === "missed" || st === "compensated") return pick(st === "compensated" ? msgs.good : msgs.none, seed);
    var extra = (d.t && d.t.st === "extra") || (d.nw && d.nw.st === "extra");
    var less = (d.t && (d.t.st === "partial" || d.t.st === "none")) || (d.nw && (d.nw.st === "partial" || d.nw.st === "none")) || (d.fx && d.fx.st === "none");
    if (less) return pick(msgs.some, seed);
    if (extra) return pick(msgs.great, seed);
    return pick(msgs.good, seed);
  }

  /* -------------------------------------------------------------------
     تاريخ اليوم الافتراضي للتقرير (بعد منتصف الليل وحتى 4 فجرًا يُعتبر اليوم السابق إن لم يُرسل)
     ------------------------------------------------------------------- */
  function defaultReportDate() {
    var now = new Date(), t = ymd(now);
    if (now.getHours() < 4) {
      var y = addDays(t, -1);
      if (state && !reportOf(state, y) && dowOf(y) !== 5 && !isRest(y) && state.start && y >= state.start) return y;
    }
    return t;
  }

  /* -------------------------------------------------------------------
     واجهة عامة صغيرة
     ------------------------------------------------------------------- */
  function toast(msg, kind) {
    var el = document.getElementById("qtToast");
    if (!el) {
      el = document.createElement("div"); el.id = "qtToast"; el.className = "toast";
      document.body.appendChild(el);
    }
    el.className = "toast show " + (kind || "");
    el.innerHTML = esc(msg);
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { el.className = "toast " + (kind || ""); }, 3200);
  }

  function applyTheme() {
    try {
      if (window.localStorage.getItem("darkMode") === "true") document.body.className += " dark";
    } catch (e) {}
    try {                       // رقم الدعم أسفل كل صفحة
      if (!document.getElementById("qtSupport") && QT_CONFIG.SUPPORT_PHONE) {
        var p = QT_CONFIG.SUPPORT_PHONE, local = "0" + p.substring(2);
        var f = document.createElement("div"); f.id = "qtSupport"; f.className = "support";
        f.innerHTML = '🤝 للدعم والاستفسار: <a href="https://wa.me/' + p + '" target="_blank" rel="noopener" style="direction:ltr;unicode-bidi:embed;font-weight:700">' + local + '</a>';
        document.body.appendChild(f);
      }
    } catch (e) {}
  }
  function bindThemeButton(id) {
    var b = document.getElementById(id);
    if (!b) return;
    function label() { b.innerHTML = /(^| )dark( |$)/.test(document.body.className) ? "☀️ الوضع النهاري" : "🌙 الوضع الليلي"; }
    label();
    b.onclick = function () {
      var has = /(^| )dark( |$)/.test(document.body.className);
      if (has) document.body.className = document.body.className.replace(/(^| )dark( |$)/g, " ");
      else document.body.className += " dark";
      try { window.localStorage.setItem("darkMode", has ? "false" : "true"); } catch (e) {}
      label();
    };
  }

  setRest((getSession() || {}).rest);

  return {
    SURAHS: SURAHS, SLOTS: SLOTS, MAIDA: MAIDA, UNITS: UNITS, TOTAL12: TOTAL12,
    esc: esc, ymd: ymd, parseYmd: parseYmd, addDays: addDays, dowOf: dowOf, todayStr: todayStr, isYmd: isYmd,
    prettyDate: prettyDate, shortDate: shortDate, weekStart: weekStart, getParam: getParam, DAYNAMES: DAYNAMES, MONTHS: MONTHS,
    isRest: isRest, fmtU: fmtU, fmtRaw: fmtRaw, parseU: parseU, normDigits: normDigits,
    NEW_LAST_FOR: function (nw) { return nw && nw.plan ? NEW_LAST : 120; },
    fxItems: fxItems, fxText: fxText, NU: NU, NEW_LAST: NEW_LAST, unitInfo: unitInfo, segsOf: segsOf, segLabel: segLabel, segFull: segFull, partText: partText,
    init: init, pull: pull, push: push, getState: getState, setStart: setStart, setBase: setBase, setTpd: setTpd, currentTpd: currentTpd, tpdLabel: tpdLabel, TPD_OPTIONS: TPD_OPTIONS, putReport: putReport, putKahf: putKahf, addComp: addComp,
    emptyState: emptyState, merge: merge, hasServer: hasServer,
    compute: compute, dayFor: dayFor, streak: streak, surahTimeline: surahTimeline,
    ST_AR: ST_AR, ST_ICON: ST_ICON, tSummary: tSummary, nSummary: nSummary, fSummary: fSummary,
    todayTasksText: todayTasksText, reportText: reportText, buildReport: buildReport,
    weekStats: weekStats, monthStats: monthStats, encourage: encourage, defaultReportDate: defaultReportDate,
    resetRequest: resetRequest, resetConfirm: resetConfirm, mountReminders: mountReminders, bindEyes: bindEyes,
    reportOf: reportOf, withHistory: withHistory, cancelReport: cancelReport,
    setRest: setRest, rest: getRestArr, status: status, onboardingDone: onboardingDone, setOnboardingDone: setOnboardingDone,
    badges: badges, guardianDetail: guardianDetail, bestStreak: bestStreak,
    api: api, session: getSession, register: register, login: login, updateProfile: updateProfile, logout: logout, normPhone: normPhone,
    toast: toast, applyTheme: applyTheme, bindThemeButton: bindThemeButton,
    _setState: function (s) { state = s; }
  };
})();

/* =====================================================================
   واجهة التعويض (الأيام الناقصة + الكنز الناقص + الجديد الناقص)
   تظهر في صفحة الخطة وفي تقرير الجمعة. التعويض نفسه مسموح يوم الجمعة فقط.
   ===================================================================== */
QT.renderComp = function (box, M, enabled, onChange) {
  var esc = QT.esc, html = "", i, j;
  function note(t) { return '<p class="muted">' + t + '</p>'; }

  if (!M) { box.innerHTML = note("حدّد تاريخ بداية الخطة أولًا."); return; }
  if (!enabled) html += '<div class="err" style="background:#fff1d6;color:#8a5e00">🔒 التعويض متاح يوم الجمعة فقط. تقدر تشوف النواقص هنا فقط.</div>';

  /* ---- الأيام الناقصة ---- */
  html += '<h3>⚠️ الأيام الناقصة (' + M.missedDays.length + ')</h3>';
  if (!M.missedDays.length) html += note("لا توجد أيام ناقصة 👏");
  for (i = 0; i < M.missedDays.length; i++) {
    var md = M.missedDays[i];
    html += '<div class="dayline missed"><div class="meta"><div class="title">اليوم ' + md.n + ' — ' + QT.prettyDate(md.date) + '</div>' +
            '<div class="sub">لم يتم فيه شيء. عند التعويض يرجع لمكانه في الأيام المكتملة ويظل مرتبطًا بتاريخه.</div></div>' +
            (enabled ? '<button class="btn small" data-act="day" data-ref="' + md.date + '">تم تعويضه بالكامل</button>' : '') + '</div>';
  }

  /* ---- الكنز الناقص ---- */
  html += '<h3 style="margin-top:22px">💎 الكنز الناقص (' + (M.tDefTotal ? QT.fmtU(M.tDefTotal) + ' ربع' : '0') + ')</h3>';
  if (!M.tDefOpen.length) html += note("لا يوجد كنز ناقص 👏");
  for (i = 0; i < M.tDefOpen.length; i++) {
    var td = M.tDefOpen[i], segs = QT.segsOf(td.curFrom, td.to), ss = [];
    for (j = 0; j < segs.length; j++) ss.push(QT.segFull(segs[j]));
    html += '<div class="dayline"><div class="meta"><div class="title">اليوم ' + td.n + ' — ' + QT.shortDate(td.date) + ' · ناقص ' + QT.fmtU(td.rem) + ' ربع</div>' +
            '<div class="sub">' + esc(ss.join(" + ")) + '</div></div>';
    if (enabled) html += '<div class="row"><button class="btn small" data-act="t-full" data-ref="' + td.id + '" data-amt="' + td.rem + '">تم بالكامل</button>' +
                         '<button class="btn small gray" data-act="t-part" data-ref="' + td.id + '" data-rem="' + td.rem + '">جزئي</button></div>';
    html += '</div>';
  }

  /* ---- الجديد الناقص ---- */
  html += '<h3 style="margin-top:22px">📖 الجديد الناقص (' + M.nDefTotal + ' آية)</h3>';
  if (!M.nDefOpen.length) html += note("لا يوجد جديد ناقص 👏");
  for (i = 0; i < M.nDefOpen.length; i++) {
    var nd = M.nDefOpen[i];
    html += '<div class="dayline"><div class="meta"><div class="title">اليوم ' + nd.n + ' — ' + QT.shortDate(nd.date) + ' · ربع ' + nd.q + ' من المائدة</div>' +
            '<div class="sub">الآيات الناقصة: من ' + nd.curFrom + ' إلى ' + nd.to + ' (' + nd.rem + ' آية)</div></div>';
    if (enabled) html += '<div class="row"><button class="btn small" data-act="n-full" data-ref="' + nd.id + '" data-amt="' + nd.rem + '">تم بالكامل</button>' +
                         '<button class="btn small gray" data-act="n-part" data-ref="' + nd.id + '" data-from="' + nd.curFrom + '" data-to="' + nd.to + '">جزئي</button></div>';
    html += '</div>';
  }
  html += '<div id="compBoxMsg"></div>';
  box.innerHTML = html;

  box.onclick = function (ev) {
    ev = ev || window.event;
    var t = ev.target || ev.srcElement;
    while (t && t !== box && !(t.getAttribute && (t.getAttribute("data-act") || t.getAttribute("data-pick")))) t = t.parentNode;
    if (!t || t === box) return;
    if (t.getAttribute("data-pick")) {
      if (!enabled) return;
      var pk = t.getAttribute("data-pick");
      QT.addComp(pk, t.getAttribute("data-ref"), Number(t.getAttribute("data-amt")));
      QT.toast("تم تسجيل الجزء ✅", "ok2"); if (onChange) onChange(); return;
    }
    var act = t.getAttribute("data-act"), ref = t.getAttribute("data-ref");
    if (!enabled) return;
    if (act === "day") { QT.addComp("day", ref, 0); QT.toast("تم تعويض اليوم ✅", "ok2"); if (onChange) onChange(); return; }
    if (act === "t-full") { QT.addComp("t", ref, Number(t.getAttribute("data-amt"))); QT.toast("تم تعويض الكنز ✅", "ok2"); if (onChange) onChange(); return; }
    if (act === "n-full") { QT.addComp("n", ref, Number(t.getAttribute("data-amt"))); QT.toast("تم تعويض الجديد ✅", "ok2"); if (onChange) onChange(); return; }
    if (act === "t-part" || act === "n-part") {
      // لوحة اختيارات (بدل الكتابة): تظهر تحت السطر
      var row = t; while (row && row !== box && (" " + row.className + " ").indexOf(" dayline ") < 0) row = row.parentNode;
      if (!row || row === box) return;
      var old = row.getElementsByClassName("pickpanel");
      if (old.length) { row.removeChild(old[0]); return; }
      var pn = document.createElement("div"); pn.className = "pickpanel";
      pn.style.cssText = "flex-basis:100%;width:100%;margin-top:8px";
      var h = "", k;
      if (act === "t-part") {
        var rem = Number(t.getAttribute("data-rem")), list = ["¼", "½", "1", "1¼", "1½"];
        h = '<div class="muted">كم ربعًا حفظت من هذا النقص؟</div><div class="chips">';
        for (k = 0; k < list.length; k++) { var uv = QT.parseU(list[k]); if (uv < rem) h += '<button type="button" class="chip" data-pick="t" data-ref="' + ref + '" data-amt="' + uv + '" style="direction:ltr">' + list[k] + '</button>'; }
        h += '</div>';
      } else {
        var f = Number(t.getAttribute("data-from")), to = Number(t.getAttribute("data-to"));
        h = '<div class="muted">آخر آية حفظتها؟</div><div class="chips">';
        for (k = f; k < to && k < f + 40; k++) h += '<button type="button" class="chip" data-pick="n" data-ref="' + ref + '" data-amt="' + (k - f + 1) + '">' + k + '</button>';
        h += '</div>';
      }
      pn.innerHTML = h; row.style.flexWrap = "wrap"; row.appendChild(pn);
      return;
    }
    if (act === "pick") { /* يُعالَج أدناه */ }
  };
};

/* =====================================================================
   نموذج التقرير (يُستعمل في report.html وفي نافذة صفحة الخطة)
   QT.openReport(عنصر, "YYYY-MM-DD", { edit, fromPlan, noNav, setTitle, setSub, onDone })
   ===================================================================== */
QT.openReport = function (app, date, hooks) {
  hooks = hooks || {};
  var $ = function (id) { return document.getElementById(id); };
  (function () {
      var esc = QT.esc;
      var M = null, day = null, form = {}, busy = false;

      /* ---------- أدوات العرض ---------- */
      var FOUR = [["full", "✅", "تم بالكامل"], ["extra", "➕", "تم وزيادة"], ["partial", "🟡", "جزئي"], ["none", "❌", "لم يتم"]];
      var TWO = [["done", "✅", "تم"], ["none", "❌", "لم يتم"]];
      function optBtns(sec, list, two) {
        var cur = form[sec] && form[sec].st, h = '<div class="opts' + (two ? ' two' : '') + '">', i;
        for (i = 0; i < list.length; i++) {
          h += '<button type="button" class="opt ' + list[i][0] + (cur === list[i][0] ? ' sel' : '') + '" data-sec="' + sec + '" data-st="' + list[i][0] + '"><span>' + list[i][1] + '</span>' + list[i][2] + '</button>';
        }
        return h + '</div>';
      }
      function chipGrid(sec, vals, cur) {
        var h = '<div class="grid">';
        for (var i = 0; i < vals.length; i++) {
          h += '<button type="button" class="ch' + (String(cur) === String(vals[i][0]) ? ' sel' : '') + '" data-chip="' + sec + '" data-v="' + vals[i][0] + '">' + vals[i][1] + '</button>';
        }
        return h + '</div>';
      }
      function head(ic, title, sub) {
        return '<div class="box-h"><div class="ico">' + ic + '</div><div><h3>' + title + '</h3>' + (sub ? '<small>' + sub + '</small>' : '') + '</div></div>';
      }

      // اختيارات الكنز: زيادة من 2 إلى 4 ، جزئي من ¼ إلى 1½ (أقل من المطلوب)
      var EXTRA_T = ["2", "2¼", "2½", "3", "3¼", "3½", "4"];
      var PART_T = ["¼", "½", "1", "1¼", "1½", "2", "2½", "3", "3½"];

      function treasureBox() {
        var t = day.t, h = '<section class="box t">' + head("💎", "الكنز", "المطلوب اليوم: " + QT.fmtU(t.req) + " ربع"), i;
        for (i = 0; i < t.segs.length; i++) {
          var sg = t.segs[i], inf = sg.info;
          h += '<div class="item"><span class="pill">ربع ' + sg.u + '</span><span class="name">' + esc(inf.title) + '</span>';
          if (!sg.whole) h += ' <span class="tag">' + (sg.a === 0 ? "أول " : sg.b === 12 ? "آخر " : "جزء ") + QT.fmtU(sg.b - sg.a) + '</span>';
          if (inf.sub && inf.sub !== "كاملة") h += '<br><span class="mu">يبدأ بـ</span> <span class="ph">«' + esc(inf.sub) + '»</span>';
          if (inf.ayat) h += ' <span class="mu">(آيات ' + inf.ayat + ')</span>';
          if (inf.parts.length > 2) h += '<br><span class="mu">' + esc(inf.parts.map(function (p) { return p[0]; }).join("، ")) + '</span>';
          h += '</div>';
        }
        h += optBtns("t", FOUR, false);
        var st = form.t && form.t.st, cur = form.t && form.t.amtText;
        if (st === "extra") {
          var ev = []; for (i = 0; i < EXTRA_T.length; i++) ev.push([EXTRA_T[i], EXTRA_T[i]]);
          h += '<div class="pick"><h4>➕ كم ربعًا زدت؟</h4>' + chipGrid("t", ev, cur) + '</div>';
        }
        if (st === "partial") {
          var pv = [];
          for (i = 0; i < PART_T.length; i++) if (QT.parseU(PART_T[i]) < t.req) pv.push([PART_T[i], PART_T[i]]);
          h += '<div class="pick p"><h4>🟡 كم ربعًا حفظت؟</h4>' + (pv.length ? chipGrid("t", pv, cur) : '<p class="hint">المطلوب صغير، اختر «تم بالكامل» أو «لم يتم».</p>') + '</div>';
        }
        return h + '</section>';
      }
      function newBox() {
        var n = day.nw, q = n.qi, h = '<section class="box n">' + head("📖", "الجديد", n.plan ? "خطة الجديد للترم الأول · سورة المائدة" : "سورة المائدة · اليوم " + (n.ph === "A" ? "الأول" : "الثاني") + " من الربع"), i;
        if (n.plan) {
          h += '<div class="item"><span class="pill g">اليوم ' + n.k + ' من 25</span><span class="name">من آية ' + n.from + ' إلى آية ' + n.to + '</span> <span class="mu">(' + n.cnt + ' آيات)</span>' +
               '<br><span class="mu">مقرر هذا اليوم في الخطة: آيات ' + q.s + '–' + q.e + '</span></div>';
        } else {
        h += '<div class="item"><span class="pill g">ربع ' + q.q + '</span><span class="name">من آية ' + n.from + ' إلى آية ' + n.to + '</span> <span class="mu">(' + n.cnt + ' آيات)</span>' +
             '<br><span class="mu">الربع يبدأ بـ</span> <span class="ph">«' + esc(q.ph) + '»</span> <span class="mu">(آيات ' + q.s + '–' + q.e + ')</span></div>';
        }
        h += optBtns("nw", FOUR, false);
        var st = form.nw && form.nw.st, cur = form.nw && form.nw.toText;
        if (st === "extra") {
          var ev = [], mx = Math.min(n.to + 15, QT.NEW_LAST_FOR(n));
          for (i = n.to + 1; i <= mx; i++) ev.push([i, i]);
          h += '<div class="pick"><h4>➕ إلى أي آية وصلت؟ (بعد آية ' + n.to + ')</h4>' + (ev.length ? chipGrid("nw", ev, cur) : '<p class="hint">لا توجد آيات بعدها.</p>') + '</div>';
        }
        if (st === "partial") {
          var pv = [];
          for (i = n.from; i < n.to; i++) pv.push([i, i]);
          h += '<div class="pick p"><h4>🟡 آخر آية حفظتها (من آية ' + n.from + ')</h4>' + (pv.length ? chipGrid("nw", pv, cur) : '<p class="hint">المطلوب آية واحدة، اختر «تم بالكامل» أو «لم يتم».</p>') + '</div>';
        }
        return h + '</section>';
      }
      function fixBox() {
        var f = day.fx, h = '<section class="box f">' + head("🔄", "التثبيت", "مراجعة من المائدة"), i;
        var fit = QT.fxItems(day);
        for (i = 0; i < fit.length; i++) {
          h += '<div class="item"><span class="pill g">' + fit[i].label + '</span><span class="name">من آية ' + fit[i].s + ' إلى ' + fit[i].e + '</span>' +
               (fit[i].ph ? '<br><span class="mu">يبدأ بـ</span> <span class="ph">«' + esc(fit[i].ph) + '»</span>' : '') + '</div>';
        }
        return h + optBtns("fx", TWO, true) + '</section>';
      }
      function wholeBox() {
        var cur = form.day || "";
        return '<section class="box">' + head("📌", "حالة اليوم بالكامل", "اختياري — اختصار لكل الأقسام") +
          '<div class="opts two"><button type="button" class="opt full' + (cur === "full" ? " sel" : "") + '" data-day="full"><span>✅</span>تم المطلوب</button>' +
          '<button type="button" class="opt none' + (cur === "none" ? " sel" : "") + '" data-day="none"><span>❌</span>لم يتم</button></div></section>';
      }

      /* ---------- مزامنة الاختيار الكلي ---------- */
      function syncDay() {
        var all = [], i;
        if (day.t) all.push(form.t && form.t.st);
        if (day.nw) all.push(form.nw && form.nw.st);
        if (day.fx) all.push(form.fx && form.fx.st);
        var full = true, none = true;
        for (i = 0; i < all.length; i++) {
          if (!(all[i] === "full" || all[i] === "done")) full = false;
          if (all[i] !== "none") none = false;
        }
        form.day = (all.length && full) ? "full" : (all.length && none) ? "none" : "";
      }
      function setAll(v) {
        if (day.t) form.t = { st: v === "full" ? "full" : "none", amtText: "" };
        if (day.nw) form.nw = { st: v === "full" ? "full" : "none", toText: "" };
        if (day.fx) form.fx = { st: v === "full" ? "done" : "none" };
        form.day = v;
      }

      /* ---------- بناء الصفحة ---------- */
      function draw() {
        var h = '<div class="steps"><b id="stepTxt"></b><div class="bar"><i id="stepBar"></i></div></div>';
        if (day.t) h += treasureBox();
        if (day.nw) h += newBox();
        if (day.fx) h += fixBox(); else h += '<section class="box f">' + head("🔄", "التثبيت", "") + '<div class="item mu">لا يوجد تثبيت اليوم (لم يكتمل ربع جديد بعد).</div></section>';
        h += wholeBox();
        h += '<div class="errbox" id="errBox"></div>';
        h += '<div class="dock"><button type="button" id="sendBtn" class="send">📤 تسجيل تقرير اليوم</button></div>';
        h += '<p class="hint" style="text-align:center">لا يتم احتساب أي شيء إلا بعد الضغط على «تسجيل تقرير اليوم».</p>';
        h += navBar();
        app.innerHTML = h;
        updateBtn();
      }
      function navBar() {
        if (hooks.noNav) return "";
        return '<nav class="navbar"><a href="plan.html"><span>📋</span>الخطة</a><a href="index.html"><span>🏠</span>الرئيسية</a><a href="success.html?d=' + date + '"><span>📊</span>التقدم</a></nav>';
      }
      function check() { return QT.buildReport(day, form); }
      function updateBtn() {
        var b = $("sendBtn"); if (!b) return;
        var r = check();
        b.className = "send" + (r.ok ? "" : " off");
        var total = (day.t ? 1 : 0) + (day.nw ? 1 : 0) + (day.fx ? 1 : 0), got = 0;
        function ok(x) { return x && x.st && !((x.st === "extra" || x.st === "partial") && !(x.amtText || x.toText)); }
        if (day.t && ok(form.t)) got++;
        if (day.nw && ok(form.nw)) got++;
        if (day.fx && ok(form.fx)) got++;
        if ($("stepTxt")) { $("stepTxt").innerHTML = "اكتمل " + got + " من " + total; $("stepBar").style.width = (total ? Math.round(got / total * 100) : 0) + "%"; }
      }

      app.onclick = function (ev) {
        ev = ev || window.event;
        var t = ev.target || ev.srcElement;
        while (t && t !== app && !(t.getAttribute && (t.getAttribute("data-sec") || t.getAttribute("data-day") || t.getAttribute("data-chip") || t.id === "sendBtn"))) t = t.parentNode;
        if (!t || t === app || busy) return;
        var g = function (a) { return t.getAttribute(a); };
        var sec = g("data-sec");
        if (sec) {
          var old = form[sec] || {};
          if (old.st && old.st === g("data-st")) { form[sec] = null; syncDay(); draw(); return; }      // الضغط مرة ثانية يلغي الاختيار
          form[sec] = { st: g("data-st"), amtText: (g("data-st") === old.st ? old.amtText : ""), toText: (g("data-st") === old.st ? old.toText : "") };
          syncDay(); draw(); return;
        }
        if (g("data-day")) {
          if (form.day === g("data-day")) { form.t = null; form.nw = null; form.fx = null; form.day = ""; }   // الضغط مرة ثانية يلغي كل الاختيارات
          else setAll(g("data-day"));
          draw(); return;
        }
        if (g("data-chip")) {
          var cs = g("data-chip"), v = g("data-v");
          form[cs] = form[cs] || {};
          if (t.className.indexOf("sel") > -1) {                                   // الضغط على الاختيار المحدد يلغيه
            if (cs === "t") form.t.amtText = ""; else form.nw.toText = "";
            t.className = t.className.replace(/ ?sel/g, ""); updateBtn(); return;
          }
          if (cs === "t") form.t.amtText = v; else form.nw.toText = v;
          var sibs = t.parentNode.getElementsByTagName("button");
          for (var i = 0; i < sibs.length; i++) sibs[i].className = sibs[i].className.replace(/ ?sel/g, "");
          t.className += " sel"; updateBtn(); return;
        }
        if (t.id === "sendBtn") send();
      };

      function send() {
        var any = (form.t && form.t.st) || (form.nw && form.nw.st) || (form.fx && form.fx.st);
        if (!any) return;                                       // لا شيء محدد: الزر لا يعمل (كأنه لم يُكتب شيء)
        var r = check(), eb = $("errBox");
        if (!r.ok) {
          var h = '<div class="err"><b>لا يمكن الإرسال، ناقصك:</b><br>';
          for (var i = 0; i < r.errors.length; i++) h += "• " + esc(r.errors[i]) + "<br>";
          eb.innerHTML = h + '</div>';
          try { eb.scrollIntoView(); } catch (e) {}
          return;
        }
        busy = true; eb.innerHTML = '<div class="ok-msg">⏳ جاري الإرسال...</div>';
        $("sendBtn").className = "send off";
        var rep = QT.withHistory(date, r.report), st = QT.getState();
        st.reports[date] = rep;
        var M2 = QT.compute(st, QT.todayStr()), d2 = M2.byDate[date];
        var text = QT.reportText(M2, d2);
        var finished = false;
        function go() { if (finished) return; finished = true; try { window.sessionStorage.setItem("qt_just", date); } catch (e) {} goDone(); }
        QT.putReport(date, rep, { notify: text, gdetail: QT.guardianDetail(d2), date: date, n: day.n, kind: "report" }, function () { go(); });
        setTimeout(go, 2500);
      }

      /* ---------- الجمعة ---------- */
      function fridayPage() {
        var k = QT.getState().kahf[date], sel = k ? (k.ok ? "done" : "none") : "", examId = "";
        var h = '<section class="box f">' + head("🕌", "سورة الكهف", "قراءة أو تسميع — لا تدخل في الخطة ولا تُحسب نقصًا") +
          '<div class="opts two"><button type="button" class="opt full' + (sel === "done" ? " sel" : "") + '" data-k="done"><span>✅</span>تم</button>' +
          '<button type="button" class="opt none' + (sel === "none" ? " sel" : "") + '" data-k="none"><span>❌</span>لم يتم</button></div></section>' +
          '<section class="box f">' + head("📝", "اختبار الأسبوع", "20 سؤالًا من الكنز والثابت — درجته تصل لولي الأمر") + '<div id="exBody" class="mu">⏳ جاري التحقق من اختبار الأسبوع...</div></section>' +
          '<div class="dock"><button type="button" id="kSend" class="send">📤 تسجيل تقرير اليوم</button></div>' + navBar();
        app.innerHTML = h;
        var chosen = sel;
        function exLink(label) { return '<a class="btn" href="exam.html?mode=official&d=' + date + '">' + label + '</a>'; }
        function loadExam() {
          var box = document.getElementById("exBody"); if (!box) return;
          if (!QT.hasServer()) { box.innerHTML = "الاختبار يحتاج اتصالًا بالخادم."; return; }
          QT.api({ action: "exam", op: "find", date: date }, function (ok, data) {
            if (!ok || !data || data.ok === false) { box.innerHTML = '<p class="mu">تعذّر التحقق من حالة الاختبار.</p>' + (date === QT.todayStr() ? exLink("📝 ابدأ اختبار الأسبوع") : ""); return; }
            if (data.found && data.done && data.result) {
              examId = data.sid;
              box.innerHTML = '<div class="ok-msg">✅ أنهيت اختبار الأسبوع: <b>' + QT.esc(String(data.result.score)) + ' من ' + QT.esc(String(data.result.total)) + ' (' + QT.esc(String(data.result.pct)) + '%)</b></div><p class="mu">تصل النتيجة لولي الأمر مع تقرير الجمعة عند الضغط على «تسجيل تقرير اليوم».</p>';
              return;
            }
            if (data.found && !data.done) { box.innerHTML = '<p class="mu">اختبارك مفتوح ولم ينتهِ. الرجوع له يُحسب خروجًا من الصفحة ويتبدّل السؤال.</p>' + exLink("▶ كمّل الاختبار"); return; }
            if (date !== QT.todayStr()) { box.innerHTML = '<p class="mu">الاختبار الرسمي متاح يوم الجمعة نفسه فقط.</p>'; return; }
            box.innerHTML = '<p class="mu">اختبار شامل: الكنز والثابت والتسميع بالصوت. جهّز نفسك، وما تخرجش من الصفحة وقت الاختبار.</p>' + exLink("📝 ابدأ اختبار الأسبوع");
          }, 15000);
        }
        loadExam();
        app.onclick = function (ev) {
          ev = ev || window.event; var t = ev.target || ev.srcElement;
          while (t && t !== app && !(t.getAttribute && (t.getAttribute("data-k") || t.id === "kSend"))) t = t.parentNode;
          if (!t || t === app) return;
          var kk = t.getAttribute("data-k");
          if (kk) { chosen = kk; var bs = app.getElementsByClassName("opt"); for (var i = 0; i < bs.length; i++) bs[i].className = bs[i].className.replace(/ ?sel/g, ""); t.className += " sel"; return; }
          if (t.id === "kSend") {
            if (!chosen) { QT.toast("اختر تم أو لم يتم لسورة الكهف", "err2"); return; }
            QT.getState().kahf[date] = { ok: chosen === "done", at: new Date().getTime() };
            QT.putReport("fri-" + date, { v: 2, friday: true, kahf: chosen }, { notify: "🕌 الجمعة " + QT.shortDate(date) + " — سورة الكهف: " + (chosen === "done" ? "✅ تم" : "❌ لم يتم"), date: date, kind: "friday", examId: examId, kahf: chosen }, function () {});
            QT.putKahf(date, chosen === "done");
            try { window.sessionStorage.setItem("qt_just", date); } catch (e) {}
            setTimeout(function () { goDone(); }, 1200);
            QT.toast("جاري الإرسال...", "ok2");
          }
        };
      }

      function msgPage(title, text, link) {
        app.innerHTML = '<div class="box msg"><h2>' + title + '</h2><p class="mu">' + text + '</p>' + (link ? '<a class="btn" href="' + link[0] + '">' + link[1] + '</a>' : '') + '</div>' + navBar();
      }

      /* ---------- التشغيل ---------- */
      var st = QT.getState();
      var setTitle = hooks.setTitle || function () {}, setSub = hooks.setSub || function () {};
      function goDone() { try { window.sessionStorage.setItem("qt_just", date); } catch (e) {} if (hooks.onDone) hooks.onDone(date); else window.location.replace("success.html?d=" + date); }
      if (!st.start) { setTitle("تقرير اليوم"); msgPage("📅 حدّد تاريخ بداية الخطة أولًا", "افتح الصفحة الرئيسية واختر تاريخ البداية.", ["index.html", "الذهاب للرئيسية"]); return; }
      M = QT.compute(st, QT.todayStr());
      setSub(QT.prettyDate(date));
      var d = M.byDate[date];
      if (QT.isRest(date)) { setTitle("يوم راحة 🌿"); msgPage("🌿 يوم راحة", "الأحد والأربعاء بلا مهام ولا تقرير.", ["plan.html", "📋 الخطة"]); return; }
      if (date < st.start || !d) { setTitle("تقرير اليوم"); msgPage("لا يوجد حفظ في هذا التاريخ", "هذا اليوم قبل بداية الخطة أو بعد نهايتها.", ["plan.html", "📋 الخطة"]); return; }
      if (d.isFriday) { setTitle("يوم الجمعة 🕌"); fridayPage(); return; }
      if (date > QT.todayStr()) { setTitle("اليوم " + d.n); msgPage("⏳ هذا اليوم لم يأتِ بعد", "يمكنك ملء تقرير اليوم عند حلول موعده.", ["plan.html", "📋 الخطة"]); return; }
      var edit = !!hooks.edit;
      if (QT.reportOf(st, date) && !edit) { goDone(); return; }
      if (!hooks.fromPlan) { try { if (window.sessionStorage.getItem("qt_just") === date && !edit) { goDone(); return; } } catch (e) {} }
      day = d;
      if (QT.reportOf(st, date)) {
        var copy = JSON.parse(JSON.stringify(st)); delete copy.reports[date];
        var Mx = QT.compute(copy, date); day = Mx.byDate[date] || d;
        var rp = QT.reportOf(st, date);
        if (day.t && rp.t) form.t = { st: rp.t.st, amtText: rp.t.amt ? QT.fmtRaw(rp.t.amt) : "" };
        if (day.nw && rp.nw) form.nw = { st: rp.nw.st, toText: rp.nw.to ? String(rp.nw.to) : "" };
        if (day.fx && rp.fx) form.fx = { st: rp.fx.st };
        syncDay();
      }
      setTitle("اليوم " + day.n);
      draw();
  })();
};
