/* =====================================================================
   Code.gs — Google Apps Script لمشروع «خطة متابعة القرآن الكريم»
   • حسابات: لكل مشترك بياناته الخاصة.
   • أربعة قوالب واتساب فقط (باللهجة المصرية ar_EG)، وكلها تُرسل بالقوالب فتصل في أي وقت:
       1) تذكير الطالب بملء التقرير        (مواعيده يحددها الطالب)
       2) تقرير الطالب لولي الأمر           (يُرسل فورًا بعد ملء التقرير)
       3) «مهام اليوم مرسلة إلى الطالب»     (مواعيده يحددها الطالب)
       4) «مهام اليوم مرسلة إلى ولي الأمر»  (مواعيده يحددها الطالب، بدون رابط)
   • يحتاج ملف Engine.gs بجانبه (يحسب مهام كل يوم).
   ===================================================================== */

// ======== الإعدادات ========
var APP_VERSION = "final-10";                           // رقم الإصدار (يظهر في testConnection ليسهل التأكد أنك لصقت النسخة الصحيحة)
// تاريخ بداية «خطة الجديد للترم الأول» (YYYY-MM-DD). فارغ = النظام القديم (الأرباع) كما هو. هذا هو المكان الوحيد الذي تكتبه فيه (الموقع يقرؤه من هنا تلقائيًا).
// إذا كتبته: الأيام قبله تبقى بالنظام القديم وتقاريرها كما هي، ومنه يحسب النظام لكل مشترك آخر آية حفظها فعلًا ويكمل من بعدها.
var NEW_PLAN_START = "";                               // (اتركه فارغًا) الأفضل ضبط التاريخ من: Project Settings ← Script properties ← إضافة خاصية اسمها NEW_PLAN_START وقيمتها 2026-11-23 مثلًا
function npStart_() {                                   // تاريخ بداية الخطة الجديدة: من خصائص النص البرمجي أولًا، ثم من المتغير أعلاه
  var v = "";
  try { v = String(PropertiesService.getScriptProperties().getProperty("NEW_PLAN_START") || "").replace(/\s/g, ""); } catch (e) {}
  v = v || String(NEW_PLAN_START || "").replace(/\s/g, "");
  return /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : "";
}
var SITE_URL = "https://ammmaoa.github.io/quran-tracker";   // رابط الموقع بدون / في الآخر
var PHONE_NUMBER_ID = "1296156683587122";

// القوالب الأربعة. لكل قالب: الاسم واللغة كما تظهر في Meta، وvars = ترتيب متغيراته {{1}} {{2}} {{3}}.
// الرموز المسموحة في vars:  day = رقم اليوم ،  name = اسم الطالب ،  tasks = مهام اليوم ،  link = رابط ،  detail = تفاصيل التقرير
// شغّل الدالة testTemplates لتعرف الاسم واللغة وعدد متغيرات كل قالب في Meta بالضبط، وعدّل الأسطر أدناه لتطابقها.
var TPL = {
  // alts = ترتيبات بديلة للمتغيرات: لو رفضت Meta الرسالة بسبب «عدد المتغيرات لا يطابق القالب» (خطأ 132000) يجرّب النظام الترتيب التالي تلقائيًا ويتذكر الترتيب الناجح.
  studentReportReminder: { name: "quran_daily_report",   lang: "ar_EG", vars: ["day", "link"], alts: [["day"], ["link"]] },                                   // تذكير الطالب بملء التقرير
  parentReport:          { name: "quran_parent_report",  lang: "ar_EG", vars: ["day", "detail"], alts: [] },                                                 // تقرير الطالب لولي الأمر (فور الحفظ) — متغيران فقط، ثابت لا يتغير
  studentTasks:          { name: "quran_daily_tasks",    lang: "ar_EG", vars: ["day", "link"], alts: [["day", "tasks", "link"], ["day", "tasks"], ["day"], ["tasks", "link"], ["link"], ["tasks"]] },  // مهام اليوم للطالب
  parentTasks:           { name: "_quran_parent_tasks",  names: ["_quran_parent_tasks", "quran_parent_tasks_", "quran_parent_tasks"], lang: "ar_EG", vars: ["name", "day", "tasks"], alts: [["day", "tasks"], ["name", "tasks"], ["tasks"], ["name", "day"]] }                 // مهام اليوم لولي الأمر (بدون رابط) — الاسم في Meta يبدأ بشرطة سفلية _
};
function validateTpl_() {                                // يتأكد قبل أي إرسال أن إعدادات القوالب سليمة (الرموز المسموحة فقط)
  var ok = { day: 1, name: 1, tasks: 1, link: 1, detail: 1 }, k, i, bad = [];
  for (k in TPL) {
    for (i = 0; i < TPL[k].vars.length; i++) if (!ok[TPL[k].vars[i]]) bad.push(k + ":" + TPL[k].vars[i]);
    for (var a = 0; a < (TPL[k].alts || []).length; a++) for (i = 0; i < TPL[k].alts[a].length; i++) if (!ok[TPL[k].alts[a][i]]) bad.push(k + ":alt" + a + ":" + TPL[k].alts[a][i]);
  }
  return bad;
}
var WABA_ID = "2057317411656038";                      // معرّف حساب واتساب للأعمال (لدالة testTemplates فقط). يتغير لو غيّرت الحساب

// قالب رمز استرجاع كلمة السر (غير مطلوب الآن: اتركه فارغًا؛ وقتها الاسترجاع عن طريق الدعم)
var RESET_TEMPLATE_NAME = "";
var RESET_TEMPLATE_LANG = "ar_EG";

var NOTIFY_EMAIL = "";                                 // بريد يصله إشعار عند كل تسجيل جديد (فارغ = بريد حسابك في Google)
var SUPPORT_PHONE = "201095374757";                    // رقم الدعم الذي يظهر للمشتركين

// true = رقم Meta التجريبي (حد 5 أرقام وتحتاج إضافة كل رقم يدويًا) ، false = رقم حقيقي (بلا حد)
var USING_TEST_NUMBER = true;
var MAX_NUMBERS = 5;                                   // حد رقم الاختبار (الطلاب + أولياء الأمور)

var DEFAULT_REST = [0, 3];                             // الأحد والأربعاء (0=الأحد ... 6=السبت)
var DEFAULT_REMINDERS = ["18:00", "22:00"];            // مواعيد تذكير ملء التقرير لمن لم يحددها
var DEFAULT_TASKS_STUDENT = ["06:00"];                 // مهام اليوم للطالب
var DEFAULT_TASKS_GUARDIAN = ["06:00"];                // مهام اليوم لولي الأمر
// ===========================

var SCHEMA_VERSION = "6";                              // رقم إصدار بنية البيانات (عند تغييره يُؤخذ نسخ احتياطي تلقائي قبل أي ترحيل)
var TICK_MINUTES = 5;                                  // فحص المواعيد كل 5 دقائق
var LOOKAHEAD_SEC = 300;                               // الرسالة التي موعدها خلال الدقائق الخمس القادمة تُرسل عند موعدها بالضبط (ينتظر الفحص حتى الموعد)
var GRACE_MIN = 60;                                    // لو مرّ الموعد وما أُرسلت الرسالة (ضمن ساعة) تُرسل فورًا في أول فحص بدل أن تضيع أو تُؤجَّل لبكرة
var MAX_RUN_SEC = 340;                                 // حد أمان لزمن التشغيل الواحد (الحد الأقصى في Google 6 دقائق)
var BACKUPS_KEEP = 5;                                  // عدد النسخ الاحتياطية المحفوظة
var TZ = "Africa/Cairo";
var USERS_SHEET = "_users";
var NUMBERS_SHEET = "_numbers";
var LOG_SHEET = "التقارير";
var ROSTER_SHEET = "المشتركون";                       // ورقة مقروءة بأسماء وأرقام المشتركين (بدون كلمات السر)

/* ============================ الاستقبال ============================ */
function doGet(e) {
  return ContentService.createTextOutput("Quran Tracker is working | version " + APP_VERSION + " | NEW_PLAN_START=" + (npStart_() || "(empty)")).setMimeType(ContentService.MimeType.TEXT);
}
function doPost(e) {
  var d0 = null;
  try { d0 = JSON.parse(e.postData.contents); } catch (x0) { d0 = null; }
  if (d0 && d0.action === "exam") {                      // الاختبار له جلساته الخاصة: لا يحجز القفل العام (لا يوقف الآخرين ولا المواعيد)
    try { memoReset_(); return json_(actExam_(d0)); } catch (err0) { return json_({ ok: false, error: "خطأ في الخادم: " + String(err0) }); }
  }
  var lock = LockService.getScriptLock();
  try {
    lock.waitLock(25000);
    memoReset_();
    ensureSchema_();
    var d = JSON.parse(e.postData.contents);
    var out;
    switch (d.action) {
      case "status":       out = actStatus_(); break;
      case "register":     out = actRegister_(d); break;
      case "login":        out = actLogin_(d); break;
      case "get":          out = actGet_(d); break;
      case "save":         out = actSave_(d); break;
      case "profile":      out = actProfile_(d); break;
      case "resetRequest": out = actResetRequest_(d); break;
      case "resetConfirm": out = actResetConfirm_(d); break;
      default:             out = { ok: false, error: "طلب غير معروف" };
    }
    return json_(out);
  } catch (err) {
    return json_({ ok: false, error: "خطأ في الخادم: " + String(err) });
  } finally {
    try { lock.releaseLock(); } catch (x) {}
  }
}
function json_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

/* ============================ أدوات عامة ============================ */
function ss_() { return SpreadsheetApp.getActiveSpreadsheet(); }
function normDigits_(s) {
  return String(s || "").replace(/[٠-٩]/g, function (c) { return String(c.charCodeAt(0) - 1632); });
}
// رقم موبايل مصري صحيح: 11 رقمًا يبدأ بـ 010 أو 011 أو 012 أو 015 → يعود بالصيغة الدولية 201xxxxxxxxx
function normPhone_(p) {
  var d = normDigits_(p).replace(/\D/g, "");
  if (d.indexOf("0020") === 0) d = d.substring(2);
  if (d.length === 12 && d.indexOf("20") === 0) d = "0" + d.substring(2);
  if (!/^01[0125]\d{8}$/.test(d)) return "";
  return "2" + d;
}
var PHONE_ERR = "رقم الهاتف لازم يكون 11 رقمًا ويبدأ بـ 010 أو 011 أو 012 أو 015.";
function supportLocal_() { return "0" + SUPPORT_PHONE.substring(2); }
function localPhone_(p) { return p && String(p).indexOf("20") === 0 ? "0" + String(p).substring(2) : String(p || ""); }
function hex_(bytes) {
  var s = "";
  for (var i = 0; i < bytes.length; i++) { var b = bytes[i]; if (b < 0) b += 256; s += (b < 16 ? "0" : "") + b.toString(16); }
  return s;
}
function hashPin_(salt, pin) {
  return hex_(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, salt + ":" + pin, Utilities.Charset.UTF_8));
}
function rand_(n) { return Utilities.getUuid().replace(/-/g, "").substring(0, n); }
function oneLine_(t) {                                  // القوالب لا تقبل أسطرًا جديدة أو مسافات كثيرة داخل المتغير
  var x = String(t || "").replace(/[\r\n\t]+/g, " | ").replace(/ {2,}/g, " ").replace(/(\| ){2,}/g, "| ");
  x = x.replace(/^[\s|]+|[\s|]+$/g, "");
  return x.length > 900 ? x.substring(0, 897) + "..." : x;
}

/* ============================ المستخدمون ============================ */
function usersSheet_() {
  var sh = ss_().getSheetByName(USERS_SHEET);
  if (!sh) {
    sh = ss_().insertSheet(USERS_SHEET);
    sh.appendRow(["id", "name", "phone", "guardian", "salt", "hash", "tokens", "createdAt", "rest", "reminders", "tasksStudent", "tasksGuardian"]);
    sh.getRange("A:L").setNumberFormat("@");
    try { sh.hideSheet(); } catch (e) {}
  }
  return sh;
}
function jsonList_(cell, fallback) {
  try { var a = JSON.parse(String(cell || "")); if (a && a.length) return a; } catch (e) {}
  return fallback;
}
var MEMO_USERS_ = null;
function memoReset_() { MEMO_USERS_ = null; }
function readUsers_() {
  if (MEMO_USERS_) return MEMO_USERS_;
  var sh = usersSheet_(), last = sh.getLastRow(), out = [];
  if (last < 2) return out;
  var vals = sh.getRange(2, 1, last - 1, 12).getValues();
  for (var i = 0; i < vals.length; i++) {
    var v = vals[i], tk = [], rs = DEFAULT_REST;
    if (!v[0]) continue;
    try { tk = JSON.parse(String(v[6] || "[]")); } catch (e) {}
    try { var a = JSON.parse(String(v[8] || "")); if (a && a.length !== undefined) rs = a; } catch (e2) {}
    out.push({ row: i + 2, id: String(v[0]), name: String(v[1]), phone: String(v[2]), guardian: String(v[3] || ""),
               salt: String(v[4]), hash: String(v[5]), tokens: tk, createdAt: String(v[7]), rest: rs,
               reminders: jsonList_(v[9], DEFAULT_REMINDERS), tasksStudent: jsonList_(v[10], DEFAULT_TASKS_STUDENT),
               tasksGuardian: jsonList_(v[11], DEFAULT_TASKS_GUARDIAN) });
  }
  MEMO_USERS_ = out;
  return out;
}
function findBy_(field, value) {
  var u = readUsers_();
  for (var i = 0; i < u.length; i++) if (u[i][field] === value) return u[i];
  return null;
}
function writeUser_(u) {
  MEMO_USERS_ = null;
  var sh = usersSheet_();
  sh.getRange(u.row, 2, 1, 6).setValues([[u.name, u.phone, u.guardian || "", u.salt, u.hash, JSON.stringify(u.tokens)]]);
  sh.getRange(u.row, 9, 1, 4).setValues([[JSON.stringify(u.rest || DEFAULT_REST), JSON.stringify(u.reminders || DEFAULT_REMINDERS),
                                          JSON.stringify(u.tasksStudent || DEFAULT_TASKS_STUDENT), JSON.stringify(u.tasksGuardian || DEFAULT_TASKS_GUARDIAN)]]);
}
function newToken_(u) {
  var t = rand_(32);
  u.tokens.push(t);
  if (u.tokens.length > 8) u.tokens = u.tokens.slice(u.tokens.length - 8);
  writeUser_(u);
  return t;
}
function auth_(d) {
  if (!d.uid || !d.token) return null;
  var u = findBy_("id", String(d.uid));
  if (!u) return null;
  return u.tokens.indexOf(String(d.token)) > -1 ? u : null;
}
function profileOf_(u) {
  return { name: u.name, phone: u.phone, guardian: u.guardian || "", rest: u.rest || DEFAULT_REST, reminders: u.reminders || DEFAULT_REMINDERS,
           tasksStudent: u.tasksStudent || DEFAULT_TASKS_STUDENT, tasksGuardian: u.tasksGuardian || DEFAULT_TASKS_GUARDIAN };
}

// أيام الراحة (0=الأحد ... 6=السبت)؛ الجمعة ثابتة للكهف والتعويض
function parseRest_(arr) {
  if (arr === undefined || arr === null) return DEFAULT_REST.slice();
  if (Object.prototype.toString.call(arr) !== "[object Array]") return null;
  var seen = {}, out = [];
  for (var i = 0; i < arr.length; i++) {
    var n = Number(arr[i]);
    if (n === 5) continue;
    if (!(n >= 0 && n <= 6) || n % 1 !== 0) return null;
    if (!seen[n]) { seen[n] = 1; out.push(n); }
  }
  out.sort(function (a, b) { return a - b; });
  if (out.length > 5) return null;
  return out;
}
// مواعيد الإرسال: من 1 إلى 5 مواعيد بصيغة HH:MM (الأول إجباري) — تُستعمل للمواعيد الثلاثة
function parseTimes_(arr, def) {
  if (arr === undefined || arr === null) return def.slice();
  if (Object.prototype.toString.call(arr) !== "[object Array]") return null;
  var seen = {}, out = [];
  for (var i = 0; i < arr.length; i++) {
    var t = String(arr[i]);
    if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(t)) return null;
    if (!seen[t]) { seen[t] = 1; out.push(t); }
  }
  if (out.length < 1 || out.length > 5) return null;
  out.sort();
  return out;
}

/* ===== سجل الأرقام: كل رقم يُضاف لرقم Meta التجريبي يبقى محسوبًا حتى لو حُذف الحساب ===== */
function numbersSheet_() {
  var sh = ss_().getSheetByName(NUMBERS_SHEET);
  if (!sh) {
    sh = ss_().insertSheet(NUMBERS_SHEET);
    sh.appendRow(["number", "addedAt"]);
    sh.getRange("A:B").setNumberFormat("@");
    try { sh.hideSheet(); } catch (e) {}
  }
  return sh;
}
function maxNumbers_() { return USING_TEST_NUMBER ? MAX_NUMBERS : 100000; }
function knownNumbers_() {
  var set = {}, count = 0, sh = numbersSheet_(), last = sh.getLastRow(), i;
  if (last >= 2) {
    var v = sh.getRange(2, 1, last - 1, 1).getValues();
    for (i = 0; i < v.length; i++) { var n = String(v[i][0]); if (n && !set[n]) { set[n] = 1; count++; } }
  }
  var u = readUsers_();
  for (i = 0; i < u.length; i++) {
    if (u[i].phone && !set[u[i].phone]) { set[u[i].phone] = 1; count++; }
    if (u[i].guardian && !set[u[i].guardian]) { set[u[i].guardian] = 1; count++; }
  }
  return { set: set, count: count };
}
function rememberNumbers_(list) {                     // نسجّل في الورقة فقط (لا نعتمد على الحسابات الحالية)
  var sh = numbersSheet_(), last = sh.getLastRow(), have = {}, i;
  if (last >= 2) {
    var v = sh.getRange(2, 1, last - 1, 1).getValues();
    for (i = 0; i < v.length; i++) have[String(v[i][0])] = 1;
  }
  for (i = 0; i < list.length; i++) {
    if (list[i] && !have[list[i]]) { have[list[i]] = 1; sh.appendRow([list[i], Utilities.formatDate(new Date(), TZ, "yyyy-MM-dd HH:mm")]); }
  }
}
function closedMsg_() {
  return "للأسف تم انتهاء التسجيل: اكتمل العدد المسموح به حاليًا. للاستفسار تواصل مع الدعم: " + supportLocal_();
}
function actStatus_() {
  var n = knownNumbers_();
  return { ok: true, open: n.count < maxNumbers_(), left: Math.max(0, maxNumbers_() - n.count), support: supportLocal_() };
}

/* ===== ورقة «المشتركون» المقروءة + إشعار البريد ===== */
function rosterDirty_() { try { PropertiesService.getScriptProperties().setProperty("rosterDirty", "1"); } catch (e) {} }
function syncRoster_() {
  var ss = ss_(), sh = ss.getSheetByName(ROSTER_SHEET);
  if (!sh) sh = ss.insertSheet(ROSTER_SHEET);
  var users = readUsers_(), i;
  var rows = [["الاسم", "رقم الهاتف", "رقم ولي الأمر", "تاريخ التسجيل", "أيام الراحة", "مهام الطالب", "مهام ولي الأمر", "تذكير التقرير"]];
  var DN = ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
  for (i = 0; i < users.length; i++) {
    var u = users[i], rn = [];
    for (var k = 0; k < (u.rest || []).length; k++) rn.push(DN[u.rest[k]]);
    rows.push([u.name, "'" + localPhone_(u.phone), u.guardian ? "'" + localPhone_(u.guardian) : "", u.createdAt, rn.join("، ") || "—",
               (u.tasksStudent || []).join(" ، "), u.guardian ? (u.tasksGuardian || []).join(" ، ") : "—", (u.reminders || []).join(" ، ")]);
  }
  sh.clear();
  sh.getRange(1, 1, rows.length, 8).setValues(rows);
}
function notifyOwner_(u) {
  try {
    var to = NOTIFY_EMAIL || Session.getEffectiveUser().getEmail();
    if (!to) return;
    var body = "مشترك جديد في خطة متابعة القرآن الكريم:\n\n" +
      "الاسم: " + u.name + "\nرقم الهاتف: " + localPhone_(u.phone) + "\nرقم ولي الأمر: " + (u.guardian ? localPhone_(u.guardian) : "لا يوجد") +
      (USING_TEST_NUMBER ? "\n\nالمطلوب منك: أضف الرقم (والرقم الثاني إن وُجد) في Meta ← WhatsApp ← API Setup ← Manage phone number list، ثم أكّده بالكود الذي يصل صاحبه.\n" : "\n\nلا يلزم إضافة الرقم في Meta لأنك تستخدم رقمًا حقيقيًا.\n") +
      "(كلمة السر لا يراها أحد؛ لو نسيها شغّل adminResetPin.)";
    MailApp.sendEmail(to, "مشترك جديد: " + u.name, body);
  } catch (e) { Logger.log("تعذر إرسال بريد الإشعار: " + e); }
}

/* ============================ التسجيل والدخول ============================ */
function actRegister_(d) {
  var name = String(d.name || "").replace(/^\s+|\s+$/g, "");
  var phone = normPhone_(d.phone), pin = normDigits_(String(d.pin || ""));
  if (name.length < 2) return { ok: false, error: "اكتب اسمك (حرفان على الأقل)." };
  if (!phone) return { ok: false, error: PHONE_ERR };
  if (pin.length < 4) return { ok: false, error: "كلمة السر لا تقل عن 4 أرقام أو حروف." };
  if (!d.consent) return { ok: false, error: "لازم توافق على استلام الرسائل على واتساب." };
  var guardian = "";
  if (String(d.guardian || "").replace(/\s/g, "")) {
    guardian = normPhone_(d.guardian);
    if (!guardian) return { ok: false, error: "رقم ولي الأمر: " + PHONE_ERR };
    if (guardian === phone) return { ok: false, error: "رقم ولي الأمر لازم يكون مختلفًا عن رقمك." };
  }
  var rest = parseRest_(d.rest);
  if (!rest) return { ok: false, error: "اترك يومًا واحدًا على الأقل للحفظ (لا يمكن اختيار كل الأيام كراحة)." };
  var rems = parseTimes_(d.reminders, DEFAULT_REMINDERS);
  if (!rems) return { ok: false, error: "اختر موعد تذكير ملء التقرير (إجباري) — حتى 5 مواعيد." };
  var ts = parseTimes_(d.tasksStudent, DEFAULT_TASKS_STUDENT);
  if (!ts) return { ok: false, error: "اختر موعد «مهام اليوم مرسلة إلى الطالب» (إجباري) — حتى 5 مواعيد." };
  var tg = parseTimes_(d.tasksGuardian, DEFAULT_TASKS_GUARDIAN);
  if (!tg) return { ok: false, error: "اختر موعد «مهام اليوم مرسلة إلى ولي الأمر» (إجباري) — حتى 5 مواعيد." };
  if (findBy_("phone", phone)) return { ok: false, error: "هذا الرقم مسجّل بالفعل. استخدم «تسجيل الدخول»." };
  var known = knownNumbers_(), need = 0;
  if (!known.set[phone]) need++;
  if (guardian && !known.set[guardian]) need++;
  if (known.count + (known.set[phone] ? 0 : 1) > maxNumbers_()) return { ok: false, closed: true, error: closedMsg_() };
  if (known.count + need > maxNumbers_()) return { ok: false, error: "عدد الأرقام المسموح به لا يتسع لرقم ولي الأمر الآن. سجّل بدونه أو تواصل مع الدعم: " + supportLocal_() };
  var salt = rand_(16);
  var u = { row: 0, id: "u" + rand_(12), name: name, phone: phone, guardian: guardian, salt: salt, hash: hashPin_(salt, pin), tokens: [],
            rest: rest, reminders: rems, tasksStudent: ts, tasksGuardian: tg, createdAt: Utilities.formatDate(new Date(), TZ, "yyyy-MM-dd HH:mm") };
  MEMO_USERS_ = null;
  var sh = usersSheet_();
  sh.appendRow([u.id, u.name, u.phone, u.guardian, u.salt, u.hash, "[]", u.createdAt, JSON.stringify(u.rest), JSON.stringify(u.reminders), JSON.stringify(u.tasksStudent), JSON.stringify(u.tasksGuardian)]);
  u.row = sh.getLastRow();
  rememberNumbers_([phone, guardian]);
  if (/^\d{4}-\d{2}-\d{2}$/.test(String(d.start || ""))) {            // تاريخ بداية الخطة المختار عند التسجيل
    var st0 = emptyState_(); st0.start = String(d.start); st0.settingsAt = new Date().getTime();
    saveState_(u.id, st0);
  }
  var token = newToken_(u);
  rosterDirty_();
  armNext_();
  notifyOwner_(u);
  return { ok: true, uid: u.id, token: token, profile: profileOf_(u), state: loadState_(u.id), config: cfg_() };
}

function actLogin_(d) {
  var phone = normPhone_(d.phone), pin = normDigits_(String(d.pin || ""));
  if (!phone || !pin) return { ok: false, error: "اكتب رقم الهاتف (11 رقمًا) وكلمة السر." };
  var cache = CacheService.getScriptCache(), key = "fail_" + phone;
  var fails = Number(cache.get(key) || 0);
  if (fails >= 6) return { ok: false, error: "محاولات كثيرة خاطئة. انتظر 10 دقائق ثم حاول مرة أخرى." };
  var u = findBy_("phone", phone);
  if (!u || u.hash !== hashPin_(u.salt, pin)) {
    cache.put(key, String(fails + 1), 600);
    return { ok: false, error: "الرقم أو كلمة السر غير صحيحة." };
  }
  cache.remove(key);
  var token = newToken_(u);
  return { ok: true, uid: u.id, token: token, profile: profileOf_(u), state: loadState_(u.id), config: cfg_() };
}

/* ============================ الإعدادات ============================ */
function actProfile_(d) {
  var u = auth_(d);
  if (!u) return { ok: false, error: "auth" };
  var cache = CacheService.getScriptCache(), key = "pf_" + u.id;
  var fails = Number(cache.get(key) || 0);
  function passOk(p) { return u.hash === hashPin_(u.salt, normDigits_(String(p || ""))); }

  if (d.name !== undefined) {
    var n = String(d.name).replace(/^\s+|\s+$/g, "");
    if (n.length < 2) return { ok: false, error: "الاسم قصير جدًا." };
    u.name = n;
  }
  if (d.guardian !== undefined) {
    var raw = String(d.guardian).replace(/\s/g, "");
    if (!raw) u.guardian = "";
    else {
      var g = normPhone_(raw);
      if (!g) return { ok: false, error: "رقم ولي الأمر: " + PHONE_ERR };
      if (g === u.phone) return { ok: false, error: "رقم ولي الأمر لازم يكون مختلفًا عن رقمك." };
      var known = knownNumbers_();
      if (g !== u.guardian && !known.set[g] && known.count + 1 > maxNumbers_()) return { ok: false, error: "عدد الأرقام المسموح به اكتمل حاليًا، لا يمكن إضافة رقم جديد. تواصل مع الدعم: " + supportLocal_() };
      u.guardian = g;
      rememberNumbers_([g]);
    }
  }
  if (d.rest !== undefined) {
    var rs = parseRest_(d.rest);
    if (!rs) return { ok: false, error: "اترك يومًا واحدًا على الأقل للحفظ." };
    u.rest = rs;
  }
  if (d.reminders !== undefined) {
    var rm = parseTimes_(d.reminders, DEFAULT_REMINDERS);
    if (!rm) return { ok: false, error: "اختر موعد تذكير ملء التقرير (إجباري) — حتى 5 مواعيد." };
    u.reminders = rm;
  }
  if (d.tasksStudent !== undefined) {
    var tsv = parseTimes_(d.tasksStudent, DEFAULT_TASKS_STUDENT);
    if (!tsv) return { ok: false, error: "اختر موعد «مهام اليوم مرسلة إلى الطالب» (إجباري) — حتى 5 مواعيد." };
    u.tasksStudent = tsv;
  }
  if (d.tasksGuardian !== undefined) {
    var tgv = parseTimes_(d.tasksGuardian, DEFAULT_TASKS_GUARDIAN);
    if (!tgv) return { ok: false, error: "اختر موعد «مهام اليوم مرسلة إلى ولي الأمر» (إجباري) — حتى 5 مواعيد." };
    u.tasksGuardian = tgv;
  }
  if (d.phone !== undefined) {                          // تغيير الرقم يحتاج كلمة السر الحالية
    var np = normPhone_(d.phone);
    if (!np) return { ok: false, error: PHONE_ERR };
    if (np !== u.phone) {
      if (fails >= 6) return { ok: false, error: "محاولات كثيرة. انتظر 10 دقائق." };
      if (!passOk(d.password)) { cache.put(key, String(fails + 1), 600); return { ok: false, error: "كلمة السر الحالية غير صحيحة." }; }
      var other = findBy_("phone", np);
      if (other && other.id !== u.id) return { ok: false, error: "هذا الرقم مستخدم في حساب آخر." };
      var kn = knownNumbers_();
      if (!kn.set[np] && kn.count + 1 > maxNumbers_()) return { ok: false, error: "عدد الأرقام المسموح به اكتمل حاليًا، لا يمكن استخدام رقم جديد. تواصل مع الدعم: " + supportLocal_() };
      u.phone = np;
      rememberNumbers_([np]);
    }
  }
  if (d.newPin !== undefined) {                         // تغيير كلمة السر يحتاج القديمة
    var npn = normDigits_(String(d.newPin));
    if (npn.length < 4) return { ok: false, error: "كلمة السر الجديدة لا تقل عن 4 أرقام أو حروف." };
    if (fails >= 6) return { ok: false, error: "محاولات كثيرة. انتظر 10 دقائق." };
    if (!passOk(d.oldPin)) { cache.put(key, String(fails + 1), 600); return { ok: false, error: "كلمة السر القديمة غير صحيحة." }; }
    u.salt = rand_(16); u.hash = hashPin_(u.salt, npn);
  }
  writeUser_(u);
  rosterDirty_();
  armNext_();                                           // يضبط المشغّل الدقيق على أقرب موعد حسب المواعيد المحفوظة الآن
  return { ok: true, profile: profileOf_(u) };
}

/* ===== استرجاع كلمة السر برمز على واتساب (غير مفعّل حتى تضع اسم قالب الرمز في RESET_TEMPLATE_NAME) ===== */
function actResetRequest_(d) {
  var phone = normPhone_(d.phone);
  if (!phone) return { ok: false, error: PHONE_ERR };
  if (!RESET_TEMPLATE_NAME) return { ok: false, error: "استرجاع كلمة السر بالواتساب غير مفعّل بعد. تواصل مع الدعم لإعادة تعيينها: " + supportLocal_() };
  var cache = CacheService.getScriptCache(), rk = "rstreq_" + phone, cnt = Number(cache.get(rk) || 0);
  if (cnt >= 3) return { ok: false, error: "طلبات كثيرة. حاول بعد ساعة أو تواصل مع الدعم: " + supportLocal_() };
  cache.put(rk, String(cnt + 1), 3600);
  var u = findBy_("phone", phone);
  if (u) {
    var code = String(Math.floor(100000 + Math.random() * 900000));
    cache.put("rst_" + u.id, hashPin_(u.salt, code), 600);
    cache.put("rstn_" + u.id, "0", 600);
    waCall_({ messaging_product: "whatsapp", to: u.phone, type: "template",
              template: { name: RESET_TEMPLATE_NAME, language: { code: RESET_TEMPLATE_LANG },
                          components: [{ type: "body", parameters: [{ type: "text", text: code }] }] } });
  }
  return { ok: true, message: "إن كان الرقم مسجّلًا فسيصلك رمز من 6 أرقام على واتساب (صالح 10 دقائق)." };
}
function actResetConfirm_(d) {
  var phone = normPhone_(d.phone), code = normDigits_(String(d.code || "")), pin = normDigits_(String(d.pin || ""));
  if (!phone || !code) return { ok: false, error: "اكتب الرقم والرمز." };
  if (pin.length < 4) return { ok: false, error: "كلمة السر الجديدة لا تقل عن 4 أرقام أو حروف." };
  var u = findBy_("phone", phone), cache = CacheService.getScriptCache();
  if (!u) return { ok: false, error: "الرمز غير صحيح أو منتهي." };
  var tries = Number(cache.get("rstn_" + u.id) || 0), stored = cache.get("rst_" + u.id);
  if (!stored || tries >= 5) return { ok: false, error: "الرمز غير صحيح أو منتهي. اطلب رمزًا جديدًا." };
  if (stored !== hashPin_(u.salt, code)) { cache.put("rstn_" + u.id, String(tries + 1), 600); return { ok: false, error: "الرمز غير صحيح." }; }
  u.salt = rand_(16); u.hash = hashPin_(u.salt, pin); u.tokens = [];
  writeUser_(u);
  cache.remove("rst_" + u.id);
  return { ok: true, message: "تم تغيير كلمة السر. سجّل الدخول بها الآن." };
}

/* ============================ حالة كل مشترك ============================ */
function emptyState_() { return { v: 2, start: "", settingsAt: 0, reports: {}, comps: [], kahf: {} };   /* base/prevStart اختياريان: نقطة انطلاق الخطة الجديدة */ }
function stateSheetName_(uid) { return "s_" + uid; }
function loadState_(uid) {
  var sh = ss_().getSheetByName(stateSheetName_(uid));
  if (!sh) return emptyState_();
  var last = sh.getLastRow();
  if (last < 1) return emptyState_();
  var vals = sh.getRange(1, 1, last, 1).getValues(), txt = "";
  for (var i = 0; i < vals.length; i++) txt += String(vals[i][0]);
  try { var s = JSON.parse(txt); s.reports = s.reports || {}; s.comps = s.comps || []; s.kahf = s.kahf || {}; return s; }
  catch (e) { return emptyState_(); }
}
function saveState_(uid, s) {
  var name = stateSheetName_(uid), sh = ss_().getSheetByName(name);
  if (!sh) { sh = ss_().insertSheet(name); try { sh.hideSheet(); } catch (e) {} }
  var txt = JSON.stringify(s), size = 40000, rows = [];
  for (var i = 0; i < txt.length; i += size) rows.push([txt.substring(i, i + size)]);
  sh.clear();
  sh.getRange(1, 1, rows.length, 1).setValues(rows);
}
function mergeState_(a, b) {
  var out = emptyState_(), k;
  if ((b.settingsAt || 0) > (a.settingsAt || 0)) { out.start = b.start || ""; out.settingsAt = b.settingsAt || 0; if (b.base) out.base = b.base; if (b.prevStart) out.prevStart = b.prevStart; if (b.tpd) out.tpd = b.tpd; }
  else { out.start = a.start || ""; out.settingsAt = a.settingsAt || 0; if (a.base) out.base = a.base; if (a.prevStart) out.prevStart = a.prevStart; if (a.tpd) out.tpd = a.tpd; }
  var names = ["reports", "kahf"];
  for (var n = 0; n < names.length; n++) {
    var nm = names[n], A = a[nm] || {}, B = b[nm] || {};
    for (k in A) out[nm][k] = A[k];
    for (k in B) { if (!out[nm][k] || (B[k].at || 0) > (out[nm][k].at || 0)) out[nm][k] = B[k]; }
  }
  var seen = {}, list = (a.comps || []).concat(b.comps || []);
  for (var i = 0; i < list.length; i++) { if (!seen[list[i].id]) { seen[list[i].id] = 1; out.comps.push(list[i]); } }
  return out;
}
function actGet_(d) {
  var u = auth_(d);
  if (!u) return { ok: false, error: "auth" };
  return { ok: true, state: loadState_(u.id), profile: profileOf_(u), config: cfg_() };
}

/* ===== حفظ التقرير: يُرسل لولي الأمر فورًا (بدون انتظار أي موعد) ===== */
function actSave_(d) {
  var u = auth_(d);
  if (!u) return { ok: false, error: "auth" };
  var result = { ok: true };
  if (d.state) saveState_(u.id, mergeState_(loadState_(u.id), d.state));
  var dup = false;
  if (d.reqId) {                                        // منع تكرار الرسائل لو وصل نفس الطلب مرتين
    var cache = CacheService.getScriptCache(), rk = "req_" + String(d.reqId).substring(0, 80);
    if (cache.get(rk)) dup = true; else cache.put(rk, "1", 21600);
  }
  if (dup) { result.duplicate = true; return result; }
  if (d.kind === "report" || d.kind === "friday") logRow_(u, d);
  if (d.kind === "report" && d.notify && u.guardian) {
    result.guardian = sendParentReport_(u, String(d.n || "-"), d.gdetail ? d.gdetail : d.notify);
  }
  if (d.kind === "friday" && u.guardian && d.examId) {   // تقرير الجمعة: بدل «الكنز والثابت» تُرسل تفاصيل الاختبار (من نتيجته المحفوظة على الخادم لا من المتصفح)
    var exr = examResultFor_(u.id, String(d.examId));
    if (exr && exr.mode === "official" && String(exr.date) === String(d.date)) result.guardian = sendParentReport_(u, "الجمعة", examDetail_(exr, d.kahf));
  }
  return result;
}
function logRow_(u, d) {
  var sh = ss_().getSheetByName(LOG_SHEET);
  if (!sh) {
    sh = ss_().insertSheet(LOG_SHEET);
    sh.appendRow(["التاريخ", "الاسم", "الرقم", "رقم اليوم", "النوع", "نص التقرير", "وقت الإرسال"]);
  }
  sh.appendRow([d.date || "", u.name, "'" + u.phone, d.n || "", d.kind || "", d.notify || "", Utilities.formatDate(new Date(), TZ, "yyyy-MM-dd HH:mm")]);
}

/* ============================ واتساب (القوالب الأربعة) ============================ */
function waCall_(payload) {
  var token = PropertiesService.getScriptProperties().getProperty("WHATSAPP_TOKEN");
  if (!token) return { ok: false, error: "WHATSAPP_TOKEN غير موجود في خصائص النص البرمجي" };
  var url = "https://graph.facebook.com/v23.0/" + PHONE_NUMBER_ID + "/messages";
  var res = UrlFetchApp.fetch(url, {
    method: "post", contentType: "application/json",
    headers: { Authorization: "Bearer " + token },
    payload: JSON.stringify(payload), muteHttpExceptions: true
  });
  var code = res.getResponseCode();
  return { ok: code >= 200 && code < 300, code: code, body: res.getContentText() };
}
function tplKeyOf_(tpl) { for (var k in TPL) if (TPL[k] === tpl) return k; return ""; }
function paramsFor_(vars, ctx) {
  var params = [], i, v, val;
  for (i = 0; i < vars.length; i++) {
    v = vars[i];
    val = ctx[v];
    if (v === "tasks" && vars.indexOf("name") < 0 && ctx.tasksNamed) val = ctx.tasksNamed;     // لو القالب بلا متغير للاسم نضع اسم الطالب داخل نص المهام
    params.push({ type: "text", text: String(val === undefined || val === "" ? "-" : val) });
  }
  return params;
}
function buildTpl_(to, tpl, vars, ctx, nm) {
  nm = nm || { name: tpl.name, lang: tpl.lang };
  return { messaging_product: "whatsapp", to: to, type: "template",
           template: { name: nm.name, language: { code: nm.lang }, components: [{ type: "body", parameters: paramsFor_(vars, ctx) }] } };
}
function chosenName_(key) {                             // الاسم/اللغة اللذان نجحا آخر مرة لهذا القالب (لو اختلفا عن المكتوب في الإعدادات)
  try { var v = PropertiesService.getScriptProperties().getProperty("tn_" + key); if (v) { var o = JSON.parse(v); if (o && o.name && o.lang) return o; } } catch (e) {}
  return null;
}
function chosenVars_(key) {                            // الترتيب الذي نجح آخر مرة لهذا القالب (إن وُجد)
  try { var v = PropertiesService.getScriptProperties().getProperty("tv_" + key); if (v) { var a = JSON.parse(v); if (a && a.length) return a; } } catch (e) {}
  return null;
}
function tplPayload_(to, tpl, ctx) {                    // يبني رسالة قالب حسب ترتيب vars (أو الترتيب الذي نجح سابقًا)
  var key = tplKeyOf_(tpl), vars = (key && chosenVars_(key)) || tpl.vars, nm = (key && chosenName_(key)) || { name: tpl.name, lang: tpl.lang };
  var payload = buildTpl_(to, tpl, vars, ctx, nm);
  try { Object.defineProperty(payload, "_re", { value: { key: key, tpl: tpl, ctx: ctx, to: to, used: vars, nm: nm }, enumerable: false }); } catch (e) {}
  return payload;
}
// سجل الإرسال: ورقة مقروءة تبيّن كل محاولة إرسال ونتيجتها وسبب الفشل إن وُجد
function metaError_(res) {
  try { var e = JSON.parse(res.body).error; return e.code + " — " + (e.error_data && e.error_data.details ? e.error_data.details : e.message); } catch (x) { return res.error || res.body || ""; }
}
function logSend_(u, type, to, res) {
  try {
    var sh = ss_().getSheetByName("سجل الإرسال");
    if (!sh) { sh = ss_().insertSheet("سجل الإرسال"); sh.appendRow(["الوقت", "الاسم", "النوع", "إلى", "النتيجة", "التفاصيل"]); }
    sh.appendRow([Utilities.formatDate(new Date(), TZ, "yyyy-MM-dd HH:mm"), u ? u.name : "", type, "'" + localPhone_(to), res && res.ok ? "✅ أُرسل" : "❌ فشل", res && res.ok ? "" : metaError_(res || {})]);
  } catch (e) {}
}
function metaCode_(res) { try { return Number(JSON.parse(res.body).error.code); } catch (x) { return 0; } }
function sendLogged_(u, type, payload) {                // يرسل ويسجّل النتيجة؛ عند خطأ «القالب غير موجود/عدد المتغيرات» يجرّب بدائله (اسم/لغة/ترتيب) ويتذكر الناجح
  var res = waCall_(payload), re = payload._re, code = metaCode_(res), note = "";
  if (!res.ok && re && re.tpl && (code === 132000 || code === 132012 || code === 132001)) {
    var tpl = re.tpl, names = (tpl.names || [tpl.name]).slice(), langs = [tpl.lang], combos = [], dead = {}, tried = {}, i, j, k, r, c, done = false;
    if (langs.indexOf("ar_EG") < 0) langs.push("ar_EG"); if (langs.indexOf("ar") < 0) langs.push("ar");
    combos.push(re.nm); for (i = 0; i < names.length; i++) for (j = 0; j < langs.length; j++) if (!(names[i] === re.nm.name && langs[j] === re.nm.lang)) combos.push({ name: names[i], lang: langs[j] });
    var vlist = [re.used], vk; [tpl.vars].concat(tpl.alts || []).forEach(function (v) { if (JSON.stringify(v) !== JSON.stringify(re.used)) vlist.push(v); });
    if (code === 132001) dead[re.nm.name + "|" + re.nm.lang] = 1;
    tried[re.nm.name + "|" + re.nm.lang + "|" + JSON.stringify(re.used)] = 1;
    for (i = 0; i < combos.length && !done; i++) {
      if (dead[combos[i].name + "|" + combos[i].lang]) continue;
      for (k = 0; k < vlist.length; k++) {
        vk = combos[i].name + "|" + combos[i].lang + "|" + JSON.stringify(vlist[k]);
        if (tried[vk]) continue; tried[vk] = 1;
        r = waCall_(buildTpl_(re.to, tpl, vlist[k], re.ctx, combos[i])); c = metaCode_(r);
        if (r.ok) {
          res = r; done = true;
          try {
            var P = PropertiesService.getScriptProperties();
            P.setProperty("tv_" + re.key, JSON.stringify(vlist[k]));
            if (combos[i].name !== tpl.name || combos[i].lang !== tpl.lang) P.setProperty("tn_" + re.key, JSON.stringify(combos[i]));
          } catch (e) {}
          note = " [قالب: " + combos[i].name + "/" + combos[i].lang + " | متغيرات: " + vlist[k].join("+") + "]";
          break;
        }
        if (c === 132001) { dead[combos[i].name + "|" + combos[i].lang] = 1; break; }      // هذا الاسم/اللغة غير موجود في Meta: ننتقل للتالي
        if (c !== 132000 && c !== 132012) { res = r; done = true; break; }                  // خطأ آخر (رقم غير مضاف/قالب غير معتمد...): لا فائدة من التجربة
        res = r;                                                                            // القالب موجود لكن المتغيرات لا تطابق: نجرّب ترتيبًا آخر
      }
    }
  }
  logSend_(u, type + note, payload.to, res);
  return res;
}

// 1) تذكير الطالب بملء التقرير
function reportReminderPayload_(u, label, today) { return tplPayload_(u.phone, TPL.studentReportReminder, { day: label, link: SITE_URL + "/report.html?d=" + today }); }
// 2) تقرير الطالب لولي الأمر: القالب المعتمد متغيران فقط ({{1}} رقم اليوم ، {{2}} تفاصيل التقرير كاملة) — بدون اسم الطالب
function parentReportPayload_(u, label, detail) {
  return tplPayload_(u.guardian, TPL.parentReport, { day: label, detail: oneLine_(detail) });
}
function sendParentReport_(u, label, detail) { return sendLogged_(u, "تقرير لولي الأمر", parentReportPayload_(u, label, detail)); }
// 3) مهام اليوم للطالب (المهام داخل الرسالة فقط لو قالبك فيه المتغير tasks)
function studentTasksPayload_(u, label, line, today) { return tplPayload_(u.phone, TPL.studentTasks, { day: label, tasks: oneLine_(line), link: SITE_URL + "/today.html?d=" + today }); }
// 4) مهام اليوم لولي الأمر (بدون رابط)
function parentTasksPayload_(u, label, line) {
  var t = oneLine_(line);
  return tplPayload_(u.guardian, TPL.parentTasks, { day: label, name: u.name, tasks: t, tasksNamed: oneLine_("الطالب " + u.name + ": " + t) });
}

/* ===== مهام اليوم (تعتمد على Engine.gs) ===== */
function tasksLine_(d) {
  if (!d) return "";
  if (d.isFriday) return "سورة الكهف";
  var parts = [], i;
  if (d.nw) parts.push("الجديد: سورة المائدة، " + (d.nw.from === d.nw.to ? "الآية " + d.nw.from : "الآيات " + d.nw.from + "–" + d.nw.to));
  if (d.t) {
    var ss = [];
    for (i = 0; i < d.t.segs.length; i++) { var sg = d.t.segs[i]; ss.push("ربع " + sg.u + " (" + sg.info.title + (sg.info.ayat ? " " + sg.info.ayat : "") + ")"); }
    parts.push("الكنز: " + ss.join(" + "));
  }
  if (d.fx) parts.push("التثبيت: مراجعة " + QT.fxText(d) + " من المائدة");
  return parts.join(" | ");
}
function cfg_() { return { newPlanStart: npStart_() }; }
function dayOf_(u, st, today) {                         // يوم المشترك (أو null لو راحة/خارج الخطة)
  if (!st.start || today < st.start) return null;
  QT_CONFIG.NEW_PLAN_START = npStart_();
  QT.setRest(u.rest || DEFAULT_REST);
  var M = QT.compute(st, today);
  return M ? (M.byDate[today] || null) : null;
}
function dayLabel_(d) { return d.isFriday ? "الجمعة" : String(d.n); }
function hasReport_(st, date) { var r = st.reports && st.reports[date]; return !!(r && !r.cancelled); }

/* ============================ المواعيد (كل مشترك بمواعيده) ============================ */
// فكرة الجدولة: مشغّل واحد كل TICK_MINUTES دقائق يقرأ مواعيد كل مشترك المحفوظة حاليًا في الورقة (فلا يحتاج ضبطًا عند تغيير الموعد).
// • موعد خلال الدقائق القادمة (أقل من LOOKAHEAD_SEC): ينتظر الفحص حتى الموعد ثم يرسل (بدقة الثواني تقريبًا).
// • موعد مرّ قبل أقل من GRACE_MIN دقيقة ولم تُرسل رسالته: تُرسل فورًا (لا تضيع ولا تتأجل لبكرة).
// • كل (نوع، مشترك، تاريخ، موعد) يُرسل مرة واحدة فقط (علامة محفوظة في خصائص النص البرمجي) فلا تتكرر الرسائل.
function sentKey_(kind, uid, today, time) { return "s|" + kind + "|" + uid + "|" + today + "|" + time; }
function wasSent_(kind, u, today, time) { return !!PropertiesService.getScriptProperties().getProperty(sentKey_(kind, u.id, today, time)); }
function markSent_(kind, u, today, time) { PropertiesService.getScriptProperties().setProperty(sentKey_(kind, u.id, today, time), String(new Date().getTime())); }
// «حجز» الرسالة قبل الانتظار حتى موعدها: يمنع أن يرسلها فحصان متداخلان معًا (الحجز ينتهي بعد 8 دقائق لو تعثر صاحبه)
function claimKey_(kind, uid, today, time) { return "c|" + kind + "|" + uid + "|" + today + "|" + time; }
function claim_(kind, u, today, time) {
  var P = PropertiesService.getScriptProperties(), key = claimKey_(kind, u.id, today, time), lock = LockService.getScriptLock(), locked = false, now = new Date().getTime();
  var token = rand_(8) + "@" + now;
  try { locked = lock.tryLock(3000); } catch (e) {}      // لو كان القفل مشغولًا بطلب من الموقع لا نُسقط الرسالة (كان هذا يؤخرها 5 دقائق): نحجزها بعلامة فريدة ونتأكد منها
  try {
    var v = P.getProperty(key);
    if (v) { var parts = String(v).split("@"), t0 = Number(parts[parts.length - 1]) || 0; if (now - t0 <= 8 * 60 * 1000) return false; }
    P.setProperty(key, token);
    if (locked) return true;
    Utilities.sleep(300);
    return P.getProperty(key) === token;
  } catch (e2) { return false; } finally { if (locked) { try { lock.releaseLock(); } catch (x) {} } }
}
function unclaim_(kind, u, today, time) { try { PropertiesService.getScriptProperties().deleteProperty(claimKey_(kind, u.id, today, time)); } catch (e) {} }
function cleanupSent_(today) {                          // مرة في اليوم: نحذف علامات الأيام السابقة
  var P = PropertiesService.getScriptProperties();
  if (P.getProperty("cleanDay") === today) return;
  var keys = P.getKeys(), i;
  for (i = 0; i < keys.length; i++) { var p = keys[i].split("|"); if ((p[0] === "s" || p[0] === "c") && p[3] && p[3] < today) P.deleteProperty(keys[i]); }
  P.setProperty("cleanDay", today);
}
function timeMin_(t) { var p = t.split(":"); return Number(p[0]) * 60 + Number(p[1]); }

// يجمع كل الرسائل التي لها موعد حان أو يحين خلال نافذة النظر للأمام
function collectJobs_(users, today, jsDay, nowSec) {
  var jobs = [], i, k, j;
  var kinds = [["ts", "tasksStudent", false], ["tg", "tasksGuardian", true], ["rr", "reminders", false]];
  for (i = 0; i < users.length; i++) {
    var u = users[i], rest = u.rest || DEFAULT_REST;
    if (jsDay !== 5 && rest.indexOf(jsDay) > -1) continue;                                      // يوم راحة هذا المشترك
    for (k = 0; k < kinds.length; k++) {
      if (kinds[k][2] && !u.guardian) continue;                                                  // مهام ولي الأمر لمن له ولي أمر فقط
      var times = u[kinds[k][1]] || [];
      for (j = 0; j < times.length; j++) {
        var t = timeMin_(times[j]) * 60, late = nowSec - t;                                      // late > 0: مرّ الموعد
        if (late >= 0 && late < GRACE_MIN * 60) jobs.push({ u: u, kind: kinds[k][0], time: times[j], at: t });
        else if (late < 0 && -late <= LOOKAHEAD_SEC) jobs.push({ u: u, kind: kinds[k][0], time: times[j], at: t });
      }
    }
  }
  jobs.sort(function (a, b) { return a.at - b.at; });
  return jobs;
}
// ينفّذ رسالة واحدة (بعد التأكد من الشروط وقت الإرسال الفعلي)
function runJob_(job, today) {
  var u = job.u, kind = job.kind;
  if (wasSent_(kind, u, today, job.time)) return "سبق إرسالها";
  var st = loadState_(u.id), d = dayOf_(u, st, today);
  if (npStart_() && today >= npStart_() && !st.base) return "لم يحدّد المشترك بعد «وين وصلت» (الربع في الكنز وآخر آية في الجديد) — لا نخمّن، لن تُرسل مهام حتى يحدده من الصفحة الرئيسية";
  if (!d) return "لا مهام اليوم (راحة أو الخطة لم تبدأ/لم يُحدَّد تاريخ بدايتها)";
  var res, type;
  if (kind === "ts") {
    var l1 = tasksLine_(d); if (!l1) return "لا مهام اليوم";
    res = sendLogged_(u, "مهام اليوم للطالب", studentTasksPayload_(u, dayLabel_(d), l1, today));
  } else if (kind === "tg") {
    var l2 = tasksLine_(d); if (!l2) return "لا مهام اليوم";
    res = sendLogged_(u, "مهام اليوم لولي الأمر", parentTasksPayload_(u, dayLabel_(d), l2));
  } else {
    if (d.isFriday) { if (st.kahf && st.kahf[today]) return "سجّل الكهف"; }
    else if (hasReport_(st, today)) return "سجّل تقرير اليوم";
    res = sendLogged_(u, "تذكير ملء التقرير", reportReminderPayload_(u, dayLabel_(d), today));
  }
  if (res.ok) { markSent_(kind, u, today, job.time); return "أُرسلت"; }
  return "فشل: " + metaError_(res);                                                              // لا نحجز الموعد: تُعاد المحاولة في الفحص التالي ضمن ساعة السماح
}
function tick() {                                       // يعمل كل TICK_MINUTES دقائق
  var P = PropertiesService.getScriptProperties(), t0 = new Date().getTime();
  try {
    memoReset_();
    P.setProperty("lastTick", String(t0));
    var now = new Date();
    var today = Utilities.formatDate(now, TZ, "yyyy-MM-dd");
    var hms = Utilities.formatDate(now, TZ, "HH:mm:ss").split(":");
    var nowSec = Number(hms[0]) * 3600 + Number(hms[1]) * 60 + Number(hms[2]);
    var u7 = Number(Utilities.formatDate(now, TZ, "u"));  // الاثنين=1 ... الأحد=7
    var jsDay = (u7 === 7) ? 0 : u7;
    ensureSchema_();
    var users = readUsers_();
    var jobs = collectJobs_(users, today, jsDay, nowSec), i, summary = [];
    for (i = 0; i < jobs.length; i++) {
      var job = jobs[i];
      if (wasSent_(job.kind, job.u, today, job.time)) continue;                                  // أُرسلت من قبل
      if (!claim_(job.kind, job.u, today, job.time)) { summary.push(job.kind + "/" + job.u.name + "/" + job.time + ": تتولاها عملية أخرى"); continue; }
      var waitSec = job.at - (nowSec + (new Date().getTime() - t0) / 1000);
      if (waitSec > 0.5) {                                                                        // الموعد لم يحن: ننتظر حتى لحظته
        if ((new Date().getTime() - t0) / 1000 + waitSec > MAX_RUN_SEC) { unclaim_(job.kind, job.u, today, job.time); summary.push("تأجيل للفحص التالي: " + job.u.name); continue; }
        Utilities.sleep(Math.round(waitSec * 1000));
      }
      var r;
      try { r = runJob_(job, today); } catch (e1) { r = "خطأ: " + e1; Logger.log("خطأ في مهمة " + job.kind + " للمشترك " + job.u.name + ": " + e1); }
      if (r !== "أُرسلت") unclaim_(job.kind, job.u, today, job.time);                            // لم تُرسل: نفك الحجز لتُعاد المحاولة في الفحص التالي ضمن ساعة السماح
      summary.push(job.kind + "/" + job.u.name + "/" + job.time + ": " + r);
    }
    P.setProperty("lastTickSummary", (summary.join(" | ") || "لا مواعيد الآن").substring(0, 800));
    cleanupSent_(today);
    if (P.getProperty("rosterDirty") === "1") { try { syncRoster_(); P.deleteProperty("rosterDirty"); } catch (e2) { Logger.log("roster: " + e2); } }
    autoBackup_(today, nowSec);
    armNext_();
  } catch (err) {
    try { P.setProperty("lastTickError", Utilities.formatDate(new Date(), TZ, "yyyy-MM-dd HH:mm") + " — " + String(err)); } catch (x) {}
    Logger.log("خطأ في tick: " + err);
  }
}

/* ===== مشغّل دقيق إضافي: «fireDue» يُضبط على أقرب موعد إرسال قادم (بالثانية تقريبًا) ويُعاد ضبطه بعد كل فحص وكل حفظ لمواعيد ===== */
function nextJobEpoch_() {                              // أقرب موعد إرسال لم يُرسل بعد (اليوم، وإلا أول موعد غدًا) بالمللي ثانية
  var now = new Date(), today = Utilities.formatDate(now, TZ, "yyyy-MM-dd");
  var hms = Utilities.formatDate(now, TZ, "HH:mm:ss").split(":"), nowSec = Number(hms[0]) * 3600 + Number(hms[1]) * 60 + Number(hms[2]);
  var u7 = Number(Utilities.formatDate(now, TZ, "u")), jsDay = (u7 === 7) ? 0 : u7;
  var users = readUsers_(), keys = [["ts", "tasksStudent", false], ["tg", "tasksGuardian", true], ["rr", "reminders", false]], i, k, j;
  var bestToday = null, bestAny = null;
  for (i = 0; i < users.length; i++) {
    var u = users[i], rest = u.rest || DEFAULT_REST;
    for (k = 0; k < keys.length; k++) {
      if (keys[k][2] && !u.guardian) continue;
      var times = u[keys[k][1]] || [];
      for (j = 0; j < times.length; j++) {
        var t = timeMin_(times[j]) * 60;
        if (bestAny === null || t < bestAny) bestAny = t;
        if (t <= nowSec) continue;
        if (jsDay !== 5 && rest.indexOf(jsDay) > -1) continue;
        if (wasSent_(keys[k][0], u, today, times[j])) continue;
        if (bestToday === null || t < bestToday) bestToday = t;
      }
    }
  }
  var base = now.getTime() - now.getMilliseconds();
  if (bestToday !== null) return base + (bestToday - nowSec) * 1000;
  if (bestAny !== null) return base + (86400 + bestAny - nowSec) * 1000;
  return 0;
}
function armNext_() {
  try {
    var P = PropertiesService.getScriptProperties(), target = nextJobEpoch_(), all = ScriptApp.getProjectTriggers(), mine = [], i;
    for (i = 0; i < all.length; i++) if (all[i].getHandlerFunction() === "fireDue") mine.push(all[i]);
    if (!target) { for (i = 0; i < mine.length; i++) ScriptApp.deleteTrigger(mine[i]); P.deleteProperty("armedAt"); return; }
    if (mine.length === 1 && P.getProperty("armedAt") === String(target)) return;      // مضبوط على نفس الموعد بالفعل
    for (i = 0; i < mine.length; i++) ScriptApp.deleteTrigger(mine[i]);
    ScriptApp.newTrigger("fireDue").timeBased().at(new Date(target)).create();
    P.setProperty("armedAt", String(target));
  } catch (e) {
    try { PropertiesService.getScriptProperties().setProperty("lastArmError", Utilities.formatDate(new Date(), TZ, "yyyy-MM-dd HH:mm") + " — " + String(e)); } catch (x) {}
    Logger.log("armNext_: " + e);                       // فشل الضبط الدقيق لا يوقف شيئًا: فحص tick كل 5 دقائق يغطي الإرسال
  }
}
function fireDue() { tick(); }                          // يستدعيه المشغّل الدقيق عند الموعد: نفس نظام الإرسال العادي بالضبط

/* شغّل هذه الدالة مرة واحدة (وكل مرة تحدّث فيها الكود): تنشئ فحص المواعيد كل TICK_MINUTES دقائق + المشغّل الدقيق، وتجدد صلاحياتهما */
function setupTriggers() {
  var all = ScriptApp.getProjectTriggers();
  for (var i = 0; i < all.length; i++) {
    var f = all[i].getHandlerFunction();
    if (f === "tick" || f === "fireDue" || f === "reminderSix" || f === "reminderTen") ScriptApp.deleteTrigger(all[i]);
  }
  ScriptApp.newTrigger("tick").timeBased().everyMinutes(TICK_MINUTES).create();
  try { PropertiesService.getScriptProperties().deleteProperty("armedAt"); } catch (e) {}
  armNext_();
  Logger.log("تم إنشاء فحص المواعيد كل " + TICK_MINUTES + " دقائق + مشغّل دقيق للموعد القادم. بعد 10 دقائق شغّل testTrigger لتتأكد أنه يعمل.");
}

/* ============================ حماية البيانات: بنية + نسخ احتياطي + ترحيل ============================ */
function backupAll() {                                  // نسخة احتياطية كاملة (المستخدمون + حالة كل مشترك) في ورقة جديدة اسمها «نسخة_تاريخ»
  var ss = ss_(), name = "نسخة_" + Utilities.formatDate(new Date(), TZ, "yyyyMMdd_HHmm"), sh = ss.getSheetByName(name);
  if (sh) return name;
  sh = ss.insertSheet(name);
  var rows = [["type", "id", "idx", "data"]], users = readUsers_(), i, k;
  for (i = 0; i < users.length; i++) {
    var u = users[i];
    rows.push(["user", u.id, 0, JSON.stringify({ name: u.name, phone: u.phone, guardian: u.guardian, salt: u.salt, hash: u.hash, tokens: u.tokens, createdAt: u.createdAt, rest: u.rest, reminders: u.reminders, tasksStudent: u.tasksStudent, tasksGuardian: u.tasksGuardian })]);
    var ssh = ss.getSheetByName(stateSheetName_(u.id));
    if (ssh && ssh.getLastRow() > 0) {
      var vals = ssh.getRange(1, 1, ssh.getLastRow(), 1).getValues();
      for (k = 0; k < vals.length; k++) rows.push(["state", u.id, k, String(vals[k][0])]);
    }
  }
  sh.getRange(1, 1, rows.length, 4).setNumberFormat("@");
  sh.getRange(1, 1, rows.length, 4).setValues(rows);
  try { sh.hideSheet(); } catch (e) {}
  // نحتفظ بآخر BACKUPS_KEEP نسخ فقط
  var all = ss.getSheets(), names = [];
  for (i = 0; i < all.length; i++) if (all[i].getName().indexOf("نسخة_") === 0) names.push(all[i].getName());
  names.sort();
  while (names.length > BACKUPS_KEEP) { var old = ss.getSheetByName(names.shift()); if (old) ss.deleteSheet(old); }
  PropertiesService.getScriptProperties().setProperty("lastBackup", Utilities.formatDate(new Date(), TZ, "yyyy-MM-dd"));
  return name;
}
function autoBackup_(today, nowSec) {                   // نسخة تلقائية مرة في اليوم بعد الثالثة فجرًا
  var P = PropertiesService.getScriptProperties();
  if (nowSec < 3 * 3600 || P.getProperty("lastBackup") === today) return;
  try { backupAll(); } catch (e) { Logger.log("backup: " + e); }
}
function ensureSchema_() {                              // عند تغيير البنية: نسخة احتياطية أولًا ثم ترحيل آمن (لا حذف لأي بيانات)
  var P = PropertiesService.getScriptProperties();
  if (P.getProperty("schema") === SCHEMA_VERSION) return;
  var sh = usersSheet_();
  if (sh.getLastRow() >= 2) { try { backupAll(); } catch (e) { Logger.log("backup قبل الترحيل: " + e); } }
  var header = ["id", "name", "phone", "guardian", "salt", "hash", "tokens", "createdAt", "rest", "reminders", "tasksStudent", "tasksGuardian"];
  sh.getRange(1, 1, 1, header.length).setValues([header]);
  sh.getRange("A:L").setNumberFormat("@");               // كل الأعمدة نصية حتى لا تتحول الأرقام والرموز السداسية عشرية إلى أرقام
  var last = sh.getLastRow();
  if (last >= 2) {                                      // نملأ الأعمدة الناقصة بالقيم الافتراضية دون المساس بالموجود
    var vals = sh.getRange(2, 9, last - 1, 4).getValues(), r;
    for (r = 0; r < vals.length; r++) {
      if (!vals[r][0]) vals[r][0] = JSON.stringify(DEFAULT_REST);
      if (!vals[r][1]) vals[r][1] = JSON.stringify(DEFAULT_REMINDERS);
      if (!vals[r][2]) vals[r][2] = JSON.stringify(DEFAULT_TASKS_STUDENT);
      if (!vals[r][3]) vals[r][3] = JSON.stringify(DEFAULT_TASKS_GUARDIAN);
    }
    sh.getRange(2, 9, last - 1, 4).setValues(vals);
  }
  MEMO_USERS_ = null;
  P.setProperty("schema", SCHEMA_VERSION);
}

/* ============================ أدوات للمالك ============================ */
// إعادة تعيين كلمة سر مشترك نسي كلمته: غيّر السطرين ثم شغّل الدالة
function adminResetPin() {
  var PHONE = "اكتب رقم المشترك هنا";            // مثل 01012345678
  var NEWPIN = "اكتب كلمة السر الجديدة هنا";      // 4 أحرف أو أكثر
  var p = normPhone_(PHONE), u = findBy_("phone", p);
  if (!u) { Logger.log("الرقم غير موجود"); return; }
  u.salt = rand_(16); u.hash = hashPin_(u.salt, NEWPIN); u.tokens = [];
  writeUser_(u);
  Logger.log("تمت إعادة تعيين كلمة سر " + u.name + " — أخبره بالكلمة الجديدة وليغيّرها من الإعدادات.");
}
// حذف مشترك (مثلًا سجّل برقم خاطئ): غيّر السطرين ثم شغّل الدالة
//  • FREE_NUMBERS = true  يحرّر مكان رقمه (ورقم ولي أمره) في العدّاد — استخدمها فقط لو لم تضف الرقم في Meta.
//  • FREE_NUMBERS = false يبقي المكان محسوبًا — استخدمها لو كنت أضفت الرقم في Meta (لأن Meta لا تحذف الأرقام).
function adminRemoveUser() {
  var PHONE = "اكتب رقم المشترك هنا";            // مثل 01012345678
  var FREE_NUMBERS = true;
  var p = normPhone_(PHONE), u = findBy_("phone", p);
  if (!u) { Logger.log("الرقم غير موجود"); return; }
  var ss = ss_(), sh = usersSheet_();
  sh.deleteRow(u.row);
  var st = ss.getSheetByName(stateSheetName_(u.id));
  if (st) ss.deleteSheet(st);
  if (FREE_NUMBERS) {
    var still = knownFromUsers_(), ns = numbersSheet_(), last = ns.getLastRow();
    for (var r = last; r >= 2; r--) {
      var n = String(ns.getRange(r, 1, 1, 1).getValues()[0][0]);
      if ((n === u.phone || n === u.guardian) && !still[n]) ns.deleteRow(r);
    }
  }
  try { syncRoster_(); } catch (e) {}
  Logger.log("تم حذف " + u.name + (FREE_NUMBERS ? " وتحرير مكانه" : " (المكان ما زال محسوبًا)") + " | الأرقام المحسوبة الآن: " + knownNumbers_().count + " من " + maxNumbers_());
}
// استرجاع المشتركين وحالاتهم المفقودة من أحدث نسخة احتياطية (لا يكتب فوق أي حساب موجود)
function restoreMissingFromBackup() {
  var ss = ss_(), all = ss.getSheets(), names = [], i;
  for (i = 0; i < all.length; i++) if (all[i].getName().indexOf("نسخة_") === 0) names.push(all[i].getName());
  if (!names.length) { Logger.log("لا توجد نسخ احتياطية"); return; }
  names.sort(); var bk = ss.getSheetByName(names[names.length - 1]);
  var vals = bk.getRange(1, 1, bk.getLastRow(), 4).getValues(), have = {}, restored = 0, users = readUsers_(), states = {};
  for (i = 0; i < users.length; i++) have[users[i].id] = 1;
  for (i = 1; i < vals.length; i++) {
    var r = vals[i];
    if (r[0] === "state") { (states[r[1]] = states[r[1]] || []).push([Number(r[2]), String(r[3])]); }
  }
  var sh = usersSheet_();
  for (i = 1; i < vals.length; i++) {
    if (vals[i][0] !== "user" || have[vals[i][1]]) continue;
    var u = JSON.parse(vals[i][3]);
    sh.appendRow([vals[i][1], u.name, u.phone, u.guardian, u.salt, u.hash, JSON.stringify(u.tokens || []), u.createdAt, JSON.stringify(u.rest), JSON.stringify(u.reminders), JSON.stringify(u.tasksStudent), JSON.stringify(u.tasksGuardian)]);
    var parts = (states[vals[i][1]] || []).sort(function (a, b) { return a[0] - b[0]; }), txt = "";
    for (var k = 0; k < parts.length; k++) txt += parts[k][1];
    if (txt && !ss.getSheetByName(stateSheetName_(vals[i][1]))) { try { saveState_(vals[i][1], JSON.parse(txt)); } catch (e) {} }
    restored++;
  }
  MEMO_USERS_ = null; rosterDirty_();
  Logger.log("تم استرجاع " + restored + " مشترك من " + names[names.length - 1] + " (الموجودون لم يُمسّوا)");
}
function knownFromUsers_() {
  var set = {}, u = readUsers_();
  for (var i = 0; i < u.length; i++) { if (u[i].phone) set[u[i].phone] = 1; if (u[i].guardian) set[u[i].guardian] = 1; }
  return set;
}

/* =====================================================================
   دوال الاختبار — اختر الدالة من القائمة المنسدلة في Apps Script ثم «تشغيل»، وشاهد النتيجة في «سجل التنفيذ».
   • دوال الطالب ترسل رسالة حقيقية إلى رقم أول مشترك مسجّل فقط (وتعمل حتى لو اليوم راحة).
   • دوال ولي الأمر تعمل «تجريبيًا» (تكتب ما كانت سترسله ولا ترسل شيئًا) إلا لو غيّرت SEND_REAL إلى true.
   • كل رسالة تُرسل تظهر نتيجتها في ورقة «سجل الإرسال» في Google Sheet مع سبب الفشل إن وُجد.
   ===================================================================== */
function testUser_(needGuardian) {                     // أول مشترك (أو أول مشترك له ولي أمر)
  var users = readUsers_();
  for (var i = 0; i < users.length; i++) if (!needGuardian || users[i].guardian) return users[i];
  return null;
}
function testDay_(u) {                                  // يوم المشترك اليوم، أو نص تجريبي لو لا مهام اليوم
  var today = Utilities.formatDate(new Date(), TZ, "yyyy-MM-dd"), d = dayOf_(u, loadState_(u.id), today);
  var line = d ? tasksLine_(d) : "";
  return { today: today, label: d ? dayLabel_(d) : "1", line: line || "الجديد: (تجربة) | الكنز: (تجربة)", real: !!line };
}

// 1) اختبار الاتصال: يفحص التوكن والاتصال بـ Meta والمشغّل ومحرّك الخطة (لا يرسل رسائل)
function testConnection() {
  var token = PropertiesService.getScriptProperties().getProperty("WHATSAPP_TOKEN");
  Logger.log("0) إصدار الكود: " + APP_VERSION + " | بداية خطة الجديد للترم الأول: " + (npStart_() || "غير محددة (النظام القديم)"));
  Logger.log("1) التوكن (WHATSAPP_TOKEN): " + (token ? "موجود" : "غير موجود ❌"));
  Logger.log("2) معرّف الرقم PHONE_NUMBER_ID: " + PHONE_NUMBER_ID + (USING_TEST_NUMBER ? " (رقم اختبار)" : " (رقم حقيقي)"));
  if (token) {
    var res = UrlFetchApp.fetch("https://graph.facebook.com/v23.0/" + PHONE_NUMBER_ID + "?fields=display_phone_number,verified_name", { headers: { Authorization: "Bearer " + token }, muteHttpExceptions: true });
    Logger.log("3) الاتصال بـ Meta: كود " + res.getResponseCode() + (res.getResponseCode() === 200 ? " ✅" : " ❌") + " — " + res.getContentText());
  }
  var trig = ScriptApp.getProjectTriggers(), has = false, i;
  for (i = 0; i < trig.length; i++) if (trig[i].getHandlerFunction() === "tick") has = true;
  Logger.log("4) فحص المواعيد كل " + TICK_MINUTES + " دقائق (setupTriggers): " + (has ? "مفعّل ✅" : "غير مفعّل ❌ — شغّل setupTriggers (بدونه لن تُرسل أي رسالة تلقائية!)"));
  Logger.log("5) محرّك الخطة Engine.gs: " + (typeof QT === "object" && QT.compute ? "موجود ✅" : "غير موجود ❌ — أضف ملف Engine.gs"));
  Logger.log("6) المشتركون: " + readUsers_().length + " | الأرقام المحسوبة: " + knownNumbers_().count + " من " + maxNumbers_());
  Logger.log("7) الوقت الآن بتوقيت القاهرة: " + Utilities.formatDate(new Date(), TZ, "yyyy-MM-dd HH:mm") + " | توقيت مشروع Apps Script: " + Session.getScriptTimeZone());
}

// 2) اختبار القوالب: يسأل Meta عن قوالبك ويقارنها بالإعداد (الاسم واللغة وعدد المتغيرات والحالة)
function testTemplates() {
  var token = PropertiesService.getScriptProperties().getProperty("WHATSAPP_TOKEN");
  if (!token) { Logger.log("التوكن غير موجود"); return; }
  var res = UrlFetchApp.fetch("https://graph.facebook.com/v23.0/" + WABA_ID + "/message_templates?limit=100&fields=name,language,status,components", { headers: { Authorization: "Bearer " + token }, muteHttpExceptions: true });
  if (res.getResponseCode() !== 200) { Logger.log("تعذر قراءة القوالب: " + res.getContentText() + " — تأكد من WABA_ID في أول Code.gs"); return; }
  var list = JSON.parse(res.getContentText()).data || [], names = ["studentReportReminder", "parentReport", "studentTasks", "parentTasks"], k, i;
  Logger.log("القوالب الموجودة في Meta: " + list.map(function (t) { return t.name + " (" + t.language + ", " + t.status + ")"; }).join(" | "));
  for (k = 0; k < names.length; k++) {
    var c = TPL[names[k]], found = null, sameName = [];
    for (i = 0; i < list.length; i++) {
      if (list[i].name === c.name) sameName.push(list[i].language + "/" + list[i].status);
      if (list[i].name === c.name && list[i].language === c.lang) found = list[i];
    }
    if (!found) { Logger.log("❌ " + names[k] + ": لا يوجد قالب «" + c.name + "» بلغة " + c.lang + (sameName.length ? " — الموجود بنفس الاسم: " + sameName.join("، ") + " ← عدّل lang" : " — الاسم غير موجود في Meta ← تأكد منه") ); continue; }
    var body = "", n = 0;
    for (i = 0; i < found.components.length; i++) if (found.components[i].type === "BODY") body = found.components[i].text || "";
    var m = body.match(/\{\{\d+\}\}/g); n = m ? m.length : 0;
    Logger.log((found.status === "APPROVED" ? "✅ " : "⚠️ ") + names[k] + ": " + c.name + " (" + c.lang + ") الحالة " + found.status + " | متغيرات القالب " + n + " والإعداد " + c.vars.length + (n === c.vars.length ? " ✔" : (function () { for (var a = 0; a < (c.alts || []).length; a++) if (c.alts[a].length === n) return " ↺ سيستعمل النظام تلقائيًا ترتيبًا بديلًا بـ" + n + " متغير: " + c.alts[a].join("+"); return " ❌ غير متطابق ← أرسل لي نص القالب من Meta"; })()));
  }
}

// اختبار الجدولة التلقائية: هل المشغّل موجود؟ وهل عمل فعلًا مؤخرًا؟ وماذا فعل في آخر مرة؟
function testTrigger() {
  var P = PropertiesService.getScriptProperties(), trig = ScriptApp.getProjectTriggers(), has = 0, i;
  for (i = 0; i < trig.length; i++) if (trig[i].getHandlerFunction() === "tick") has++;
  Logger.log("1) المشغّلات (tick): " + (has === 1 ? "موجود ✅" : has === 0 ? "❌ غير موجود — شغّل setupTriggers" : "⚠️ مكرر (" + has + ") — شغّل setupTriggers ليبقى واحدًا"));
  var last = Number(P.getProperty("lastTick") || 0);
  if (!last) Logger.log("2) لم يعمل المشغّل تلقائيًا من قبل ❌ (أو لم يمضِ وقت كافٍ بعد setupTriggers). افتح «التنفيذات / Executions» في Apps Script وابحث عن أخطاء الصلاحيات.");
  else { var mins = Math.round((new Date().getTime() - last) / 60000); Logger.log("2) آخر تشغيل تلقائي: منذ " + mins + " دقيقة " + (mins <= TICK_MINUTES * 3 ? "✅" : "❌ متوقف أو متأخر — شغّل setupTriggers مجددًا ووافق على الصلاحيات")); }
  Logger.log("3) ماذا فعل آخر فحص: " + (P.getProperty("lastTickSummary") || "—"));
  Logger.log("4) آخر خطأ في الفحص: " + (P.getProperty("lastTickError") || "لا يوجد"));
  var fd = 0, nt = nextJobEpoch_(); for (i = 0; i < trig.length; i++) if (trig[i].getHandlerFunction() === "fireDue") fd++;
  Logger.log("4b) المشغّل الدقيق للموعد القادم: " + (fd === 1 ? "مضبوط ✅" : "غير مضبوط (يُضبط تلقائيًا بعد أول فحص أو بعد حفظ المواعيد)") + " | أقرب موعد إرسال: " + (nt ? Utilities.formatDate(new Date(nt), TZ, "yyyy-MM-dd HH:mm:ss") : "لا يوجد") + (P.getProperty("lastArmError") ? " | آخر خطأ ضبط: " + P.getProperty("lastArmError") : ""));
  var bad = validateTpl_(); Logger.log("5) إعدادات القوالب: " + (bad.length ? "❌ رموز غير مسموحة: " + bad.join("، ") : "سليمة ✅"));
  Logger.log("6) النسخة الاحتياطية الأخيرة: " + (P.getProperty("lastBackup") || "لم تؤخذ بعد") + " | إصدار البنية: " + (P.getProperty("schema") || "—"));
}
// اختبار الحسابات: يعرض كل حساب وهل بياناته سليمة (لا يغيّر شيئًا)
function testAccounts() {
  var users = readUsers_(), ss = ss_();
  if (!users.length) { Logger.log("لا توجد حسابات"); return; }
  for (var i = 0; i < users.length; i++) {
    var u = users[i], st = loadState_(u.id), nrep = 0, k;
    for (k in st.reports) if (st.reports.hasOwnProperty(k) && !st.reports[k].cancelled) nrep++;
    Logger.log((i + 1) + ") " + u.name + " | " + localPhone_(u.phone) + " | كلمة السر محفوظة: " + (u.hash && u.salt ? "✅" : "❌") + " | جلسات: " + u.tokens.length +
      " | ورقة حالته: " + (ss.getSheetByName(stateSheetName_(u.id)) ? "✅" : "❌") + " | بداية الخطة: " + (st.start || "غير محددة") + " | تقارير: " + nrep);
  }
}
// 3) لماذا لم تُرسل رسالتي؟ — يفحص كل مشترك وكل موعد ويشرح حالته دون إرسال شيء. (غيّر SIMULATE_TIME لمحاكاة وقت آخر مثل "06:05")
function testWhyNotSent() {
  var SIMULATE_TIME = "";                               // فارغ = الوقت الآن
  var now = new Date(), today = Utilities.formatDate(now, TZ, "yyyy-MM-dd");
  var hms = (SIMULATE_TIME ? SIMULATE_TIME + ":00" : Utilities.formatDate(now, TZ, "HH:mm:ss")).split(":"), nowSec = Number(hms[0]) * 3600 + Number(hms[1]) * 60 + Number(hms[2]);
  var u7 = Number(Utilities.formatDate(now, TZ, "u")), jsDay = (u7 === 7) ? 0 : u7, DN = ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
  var trig = ScriptApp.getProjectTriggers(), has = false, i, k, j;
  for (i = 0; i < trig.length; i++) if (trig[i].getHandlerFunction() === "tick") has = true;
  Logger.log("الآن: " + today + " " + hms.join(":") + " (" + DN[jsDay] + ") | المشغّل: " + (has ? "موجود ✅" : "❌ غير موجود — شغّل setupTriggers"));
  var users = readUsers_();
  if (!users.length) { Logger.log("لا يوجد مشتركون"); return; }
  var kinds = [["ts", "مهام الطالب", "tasksStudent"], ["tg", "مهام ولي الأمر", "tasksGuardian"], ["rr", "تذكير التقرير", "reminders"]];
  for (i = 0; i < users.length; i++) {
    var u = users[i], st = loadState_(u.id), why = [];
    if (u.rest.indexOf(jsDay) > -1 && jsDay !== 5) why.push("اليوم راحة لهذا المشترك (" + DN[jsDay] + ")");
    if (npStart_() && today >= npStart_() && !st.base) why.push("❌ لم يحدّد «وين وصلت» في الخطة الجديدة (الصفحة الرئيسية) — لن تُرسل له مهام حتى يحدده");
    if (!st.start) why.push("❌ لم يحدد تاريخ بداية الخطة — لن يُرسل له شيء حتى يحدده");
    else if (today < st.start) why.push("الخطة تبدأ " + st.start + " (لم تبدأ بعد)");
    var d = (st.start && today >= st.start) ? dayOf_(u, st, today) : null;
    Logger.log((i + 1) + ") " + u.name + " | هاتف " + localPhone_(u.phone) + " | ولي الأمر " + (u.guardian ? localPhone_(u.guardian) : "لا يوجد"));
    Logger.log("   مهام اليوم: " + (d ? "اليوم " + dayLabel_(d) + " — " + tasksLine_(d) : "لا مهام اليوم"));
    for (k = 0; k < kinds.length; k++) {
      if (kinds[k][0] === "tg" && !u.guardian) { Logger.log("   " + kinds[k][1] + ": لا يوجد ولي أمر"); continue; }
      var times = u[kinds[k][2]] || [], parts = [];
      for (j = 0; j < times.length; j++) {
        var late = nowSec - timeMin_(times[j]) * 60, state;
        if (wasSent_(kinds[k][0], u, today, times[j])) state = "أُرسل اليوم ✅";
        else if (late < 0 && -late <= LOOKAHEAD_SEC) state = "سيُرسل بعد " + Math.round(-late) + " ثانية";
        else if (late < 0) state = "لم يحن (بعد " + Math.round(-late / 60) + " دقيقة)";
        else if (late < GRACE_MIN * 60) state = "مرّ الموعد قبل " + Math.round(late / 60) + " دقيقة ولم يُرسل → سيُرسل فورًا في الفحص التالي";
        else state = "مرّ أكثر من ساعة ولم يُرسل اليوم → لن يُرسل اليوم، ويُرسل غدًا في موعده";
        parts.push(times[j] + " [" + state + "]");
      }
      Logger.log("   " + kinds[k][1] + ": " + parts.join(" ، "));
    }
    Logger.log("   الأسباب المحتملة لعدم الإرسال: " + (why.length ? why.join(" | ") : "لا مانع ظاهر في الإعدادات — راجع ورقة «سجل الإرسال» لسبب أي فشل من Meta"));
  }
}

// اختبار الإعدادات: يعرض إعدادات كل مشترك ومهام اليوم الفعلية له (بدون إرسال)
function testSettings() {
  var users = readUsers_(), DN = ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
  if (!users.length) { Logger.log("لا يوجد مشتركون بعد"); return; }
  for (var i = 0; i < users.length; i++) {
    var u = users[i], rn = [], k;
    for (k = 0; k < u.rest.length; k++) rn.push(DN[u.rest[k]]);
    var td = testDay_(u), st = loadState_(u.id);
    Logger.log((i + 1) + ") " + u.name + " | هاتف: " + localPhone_(u.phone) + " | ولي الأمر: " + (u.guardian ? localPhone_(u.guardian) : "لا يوجد") +
      " | بداية الخطة: " + (st.start || "❌ غير محددة") + " | راحة: " + (rn.join("، ") || "—") + " | مهام الطالب: " + u.tasksStudent.join(" ، ") + " | مهام ولي الأمر: " + u.tasksGuardian.join(" ، ") +
      " | تذكير التقرير: " + u.reminders.join(" ، ") + " | مهام اليوم: " + (td.real ? "اليوم " + td.label + " — " + td.line : "لا مهام اليوم (راحة أو الخطة لم تبدأ)"));
  }
}
// 4) مهام اليوم للطالب — إرسال حقيقي إلى أول مشترك مسجّل فقط
function testStudentTasks() {
  var u = testUser_(false); if (!u) { Logger.log("لا يوجد مشتركون"); return; }
  var td = testDay_(u);
  Logger.log("نتيجة الإرسال إلى " + localPhone_(u.phone) + ": " + JSON.stringify(sendLogged_(u, "اختبار مهام الطالب", studentTasksPayload_(u, td.label, td.line, td.today))));
}
// 5) تذكير الطالب بملء التقرير — إرسال حقيقي إلى أول مشترك مسجّل فقط
function testStudentReportReminder() {
  var u = testUser_(false); if (!u) { Logger.log("لا يوجد مشتركون"); return; }
  var td = testDay_(u);
  Logger.log("نتيجة الإرسال إلى " + localPhone_(u.phone) + ": " + JSON.stringify(sendLogged_(u, "اختبار تذكير التقرير", reportReminderPayload_(u, td.label, td.today))));
}
// 6) مهام اليوم لولي الأمر — تجريبي (لا يرسل) إلا لو غيّرت SEND_REAL إلى true
function testGuardianTasks() {
  var SEND_REAL = false;                                // ← غيّرها إلى true فقط لو تريد إرسالًا حقيقيًا لولي الأمر
  var u = testUser_(true); if (!u) { Logger.log("لا يوجد مشترك له رقم ولي أمر"); return; }
  var td = testDay_(u), p = parentTasksPayload_(u, td.label, td.line);
  if (!SEND_REAL) { Logger.log("تجريبي — لم يُرسل شيء. كانت سترسل إلى ولي أمر " + u.name + " (" + localPhone_(u.guardian) + "): " + JSON.stringify(p.template.components[0].parameters)); return; }
  Logger.log("نتيجة الإرسال إلى ولي الأمر " + localPhone_(u.guardian) + ": " + JSON.stringify(sendLogged_(u, "اختبار مهام ولي الأمر", p)));
}
// 7) تقرير الطالب لولي الأمر — تجريبي (لا يرسل) إلا لو غيّرت SEND_REAL إلى true
function testReportToGuardian() {
  var SEND_REAL = false;                                // ← غيّرها إلى true فقط لو تريد إرسالًا حقيقيًا لولي الأمر
  var u = testUser_(true); if (!u) { Logger.log("لا يوجد مشترك له رقم ولي أمر"); return; }
  var p = parentReportPayload_(u, "1", "رسالة اختبار — الكنز: تجربة | الجديد: تجربة");
  if (!SEND_REAL) { Logger.log("تجريبي — لم يُرسل شيء. كانت سترسل إلى ولي أمر " + u.name + " (" + localPhone_(u.guardian) + "): " + JSON.stringify(p.template.components[0].parameters)); return; }
  Logger.log("نتيجة الإرسال إلى ولي الأمر " + localPhone_(u.guardian) + ": " + JSON.stringify(sendLogged_(u, "اختبار تقرير ولي الأمر", p)));
}

/* =====================================================================
   الاختبار الأسبوعي (يوم الجمعة) — الأسئلة والتصحيح كلها هنا على الخادم
   • نص القرآن يُقرأ حرفيًا من quran-data.json (نص Tanzil المدقّق) على موقعك، ولا يُكتب شيء من الذاكرة.
   • الإجابات الصحيحة لا تصل للمتصفح أبدًا، ووقت كل سؤال يحسبه الخادم.
   • كل خيارات الأسئلة آيات/كلمات حقيقية من المصحف (لا آية مغيّرة عمدًا).
   ===================================================================== */
var EXAM_SHEET = "الاختبارات";
var EXAM_SESS_SHEET = "_جلسات_الاختبار";
var EXAM_TOTAL = 20;            // عدد الأسئلة
var EXAM_SEC_MCQ = 40;          // ثواني سؤال الاختيار
var EXAM_SEC_REC = 150;         // ثواني سؤال التسميع (يشمل التسجيل والمحاولات)
var EXAM_GRACE_SEC = 8;         // سماح لزمن الشبكة
var EXAM_MAX_VIOL = 3;          // عند الوصول لهذا العدد من مرات الخروج ينتهي الاختبار
var EXAM_FULL = 0.78;           // تسميع صحيح كاملًا
var EXAM_HALF = 0.62;           // تسميع قريب (نصف درجة)
var QURAN_DATA_URL = SITE_URL + "/quran-data.json";
var QMEMO_ = null, QX_ = null;

/* ---------- المصحف ---------- */
function quran_() {
  if (QMEMO_) return QMEMO_;
  var res = UrlFetchApp.fetch(QURAN_DATA_URL, { muteHttpExceptions: true });
  if (res.getResponseCode() !== 200) throw new Error("تعذر تحميل المصحف من الموقع: ارفع الملف quran-data.json على GitHub بجانب باقي الملفات");
  var d = JSON.parse(res.getContentText()), tot = 0, i;
  if (!d.surahs || d.surahs.length !== 114) throw new Error("ملف المصحف غير صحيح (عدد السور)");
  for (i = 0; i < 114; i++) {
    if (d.surahs[i].u.length !== d.surahs[i].s.length) throw new Error("ملف المصحف غير صحيح (سورة " + (i + 1) + ")");
    tot += d.surahs[i].u.length;
  }
  if (tot !== 6236) throw new Error("ملف المصحف غير مكتمل (" + tot + " آية بدل 6236)");
  QMEMO_ = d;
  return d;
}
function normAr_(s) {                                   // تبسيط للمطابقة: بلا تشكيل ولا علامات، وتوحيد الألف والياء والتاء المربوطة
  return String(s || "")
    .replace(/[\u0640\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u08D3-\u08FF\u200B-\u200F]/g, "")
    .replace(/[أإآٱ]/g, "ا").replace(/ى/g, "ي").replace(/ة/g, "ه").replace(/ؤ/g, "و").replace(/ئ/g, "ي").replace(/ء/g, "")
    .replace(/[^\u0621-\u064A\s]/g, " ").replace(/\s+/g, " ").replace(/^\s|\s$/g, "");
}
function qtok_(uth) {                                   // كلمات الآية (رموز الوقف تلتصق بالكلمة التي قبلها فيبقى النص مطابقًا للأصل)
  var parts = String(uth).split(" "), out = [], i, t;
  for (i = 0; i < parts.length; i++) {
    t = parts[i];
    if (/[\u0621-\u064A\u0671]/.test(t) || !out.length) out.push(t); else out[out.length - 1] += " " + t;
  }
  return out;
}
function qx_() {                                        // فهارس مساعدة: نص مبسّط لكل آية + عدد تكرارها + بدايتها
  if (QX_) return QX_;
  var Q = quran_(), n = [], W = [], cnt = {}, pre = {}, s, a, t, w, k;
  for (s = 0; s < 114; s++) {
    n[s] = []; W[s] = [];
    for (a = 0; a < Q.surahs[s].s.length; a++) {
      t = normAr_(Q.surahs[s].s[a]); n[s][a] = t; W[s][a] = t.split(" ");
      cnt[t] = (cnt[t] || 0) + 1;
      w = t.split(" "); k = w.slice(0, 4).join(" "); pre[k] = (pre[k] || 0) + 1;
    }
  }
  QX_ = { n: n, w: W, cnt: cnt, pre: pre };
  return QX_;
}
function qa_(s, a) { return quran_().surahs[s - 1].u[a - 1]; }             // نص الآية (عثماني)
function qn_(s, a) { return qx_().n[s - 1][a - 1]; }                       // نص الآية المبسّط
function qlen_(s) { return quran_().surahs[s - 1].u.length; }
function qwc_(s, a) { return qn_(s, a).split(" ").length; }
function quniq_(s, a) { return qx_().cnt[qn_(s, a)] === 1; }
function qpreu_(s, a) { var w = qn_(s, a).split(" ").slice(0, 4).join(" "); return qx_().pre[w] === 1; }

/* ---------- عشوائية ---------- */
function rI_(n) { return Math.floor(Math.random() * n); }
function shuf_(a) { var b = a.slice(), i, j, t; for (i = b.length - 1; i > 0; i--) { j = rI_(i + 1); t = b[i]; b[i] = b[j]; b[j] = t; } return b; }

/* ---------- مصادر الأسئلة: ما حفظه المشترك فعلًا ---------- */
function examSources_(u, st, today) {
  if (!st.start || today < st.start) return null;
  QT_CONFIG.NEW_PLAN_START = npStart_();
  QT.setRest(u.rest || DEFAULT_REST);
  var M = QT.compute(st, today);
  if (!M) return null;
  var C = M.C, V = M.V, i, d, weekAgo = QT.addDays(today, -6), C0 = null, V0 = null, gotNow = false;
  for (i = 0; i < M.days.length; i++) {
    d = M.days[i];
    if (d.isFriday) continue;
    if (!gotNow && d.date >= today) { C = d.t ? d.t.from : QT.TOTAL12; V = d.nw ? d.nw.from - 1 : V; gotNow = true; }
    if (C0 === null && d.date >= weekAgo) { C0 = d.t ? d.t.from : QT.TOTAL12; V0 = d.nw ? d.nw.from - 1 : V; }
    if (gotNow && C0 !== null) break;
  }
  var K = Math.floor(C / 12), W0 = C0 === null ? 0 : Math.floor(C0 / 12);
  if (W0 > K) W0 = K;
  V = Math.max(0, Math.min(120, V || 0)); V0 = V0 === null ? 0 : Math.max(0, Math.min(V, V0));
  var slots = [], k, j, seg, sn;
  for (k = 1; k <= K; k++) {
    var ay = [], surs = [];
    for (j = 0; j < QT.SLOTS[k - 1].length; j++) {
      seg = QT.SLOTS[k - 1][j]; sn = QT.SURAHS.indexOf(seg[0]) + 1;
      if (sn < 1) continue;
      for (var a = seg[3]; a <= seg[4]; a++) ay.push({ s: sn, a: a });
      if (surs.indexOf(sn) < 0) surs.push(sn);
    }
    slots.push({ q: k, ay: ay, surs: surs });
  }
  return { K: K, W0: W0, V: V, V0: V0, slots: slots };
}

/* ---------- سجل ما اختُبر سابقًا (لتغطية القديم دوريًا) ---------- */
function examHist_(uid) {
  var h = { t: {}, n: {} }, sh = ss_().getSheetByName(EXAM_SHEET);
  if (!sh || sh.getLastRow() < 2) return h;
  var rows = sh.getRange(2, 1, sh.getLastRow() - 1, 10).getValues(), i, r, o, k;
  for (i = 0; i < rows.length; i++) {
    r = rows[i];
    if (String(r[1]) !== String(uid) || String(r[4]) !== "رسمي") continue;
    try { o = JSON.parse(r[9]); } catch (e) { continue; }
    if (!o || !o.cov) continue;
    for (k = 0; k < (o.cov.t || []).length; k++) h.t[o.cov.t[k]] = String(r[2]);
    for (k = 0; k < (o.cov.n || []).length; k++) h.n[o.cov.n[k]] = String(r[2]);
  }
  return h;
}

/* ---------- اختيار الأرباع/الآيات: الأسبوع الحالي أولًا ثم الأقل اختبارًا من القديم ---------- */
function examPickSlots_(src, hist, need) {
  var week = [], old = [], i, out;
  for (i = 0; i < src.slots.length; i++) (src.slots[i].q > src.W0 ? week : old).push(src.slots[i]);
  var wn = Math.min(week.length, Math.max(2, Math.round(need * 0.4)));
  week = shuf_(week).slice(0, wn);
  old = old.map(function (x) { return { x: x, l: hist.t[x.q] || "0", r: Math.random() }; });
  old.sort(function (a, b) { return a.l < b.l ? -1 : (a.l > b.l ? 1 : a.r - b.r); });             // الأقدم اختبارًا (أو الذي لم يُختبر أبدًا) أولًا → كل ربع محفوظ يأتي دوره
  out = week.concat(old.slice(0, Math.max(0, need - week.length)).map(function (o) { return o.x; }));
  if (!out.length) out = shuf_(src.slots).slice(0, need);
  return shuf_(out);
}
function examPickAyat_(src, hist, need) {              // آيات الجديد (المائدة 1..V): الحديثة أولًا ثم الأقل اختبارًا
  var recent = [], old = [], a, picks;
  for (a = 1; a <= src.V; a++) (a > src.V0 ? recent : old).push(a);
  var rn = Math.min(recent.length, Math.max(2, Math.round(need * 0.4)));
  picks = shuf_(recent).slice(0, rn);
  old = old.map(function (x) { return { x: x, l: hist.n[x] || "0", r: Math.random() }; });
  old.sort(function (p, q) { return p.l < q.l ? -1 : (p.l > q.l ? 1 : p.r - q.r); });
  picks = picks.concat(old.slice(0, Math.max(0, need - picks.length)).map(function (o) { return o.x; }));
  if (!picks.length) { for (a = 1; a <= src.V; a++) picks.push(a); picks = shuf_(picks).slice(0, need); }
  return shuf_(picks);
}

/* ---------- شروط صلاحية الآية لكل نوع سؤال ---------- */
function okAy_(t, s, a) {
  var n = qlen_(s), w;
  if (a < 1 || a > n) return false;
  w = qwc_(s, a);
  if (!quniq_(s, a)) return false;
  switch (t) {
    case "NEXT": return a < n && w >= 3 && w <= 40 && qwc_(s, a + 1) >= 3 && qwc_(s, a + 1) <= 40 && quniq_(s, a + 1);
    case "PREV": return a > 1 && w >= 3 && w <= 40 && qwc_(s, a - 1) >= 3 && qwc_(s, a - 1) <= 40 && quniq_(s, a - 1);
    case "COMP": return w >= 9 && w <= 30 && qpreu_(s, a);
    case "SURAH": return w >= 4 && w <= 30 && qpreu_(s, a);
    case "REC": return a < n && w >= 2 && w <= 40 && qwc_(s, a + 1) >= 3 && qwc_(s, a + 1) <= 28 && quniq_(s, a + 1);
  }
  return false;
}
function memOK_(k, t, s, a, mem) {                     // الإجابة الصحيحة لازم تكون من المحفوظ فعلًا (مش الآية التالية لآخر محفوظ)
  if (!mem) return true;
  var key = function (x) { return s + ":" + x; };
  if (k === "N") { if (t === "NEXT" || t === "REC") return a + 1 <= mem.V; if (t === "PREV") return a - 1 >= 1; return a <= mem.V; }
  if (k === "T") { if (t === "NEXT" || t === "REC") return !!mem.tset[key(a + 1)]; if (t === "PREV") return !!mem.tset[key(a - 1)]; return !!mem.tset[key(a)]; }
  return true;
}
function findAy_(t, cands, ordered, mem, k) {          // أول آية صالحة من القائمة (مخلوطة، أو بترتيبها لو ordered)
  var c = ordered ? cands : shuf_(cands), i;
  for (i = 0; i < c.length; i++) {
    if (mem && mem.usedT && mem.usedT[c[i].s + ":" + c[i].a + ":" + t]) continue;      // نفس الآية بنفس نوع السؤال مرة واحدة فقط
    if (okAy_(t, c[i].s, c[i].a) && memOK_(k, t, c[i].s, c[i].a, mem)) return c[i];
  }
  return null;
}

/* ---------- مشتتات حقيقية من المصحف: الأشبه بالصحيحة (متشابهات) ---------- */
function simW_(a, b) {                                  // تشابه بين مصفوفتي كلمات مبسّطة: جاكارد + مكافأة للبداية المتطابقة ونفس فاصلة الآية
  var i, m = {}, seen = {}, ua = 0, ub = 0, inter = 0, j, la, lb;
  for (i = 0; i < a.length; i++) if (!m[a[i]]) { m[a[i]] = 1; ua++; }
  for (i = 0; i < b.length; i++) { if (seen[b[i]]) continue; seen[b[i]] = 1; ub++; if (m[b[i]]) inter++; }
  j = inter / ((ua + ub - inter) || 1);
  if (a[0] === b[0]) j += 0.08;
  la = a[a.length - 1]; lb = b[b.length - 1];
  if (la && lb && la.charAt(la.length - 1) === lb.charAt(lb.length - 1)) j += 0.07;
  return j;
}
function topPick_(arr, keep, take) {                    // من أعلى «keep» نتيجة نختار «take» عشوائيًا (بلا تكرار نص)
  var out = [], seen = {}, i, pool = [];
  for (i = 0; i < arr.length && pool.length < keep; i++) { if (seen[arr[i].n]) continue; seen[arr[i].n] = 1; pool.push(arr[i]); }
  pool = shuf_(pool);
  return pool.length >= take ? pool.slice(0, take) : null;
}
function distSim_(tw, tn, excl) {                       // 3 آيات حقيقية من المصحف كله هي الأشبه بالآية المطلوبة
  var X = qx_(), cand = [], s, a, w, lo = Math.max(3, Math.floor(tw.length * 0.5)), hi = Math.ceil(tw.length * 1.6) + 2;
  for (s = 0; s < 114; s++) for (a = 0; a < X.w[s].length; a++) {
    w = X.w[s][a]; if (w.length < lo || w.length > hi || w.length > 45) continue;
    if (X.n[s][a] === tn || excl[(s + 1) + ":" + (a + 1)]) continue;
    cand.push({ s: s + 1, a: a + 1, n: X.n[s][a], sc: simW_(tw, w) });
  }
  cand.sort(function (p, q) { return q.sc - p.sc; });
  return topPick_(cand, 8, 3);
}
function distEnd_(endNorm, endLen, selfKey) {            // 3 نهايات حقيقية لآيات أخرى هي الأشبه بالنهاية الصحيحة
  var X = qx_(), cand = [], s, a, tk, tail, tn, ew = endNorm.split(" ");
  for (s = 0; s < 114; s++) for (a = 0; a < X.w[s].length; a++) {
    if (selfKey === (s + 1) + ":" + (a + 1)) continue;
    if (X.w[s][a].length < endLen + 3) continue;
    tn = X.w[s][a].slice(X.w[s][a].length - endLen).join(" ");
    if (tn === endNorm) continue;
    cand.push({ s: s + 1, a: a + 1, n: tn, sc: simW_(ew, tn.split(" ")) });
  }
  cand.sort(function (p, q) { return q.sc - p.sc; });
  var pick = topPick_(cand, 8, 3), i, out = [];
  if (!pick) return null;
  for (i = 0; i < pick.length; i++) { tk = qtok_(qa_(pick[i].s, pick[i].a)); tail = tk.slice(tk.length - endLen).join(" "); if (normAr_(tail) !== endNorm) out.push(tail); }
  return out.length === 3 ? out : null;
}
function distSurah_(tw, s, mem) {                       // سور أخرى فيها آيات تشبه الآية المعروضة (متشابهات) ثم سور قريبة
  var X = qx_(), cand = [], x, a, w, out = [], seen = {}, i;
  seen[s] = 1;
  for (x = 0; x < 114; x++) {
    if (x + 1 === s) continue;
    for (a = 0; a < X.w[x].length; a++) { w = X.w[x][a]; if (w.length < 3) continue; cand.push({ s: x + 1, n: String(x + 1), sc: simW_(tw, w) }); }
  }
  cand.sort(function (p, q) { return q.sc - p.sc; });
  var pool = [], sn = {};
  for (i = 0; i < cand.length && pool.length < 10; i++) { if (sn[cand[i].s]) continue; sn[cand[i].s] = 1; pool.push(cand[i].s); }
  pool = shuf_(pool);
  for (i = 0; i < pool.length && out.length < 3; i++) { out.push(pool[i]); seen[pool[i]] = 1; }
  var near = shuf_(mem.surahs.concat([s - 2, s - 1, s + 1, s + 2]).filter(function (v) { return v >= 1 && v <= 114 && !seen[v]; }));
  for (i = 0; i < near.length && out.length < 3; i++) { if (seen[near[i]]) continue; seen[near[i]] = 1; out.push(near[i]); }
  return out.length === 3 ? out : null;
}
function coreOf_(tok) { return String(tok).split(" ")[0]; }

/* ---------- بناء سؤال ---------- */
function buildQ_(spec, cands, mem, ordered) {
  var t = spec.t, p = findAy_(t, cands, ordered, mem, spec.k), s, a, toks, i, opts, ans, d, q;
  if (!p) return null;
  s = p.s; a = p.a;
  q = { k: spec.k, t: t, ref: { s: s, a: a }, lim: t === "REC" ? EXAM_SEC_REC : EXAM_SEC_MCQ };
  if (t === "NEXT" || t === "PREV") {
    var tg = t === "NEXT" ? a + 1 : a - 1, tgt = qa_(s, tg), ex = {}; ex[s + ":" + a] = 1;
    d = distSim_(qn_(s, tg).split(" "), qn_(s, tg), ex); if (!d) return null;
    opts = [{ x: tgt, ok: true }]; for (i = 0; i < 3; i++) opts.push({ x: qa_(d[i].s, d[i].a), ok: false });
    q.prompt = t === "NEXT" ? "ما الآية التي تأتي بعد هذه الآية؟" : "ما الآية التي تأتي قبل هذه الآية؟";
    q.show = qa_(s, a); q.cor = tgt; q.cov = { s: s, a: a };
  } else if (t === "COMP") {
    toks = qtok_(qa_(s, a));
    var w = toks.length, pc = Math.max(4, Math.min(w - 4, Math.round(w * 0.45))), endW = toks.slice(pc), endLen = endW.length, endN = normAr_(endW.join(" "));
    var ends = distEnd_(endN, endLen, s + ":" + a); if (!ends) return null;
    opts = [{ x: endW.join(" "), ok: true }]; for (i = 0; i < 3; i++) opts.push({ x: ends[i], ok: false });
    q.prompt = "أكمل الآية:"; q.show = toks.slice(0, pc).join(" ") + " …"; q.cor = endW.join(" "); q.cov = { s: s, a: a };
  } else if (t === "SURAH") {
    var ss = distSurah_(qn_(s, a).split(" "), s, mem); if (!ss) return null;
    opts = [{ x: QT.SURAHS[s - 1], ok: true }]; for (i = 0; i < 3; i++) opts.push({ x: QT.SURAHS[ss[i] - 1], ok: false });
    q.prompt = "من أي سورة هذه الآية؟"; q.show = qa_(s, a); q.cor = QT.SURAHS[s - 1]; q.cov = { s: s, a: a };
  } else if (t === "REC") {
    q.prompt = "اقرأ الآية التي تأتي بعد هذه الآية (بصوتك):"; q.show = qa_(s, a);
    q.exp = qn_(s, a + 1); q.cor = qa_(s, a + 1); q.cov = { s: s, a: a + 1 }; q.rec = true;
    return q;
  } else return null;
  opts = shuf_(opts);
  for (i = 0; i < opts.length; i++) if (opts[i].ok) ans = i;
  q.opts = opts.map(function (o) { return o.x; }); q.ans = ans;
  return q;
}

/* ---------- خطة الأسئلة ---------- */
function examPlan_(hasT, hasN, voice, total) {
  var nX = 0, nT = 0, nN = 0, plan = [], i;
  if (hasT && hasN) { nX = 4; nN = 7; nT = total - 11; } else if (hasT) { nX = 4; nT = total - 4; } else { nN = total; }
  var rT = 0, rN = 0;
  if (voice) { if (hasT && hasN) { rT = 2; rN = 2; } else if (hasT) { rT = 4; } else { rN = 4; } }
  var base = ["NEXT", "COMP", "PREV", "COMP", "NEXT", "COMP", "PREV"], bi = 0;
  function add(k, n, rec) { var j; for (j = 0; j < n; j++) plan.push({ k: k, t: j < rec ? "REC" : base[(bi++) % base.length] }); }
  add("T", nT, rT); add("N", nN, rN);
  for (i = 0; i < nX; i++) plan.push({ k: "X", t: "SURAH" });
  return plan;
}
function slotOfAyah_(src, ref) {
  var i, j;
  for (i = 0; i < src.slots.length; i++) for (j = 0; j < src.slots[i].ay.length; j++) if (src.slots[i].ay[j].s === ref.s && src.slots[i].ay[j].a === ref.a) return src.slots[i].q;
  return 0;
}
function examBuild_(u, st, today, voice, hist) {
  var src = examSources_(u, st, today);
  if (!src) return { err: "حدّد تاريخ بداية الخطة أولًا." };
  var hasT = src.K > 0, hasN = src.V >= 3;
  if (!hasT && !hasN) return { err: "النظام مسجّل عندك " + src.K + " ربع في الكنز و" + src.V + " آية في الجديد، وده قليل على اختبار. افتح الصفحة الرئيسية ← «تعديل مكاني في الخطة» وتأكد من إجاباتك، أو سجّل تقاريرك الأول.", K: src.K, V: src.V };
  quran_(); qx_();
  var plan = examPlan_(hasT, hasN, voice, EXAM_TOTAL), nT = 0, nN = 0, i;
  for (i = 0; i < plan.length; i++) { if (plan[i].k === "T") nT++; else if (plan[i].k === "N") nN++; }
  var slotList = hasT ? examPickSlots_(src, hist, Math.max(nT, 4) + 2) : [], ayList = hasN ? examPickAyat_(src, hist, Math.max(nN, 4) + 2) : [];
  var surahsMem = []; (function () { var k, j; for (k = 0; k < src.slots.length; k++) for (j = 0; j < src.slots[k].surs.length; j++) if (surahsMem.indexOf(src.slots[k].surs[j]) < 0) surahsMem.push(src.slots[k].surs[j]); if (hasN) surahsMem.push(5); })();
  var allT = []; for (i = 0; i < src.slots.length; i++) allT = allT.concat(src.slots[i].ay);
  var allN = []; for (i = 1; i <= src.V; i++) allN.push({ s: 5, a: i });
  var maxUse = (allT.length + allN.length) >= 60 ? 1 : ((allT.length + allN.length) >= 30 ? 2 : 3);      // محفوظ قليل: نسمح بأكثر من سؤال على نفس الآية (بأنواع مختلفة)
  var mem = { surahs: surahsMem, V: src.V, tset: {}, usedT: {} }, qs = [], used = {}, ti = 0, ni = 0, xi = 0, covT = [], covN = [];
  for (i = 0; i < allT.length; i++) mem.tset[allT[i].s + ":" + allT[i].a] = 1;
  function poolFor(k) {
    if (k === "T") { var sl = slotList[ti++ % slotList.length]; return { pool: sl.ay.filter(function (p) { return ((used[p.s + ":" + p.a] || 0) < maxUse); }), slot: sl.q }; }
    if (k === "N") { var a0 = ayList[ni++ % ayList.length], near = []; for (var d = 0; d <= 4; d++) { if (a0 + d <= src.V) near.push({ s: 5, a: a0 + d }); if (d && a0 - d >= 1) near.push({ s: 5, a: a0 - d }); } return { pool: near.filter(function (p) { return ((used[p.s + ":" + p.a] || 0) < maxUse); }), ordered: true }; }
    var mixT = hasT && (xi % 2 === 0 || !hasN); xi++; var arr = mixT ? allT : allN; return { pool: arr.filter(function (p) { return ((used[p.s + ":" + p.a] || 0) < maxUse); }), mixT: mixT };
  }
  function make(spec, relax) {
    var pf = poolFor(spec.k), types = [spec.t].concat(["NEXT", "COMP", "PREV", "SURAH"].filter(function (x) { return x !== spec.t && (spec.t !== "REC" || x !== "REC"); })), j, q;
    var pools = [pf.pool]; if (spec.k === "T") pools.push(allT.filter(function (p) { return ((used[p.s + ":" + p.a] || 0) < maxUse); })); if (spec.k === "N") pools.push(allN.filter(function (p) { return ((used[p.s + ":" + p.a] || 0) < maxUse); }));
    for (j = 0; j < types.length; j++) for (var pi = 0; pi < pools.length; pi++) {       // نجرّب النوع المطلوب في كل المصادر قبل التحوّل لنوع آخر
      if (spec.k === "X" && types[j] !== "SURAH") continue;
      q = buildQ_({ k: spec.k, t: types[j] }, pools[pi], mem, pi === 0 && pf.ordered);
      if (q) { used[q.ref.s + ":" + q.ref.a] = (used[q.ref.s + ":" + q.ref.a] || 0) + 1; mem.usedT[q.ref.s + ":" + q.ref.a + ":" + q.t] = 1; if (pf.slot && pi === 0) q.slot = pf.slot; else if (spec.k === "T") q.slot = slotOfAyah_(src, q.ref); return q; }
    }
    return null;
  }
  for (i = 0; i < plan.length; i++) { var q0 = make(plan[i]); if (q0) qs.push(q0); }
  var fg = 0; while (qs.length < EXAM_TOTAL && fg++ < 14) { var kk = (hasT && hasN) ? (fg % 2 ? "T" : "N") : (hasT ? "T" : "N"), q2 = make({ k: kk, t: ["NEXT", "COMP", "PREV", "COMP"][fg % 4] }); if (q2) qs.push(q2); }   // تكملة العدد لو سؤال تعذّر بناؤه
  if (qs.length < 5) return { err: "المحفوظ حتى الآن (" + src.K + " ربع في الكنز، و" + src.V + " آية في الجديد) قليل لعمل اختبار كامل — جرّب بعد ما تحفظ أكثر.", K: src.K, V: src.V };
  var spare = [], sp = ["T", "N", "X", "T", "N", "X"];
  for (i = 0; i < sp.length; i++) { if ((sp[i] === "N" && !hasN) || (sp[i] === "T" && !hasT) || (sp[i] === "X" && !hasT && !hasN)) continue; var q1 = make({ k: sp[i], t: sp[i] === "X" ? "SURAH" : "NEXT" }); if (q1) spare.push(q1); }
  for (i = 0; i < qs.length; i++) { qs[i].i = i; if (qs[i].k === "T" && qs[i].slot) covT.push(qs[i].slot); if (qs[i].k === "N") covN.push(qs[i].ref.a); }
  return { qs: shuf_(qs).map(function (q, n) { q.i = n; return q; }), spare: spare };
}

/* ---------- مطابقة التسميع (متسامحة: تتجاهل التشكيل والفروق الإملائية البسيطة وتكرار الجمل وعبارات قبل/بعد القراءة) ---------- */
function lev_(a, b) {
  var n = a.length, m = b.length, prev = [], cur, i, j;
  if (!n) return m; if (!m) return n;
  for (j = 0; j <= m; j++) prev[j] = j;
  for (i = 1; i <= n; i++) { cur = [i]; for (j = 1; j <= m; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a.charAt(i - 1) === b.charAt(j - 1) ? 0 : 1)); prev = cur; }
  return prev[m];
}
function ratio_(a, b) { var L = Math.max(a.length, b.length); return L ? 1 - lev_(a, b) / L : 1; }
function wordEq_(a, b) { if (a === b) return true; if (Math.max(a.length, b.length) <= 3) return false; return ratio_(a, b) >= 0.70; }
function lcsTab_(ew, hw) {
  var n = ew.length, m = hw.length, dp = [], r, c;
  for (r = 0; r <= n; r++) { dp[r] = []; for (c = 0; c <= m; c++) dp[r][c] = 0; }
  for (r = 1; r <= n; r++) for (c = 1; c <= m; c++) dp[r][c] = Math.max(dp[r - 1][c], dp[r][c - 1], wordEq_(ew[r - 1], hw[c - 1]) ? dp[r - 1][c - 1] + 1 : 0);
  return dp;
}
function cleanHyp_(h, exp) {
  h = String(h || "").substring(0, 1500);
  h = normAr_(h);
  h = h.replace(/\s*صدق الله العظيم\s*$/, "").replace(/^(اعوذ بالله من الشيطان الرجيم\s*)/, "");
  if (exp.indexOf("بسم الله الرحمن الرحيم") !== 0) h = h.replace(/^بسم الله الرحمن الرحيم\s*/, "");
  return h;
}
function recBest_(expSimple, alts) {                    // {sim, hyp}: أفضل بديل تعرّف، مع البحث عن «نافذة» تطابق الآية لو قرأها مرتين أو أضاف كلامًا
  var exp = normAr_(expSimple), ew = exp.split(" "), n = ew.length, best = { sim: 0, hyp: "" }, i, st, L, lens, m, hw, dp, sc;
  for (i = 0; i < (alts || []).length; i++) { var t0 = String(alts[i] || "").replace(/\s+/g, " ").replace(/^\s|\s$/g, ""); if (t0) { best.hyp = t0; break; } }      // حتى لو التطابق صفرًا نحفظ ما قيل لعرضه في المراجعة
  for (i = 0; i < (alts || []).length; i++) {
    var h = cleanHyp_(alts[i], exp); if (!h) continue;
    hw = h.split(" "); m = hw.length; dp = lcsTab_(ew, hw);
    sc = dp[n][m] / Math.max(n, Math.ceil(m * 0.7));
    if (m > n * 1.15) {
      lens = [n, Math.ceil(n * 1.25)];
      for (var li = 0; li < lens.length; li++) { L = Math.min(lens[li], m); for (st = 0; st + L <= m; st++) { var d2 = lcsTab_(ew, hw.slice(st, st + L)); sc = Math.max(sc, d2[n][L] / Math.max(n, Math.ceil(L * 0.8))); } }
    }
    sc = Math.max(sc, Math.max(0, (ratio_(exp.replace(/ /g, ""), h.replace(/ /g, "")) - 0.45) / 0.55));
    if (sc > best.sim) best = { sim: sc, hyp: String(alts[i] || "").replace(/\s+/g, " ").replace(/^\s|\s$/g, "") };
  }
  return best;
}
function recSim_(expSimple, alts) { return recBest_(expSimple, alts).sim; }
function recDiff_(expSimple, hypText) {                 // الكلمات الناقصة/المختلفة (من الآية) والزائدة (مما قيل) — للمراجعة بعد الاختبار
  var exp = normAr_(expSimple), ew = exp.split(" "), hw = cleanHyp_(hypText, exp).split(" "), n = ew.length, m = hw.length, dp, r = n, c = m, mi = {}, ei = {}, miss = [], extra = [], i;
  if (!hw[0]) return { miss: ew.slice(0, 14), extra: [] };
  dp = lcsTab_(ew, hw);
  while (r > 0 && c > 0) {
    if (wordEq_(ew[r - 1], hw[c - 1]) && dp[r][c] === dp[r - 1][c - 1] + 1) { mi[r - 1] = 1; ei[c - 1] = 1; r--; c--; }
    else if (dp[r - 1][c] >= dp[r][c - 1]) r--; else c--;
  }
  for (i = 0; i < n; i++) if (!mi[i]) miss.push(ew[i]);
  for (i = 0; i < m; i++) if (!ei[i]) extra.push(hw[i]);
  return { miss: miss.slice(0, 14), extra: extra.slice(0, 14) };
}

/* ---------- الجلسات (ورقة مخفية) ---------- */
function sessSheet_() {
  var sh = ss_().getSheetByName(EXAM_SESS_SHEET);
  if (!sh) { sh = ss_().insertSheet(EXAM_SESS_SHEET); sh.appendRow(["sid", "uid", "date", "mode", "status", "json"]); try { sh.hideSheet(); } catch (e) {} }
  return sh;
}
function sessFind_(sid) {
  var sh = sessSheet_(), n = sh.getLastRow(), i, v;
  if (n < 2) return null;
  v = sh.getRange(2, 1, n - 1, 6).getValues();
  for (i = v.length - 1; i >= 0; i--) if (String(v[i][0]) === String(sid)) { try { return { row: i + 2, s: JSON.parse(v[i][5]) }; } catch (e) { return null; } }
  return null;
}
function sessFindActive_(uid, date, mode) {
  var sh = sessSheet_(), n = sh.getLastRow(), i, v;
  if (n < 2) return null;
  v = sh.getRange(2, 1, n - 1, 6).getValues();
  for (i = v.length - 1; i >= 0; i--) if (String(v[i][1]) === String(uid) && String(v[i][2]) === String(date) && String(v[i][3]) === mode) { try { return { row: i + 2, s: JSON.parse(v[i][5]) }; } catch (e) { return null; } }
  return null;
}
function cellJson_(o) { var j = JSON.stringify(o); if (j.length > 48000 && o.spare) { o.spare = []; j = JSON.stringify(o); } return j; }
function sessSave_(row, s) { var sh = sessSheet_(); sh.getRange(row, 5, 1, 2).setValues([[s.status, cellJson_(s)]]); }
function sessNew_(s) { var sh = sessSheet_(); sh.appendRow([s.sid, s.uid, s.date, s.mode, s.status, cellJson_(s)]); return sh.getLastRow(); }
function sessPrune_() {                                 // يحذف الجلسات الأقدم من 5 أيام (تنظيف دوري خفيف)
  try {
    var sh = sessSheet_(), n = sh.getLastRow(); if (n < 60) return;
    var v = sh.getRange(2, 1, n - 1, 3).getValues(), i, cut = Utilities.formatDate(new Date(new Date().getTime() - 5 * 86400000), TZ, "yyyy-MM-dd");
    for (i = v.length - 1; i >= 0; i--) if (String(v[i][2]) < cut) sh.deleteRow(i + 2);
  } catch (e) {}
}

/* ---------- عرض السؤال للمتصفح (بدون الإجابة) ---------- */
function examPub_(s) {
  var q = s.qs[s.cur];
  return { n: s.cur + 1, total: s.qs.length, t: q.t, k: q.k, prompt: q.prompt, show: q.show, opts: q.opts || null, lim: q.lim, rec: !!q.rec, attempt: s.att || 0 };
}
function fmtPts_(x) { return (Math.round(x * 2) / 2).toString().replace(".5", "٫5"); }

/* ---------- نتيجة نهائية + نص ولي الأمر ---------- */
function revItem_(i, q, r) {                            // سؤال كامل للمراجعة: نصه وخياراته وإجابتك والصحيح (وللتسميع: ما سُمع وما نقص)
  var it = { n: i + 1, t: q.t, k: q.k, prompt: q.prompt, show: q.show, st: r.st, pts: r.pts, sec: r.sec || 0, cor: q.cor, rec: !!q.rec };
  if (q.opts) { it.opts = q.opts; it.ans = q.ans; it.mine = (r.mine === undefined ? null : r.mine); }
  if (q.rec) { it.hyp = r.hyp || ""; it.diff = r.hyp ? recDiff_(q.exp, r.hyp) : null; }
  return it;
}
function examFinish_(s, why) {
  var i, by = { T: [0, 0], N: [0, 0], X: [0, 0] }, rec = [0, 0, 0], tot = 0, cnt = 0, secs = [], wrong = [], review = [], r, q, ok;
  for (i = 0; i < s.qs.length; i++) {
    q = s.qs[i]; r = s.res[i] || { pts: 0, st: "unanswered", sec: 0 };
    if (r.st === "void") { rec[2]++; secs.push(r.sec || 0); review.push(revItem_(i, q, r)); continue; }
    cnt++; tot += r.pts; by[q.k][0] += r.pts; by[q.k][1]++;
    if (q.t === "REC") { rec[0] += r.pts; rec[1]++; }
    secs.push(r.sec || 0);
    if (r.pts < 1) wrong.push(i + 1);
    review.push(revItem_(i, q, r));
  }
  var sumSec = 0; for (i = 0; i < secs.length; i++) sumSec += secs[i];
  var cov = { t: [], n: [] };
  for (i = 0; i < s.qs.length; i++) { q = s.qs[i]; if ((s.res[i] || {}).st === "unanswered") continue; if (q.k === "T" && q.slot && cov.t.indexOf(q.slot) < 0) cov.t.push(q.slot); if (q.k === "N" && cov.n.indexOf(q.ref.a) < 0) cov.n.push(q.ref.a); }
  var res = { sid: s.sid, uid: s.uid, date: s.date, mode: s.mode, score: tot, total: cnt, pct: cnt ? Math.round(tot * 100 / cnt) : 0, by: by, rec: rec, secs: secs, sumSec: sumSec, avg: secs.length ? Math.round(sumSec / secs.length) : 0, viol: s.viol || 0, ended: why || null, wrong: wrong, review: review, cov: cov, voice: !!s.voice };
  return res;
}
function examDetail_(rs, kahf) {
  var P = [], mm = Math.floor(rs.sumSec / 60), ss = rs.sumSec % 60;
  P.push("اختبار الجمعة: " + fmtPts_(rs.score) + " من " + rs.total + " (" + rs.pct + "%)");
  if (rs.by.T[1]) P.push("الكنز " + fmtPts_(rs.by.T[0]) + "/" + rs.by.T[1]);
  if (rs.by.N[1]) P.push("الثابت (الجديد) " + fmtPts_(rs.by.N[0]) + "/" + rs.by.N[1]);
  if (rs.by.X[1]) P.push("مختلط " + fmtPts_(rs.by.X[0]) + "/" + rs.by.X[1]);
  if (rs.rec[1] || rs.rec[2]) P.push("التسميع " + fmtPts_(rs.rec[0]) + "/" + rs.rec[1] + (rs.rec[2] ? " (تعذّر الصوت في " + rs.rec[2] + ")" : ""));
  P.push("الوقت " + mm + "د " + ss + "ث (متوسط " + rs.avg + "ث للسؤال)");
  P.push("مرات الخروج من الاختبار: " + rs.viol + (rs.ended === "violations" ? " (انتهى الاختبار بسبب الخروج المتكرر)" : ""));
  if (kahf === "done") P.push("الكهف: ✅ تم"); else if (kahf === "none") P.push("الكهف: ❌ لم يتم");
  if (rs.wrong.length) P.push("أسئلة غير صحيحة: " + rs.wrong.slice(0, 12).map(function (n) { return "س" + n; }).join(" "));
  P.push("زمن كل سؤال بالثواني: " + rs.secs.join("-"));
  var out = P.join(" | ");
  return out.length > 900 ? out.substring(0, 897) + "..." : out;
}
function examSaveResult_(u, rs) {
  var sh = ss_().getSheetByName(EXAM_SHEET);
  if (!sh) { sh = ss_().insertSheet(EXAM_SHEET); sh.appendRow(["sid", "uid", "التاريخ", "الاسم", "النوع", "الدرجة", "من", "النسبة", "نص ولي الأمر", "تفاصيل"]); }
  sh.appendRow([rs.sid, u.id, rs.date, u.name, rs.mode === "official" ? "رسمي" : "تدريبي", rs.score, rs.total, rs.pct, examDetail_(rs, ""), (function () { var j = JSON.stringify(rs); if (j.length > 48000) { var c = JSON.parse(j), k; for (k = 0; k < c.review.length; k++) { delete c.review[k].opts; } j = JSON.stringify(c); } return j; })()]);
}
function examResultFor_(uid, sid) {
  var sh = ss_().getSheetByName(EXAM_SHEET), n, v, i;
  if (!sh || (n = sh.getLastRow()) < 2) return null;
  v = sh.getRange(2, 1, n - 1, 10).getValues();
  for (i = v.length - 1; i >= 0; i--) if (String(v[i][0]) === String(sid) && String(v[i][1]) === String(uid)) { try { return JSON.parse(v[i][9]); } catch (e) { return null; } }
  return null;
}
function resPub_(rs) { return { score: rs.score, total: rs.total, pct: rs.pct, by: rs.by, rec: rs.rec, secs: rs.secs, sumSec: rs.sumSec, avg: rs.avg, viol: rs.viol, ended: rs.ended, review: rs.review, sid: rs.sid, date: rs.date, mode: rs.mode, text: examDetail_(rs, "") }; }

/* ---------- المخالفة (الخروج من الصفحة): السؤال يتبدّل ---------- */
function examViolate_(s) {
  s.viol = (s.viol || 0) + 1;
  if (s.viol >= EXAM_MAX_VIOL) return "end";
  var q = s.qs[s.cur], i, rep = -1;
  for (i = 0; i < s.spare.length; i++) if (s.spare[i].k === q.k && !s.spare[i].rec) { rep = i; break; }
  if (rep < 0) for (i = 0; i < s.spare.length; i++) if (!s.spare[i].rec) { rep = i; break; }
  if (rep >= 0) { var nq = s.spare.splice(rep, 1)[0]; nq.i = q.i; s.qs[s.cur] = nq; }
  s.issued = new Date().getTime(); s.att = 0; s.ems = 0; s.best = 0; s.bestHyp = "";
  return "swap";
}

/* ---------- نقطة الدخول ---------- */
function actExam_(d) {
  var u = auth_(d);
  if (!u) return { ok: false, error: "auth" };
  var now = new Date().getTime(), today = Utilities.formatDate(new Date(), TZ, "yyyy-MM-dd"), r, s, row;
  if (d.op === "start") {
    var mode = d.mode === "official" ? "official" : "practice", voice = d.voice === true;
    if (mode === "official") {
      var u7 = Number(Utilities.formatDate(new Date(), TZ, "u"));
      if (u7 !== 5) return { ok: false, error: "الاختبار الرسمي يوم الجمعة بس. تقدر تجرّب اختبارًا تدريبيًا دلوقتي." };
      r = sessFindActive_(u.id, today, "official");
      if (r && r.s.status === "done") { var old = examResultFor_(u.id, r.s.sid); return { ok: true, done: true, result: old ? resPub_(old) : null, sid: r.s.sid }; }
      if (r && r.s.status === "active") {                // رجوع بعد تحديث/خروج: يُحسب خروجًا ويتبدّل السؤال
        s = r.s; var vv = examViolate_(s);
        if (vv === "end") { var rs0 = examFinish_(s, "violations"); s.status = "done"; sessSave_(r.row, s); examSaveResult_(u, rs0); return { ok: true, done: true, result: resPub_(rs0), sid: s.sid }; }
        sessSave_(r.row, s);
        return { ok: true, sid: s.sid, resumed: true, viol: s.viol, maxViol: EXAM_MAX_VIOL, mode: s.mode, voice: s.voice, q: examPub_(s) };
      }
    }
    sessPrune_();
    var st = loadState_(u.id), b = examBuild_(u, st, today, voice, examHist_(u.id));
    if (b.err) return { ok: false, error: b.err };
    s = { sid: rand_(16), uid: u.id, date: today, mode: mode, voice: voice, status: "active", cur: 0, qs: b.qs, spare: b.spare, viol: 0, issued: now, att: 0, ems: 0, best: 0, res: [], t0: now };
    sessNew_(s);
    return { ok: true, sid: s.sid, total: s.qs.length, mode: mode, voice: voice, viol: 0, maxViol: EXAM_MAX_VIOL, q: examPub_(s) };
  }
  if (d.op === "find") {                                 // هل أنهى اختبار اليوم الرسمي؟ (تستعملها صفحة تقرير الجمعة)
    var fr = sessFindActive_(u.id, String(d.date || today), "official");
    if (!fr) return { ok: true, found: false };
    if (fr.s.status === "done") { var fx = examResultFor_(u.id, fr.s.sid); return { ok: true, found: true, done: true, sid: fr.s.sid, result: fx ? resPub_(fx) : null }; }
    return { ok: true, found: true, done: false, sid: fr.s.sid };
  }
  r = sessFind_(d.sid);
  if (!r || String(r.s.uid) !== String(u.id)) return { ok: false, error: "الجلسة غير موجودة. ابدأ الاختبار من جديد." };
  s = r.s; row = r.row;
  if (d.op === "result") { var rr = examResultFor_(u.id, s.sid); return rr ? { ok: true, done: true, result: resPub_(rr) } : { ok: false, error: "لا توجد نتيجة بعد." }; }
  if (s.status === "done") { var rd = examResultFor_(u.id, s.sid); return { ok: true, done: true, result: rd ? resPub_(rd) : null }; }
  if (d.op === "viol") {
    var vr = examViolate_(s);
    if (vr === "end") { var rs1 = examFinish_(s, "violations"); s.status = "done"; sessSave_(row, s); examSaveResult_(u, rs1); return { ok: true, done: true, result: resPub_(rs1) }; }
    sessSave_(row, s);
    return { ok: true, swapped: true, viol: s.viol, maxViol: EXAM_MAX_VIOL, q: examPub_(s) };
  }
  if (d.op !== "answer") return { ok: false, error: "طلب غير معروف" };
  if (Number(d.n) !== s.cur + 1) return { ok: false, error: "ترتيب الأسئلة غير صحيح. أعد تحميل الصفحة." };
  var q = s.qs[s.cur], elapsed = now - s.issued, lim = q.lim, pts = 0, st2 = "wrong", sec = Math.min(lim, Math.round(elapsed / 1000)), mine = null, hyp = "";
  var late = elapsed > (lim + EXAM_GRACE_SEC) * 1000;
  if (q.t === "REC") {
    hyp = s.bestHyp || "";
    if (d.fail === true) { st2 = "void"; pts = 0; }
    else if (late) { st2 = "timeout"; pts = 0; if (s.best >= EXAM_HALF) { pts = s.best >= EXAM_FULL ? 1 : 0.5; st2 = pts === 1 ? "ok" : "half"; } }
    else {
      var alts = (d.alts || []).filter(function (x) { return normAr_(x); });
      if (!alts.length && d.final === true) { st2 = "timeout"; pts = 0; }          // انتهى الوقت بدون أي قراءة
      else if (!alts.length) { s.ems = (s.ems || 0) + 1; if (s.ems < 3) { sessSave_(row, s); return { ok: true, retry: true, why: "nospeech", attempt: s.ems, max: 3 }; } st2 = "void"; pts = 0; }
      else {
        var rb = recBest_(q.exp, alts); s.att = (s.att || 0) + 1;
        if (rb.sim > (s.best || 0)) { s.best = rb.sim; s.bestHyp = rb.hyp; }
        hyp = s.bestHyp || rb.hyp;
        if (rb.sim < EXAM_FULL && s.att < 3 && d.final !== true) { sessSave_(row, s); return { ok: true, retry: true, why: "low", attempt: s.att, max: 3 }; }
        pts = s.best >= EXAM_FULL ? 1 : (s.best >= EXAM_HALF ? 0.5 : 0);
        st2 = pts === 1 ? "ok" : (pts === 0.5 ? "half" : "wrong");
      }
    }
  } else {
    if (d.skip !== true && d.ans !== undefined && d.ans !== null && Number(d.ans) >= 0 && Number(d.ans) < (q.opts || []).length) mine = Number(d.ans);
    if (late) { st2 = "timeout"; pts = 0; }
    else if (d.skip === true) { st2 = "wrong"; pts = 0; }
    else if (mine === q.ans) { st2 = "ok"; pts = 1; }
  }
  s.res[s.cur] = { pts: pts, st: st2, sec: sec, mine: mine, hyp: hyp };
  s.cur++; s.issued = now; s.att = 0; s.ems = 0; s.best = 0; s.bestHyp = "";
  if (s.cur >= s.qs.length) { var rs2 = examFinish_(s, null); s.status = "done"; sessSave_(row, s); examSaveResult_(u, rs2); return { ok: true, done: true, result: resPub_(rs2) }; }
  sessSave_(row, s);
  return { ok: true, q: examPub_(s), viol: s.viol || 0 };
}

/* شغّلها من Apps Script للتأكد أن الاختبار جاهز (لا تحفظ شيئًا ولا ترسل شيئًا) */
function testExam() {
  var t0 = new Date().getTime(), today = Utilities.formatDate(new Date(), TZ, "yyyy-MM-dd"), Q, i, n = 0;
  try { Q = quran_(); } catch (e) { Logger.log("❌ " + e.message); return; }
  Logger.log("1) ملف المصحف على الموقع: " + Q.surahs.length + " سورة، 6236 آية ✅ (" + (new Date().getTime() - t0) + " مللي ثانية)");
  qx_(); Logger.log("2) فهرس البحث والتحقق من التكرار جاهز ✅");
  var users = readUsers_();
  for (i = 0; i < users.length; i++) {
    var u = users[i], st = loadState_(u.id), b = examBuild_(u, st, today, true, examHist_(u.id)), k, c = { T: 0, N: 0, X: 0 }, r = 0;
    var sc = examSources_(u, st, today);
    Logger.log("   " + u.name + " — المسجّل في النظام: " + (sc ? sc.K + " ربع في الكنز | " + sc.V + " آية في الجديد | بداية الخطة " + st.start + (st.base ? " | نقطة الانطلاق: كنز " + st.base.c + " وجديد " + st.base.v : " | (لم يحدّد «وين وصلت»)") : "لم يحدد بداية الخطة بعد"));
    if (b.err) { Logger.log("3) " + u.name + ": ❌ " + b.err); continue; }
    for (k = 0; k < b.qs.length; k++) { c[b.qs[k].k]++; if (b.qs[k].t === "REC") r++; }
    Logger.log("3) " + u.name + ": ✅ " + b.qs.length + " سؤال (كنز " + c.T + " | ثابت " + c.N + " | مختلط " + c.X + " | تسميع " + r + ") + " + b.spare.length + " أسئلة بديلة. لم يُحفظ شيء.");
    n++;
  }
  Logger.log("4) الأرباع والآيات المختبَرة سابقًا تُقرأ من ورقة «" + EXAM_SHEET + "» ✅ | التوقيت الكلي: " + (new Date().getTime() - t0) + " مللي ثانية");
  if (!n) Logger.log("⚠️ لا يوجد مشترك لديه محفوظ كافٍ بعد (أو لم يحدد بداية الخطة).");
}
